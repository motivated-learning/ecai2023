﻿// Original ANAKG and AAS implementation and visualization introduced and
// developed by Adrian Horzyk (horzyk@agh.edu.pl, adrianhorzyk@gmail.com)
// All rights reserved to this code.
// Changes and use of this code after the permission given by the author.
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Data;
//using System.Windows.Documents;
using System.Windows.Input;
//using System.Windows.Media;
//using System.Windows.Media.Imaging;
//using System.Windows.Navigation;
//using System.Windows.Shapes;
//using System.Windows.Threading;
using System.Globalization;
using System.Net;
using System.IO;
using Microsoft.Win32;
//using KnowledgeMiner.Utils;
using System.Threading;
using System.Text.RegularExpressions;
using System.Net.Sockets;

//***********************************************************************************************************************************************
namespace KnowledgeMiner.WPFANG
{
    /// <summary>
    /// Interaction logic for ANAKGMainWindow.xaml
    /// </summary>
    public partial class ANAKGMainWindow
    {

        // Incoming data from the client.  
        public static string data = null;
        public static ANAKG anakg;

        public static void StartListening()
        {
            // Data buffer for incoming data.  
            byte[] bytes = new Byte[2048];

            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[1]; // [1] gives ip4, [0] gives ip6 
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11111);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and
            // listen for incoming connections.  
            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.  
                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    Socket handler = listener.Accept();
                    data = null;

                    // An incoming connection needs to be processed.  
                    while (true)
                    {
                        int bytesRec = handler.Receive(bytes);
                        data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                        if (data.IndexOf("<EOF>") > -1)
                        {
                            break;
                        }
                    }

                    // Show the data on the console.  
                    Console.WriteLine("Text received : {0}", data);

                    string incoming_string;

                    incoming_string = data.Replace("<EOF>", "").TrimEnd('\r', '\n');

                    if (incoming_string == "open_dataset_and_learn")
                    {
                        Console.WriteLine("Learned");
                        data = "Learned";
                        FileStream stream = new FileStream("agent_simple.txt", FileMode.Open, FileAccess.Read);
                        //dataFileName = fDialog.FileName.Split('.');
                        //validationDataList = SerializationHelper.Deserialize(stream);
                        // Read sequences for learning or asking
                        StreamReader reader = new StreamReader(stream);
                        anakg.ReadData(reader);
                        anakg.LearnFullSet(AdaptationPhase.CreateNetwork, anakg.MaxTuneCycles);
                        //data += anakg.NoLearnedSequences.ToString();

                        //anakg.AskPattern("Study more");
                        //ata += anakg.EffOutputs.OutputSequencePattern;
                        
                        //anakg.MaxTuneCycles = 100;
                        //data += anakg.MaxTuneCycles.ToString();
                    }
                    else
                    {
                       
                        anakg.AskPattern(incoming_string);
                        data = anakg.EffOutputs.OutputSequencePattern;
                       
                    }
                    // Echo the data back to the client.  
                    byte[] msg = Encoding.ASCII.GetBytes(data);

                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            //Console.WriteLine("\nPress ENTER to continue...");
            //Console.Read();

        }



        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        //protected ANAKG anakg;
        protected byte myBackground;
        ///protected ImageBrush brushBackground;
        string[] dataFileName;
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        public byte MyBackground
        {
            get { return myBackground; }
        }
        #endregion PROPERTIES ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        static void Main(string[] args)

        {  
            // Create ANAKG-4
            anakg = new ANAKG();

            StartListening();
            /*
            FileStream stream = new FileStream("agent_simple.txt", FileMode.Open, FileAccess.Read);
            //dataFileName = fDialog.FileName.Split('.');
            //validationDataList = SerializationHelper.Deserialize(stream);
            // Read sequences for learning or asking
            StreamReader reader = new StreamReader(stream);
            anakg.ReadData(reader);
            anakg.LearnFullSet(AdaptationPhase.CreateNetwork, anakg.MaxTuneCycles);
            data += anakg.NoLearnedSequences.ToString();

            anakg.AskPattern("Study more");

            //anakg.Neurons
            */
        }
        #endregion CONSTRUCTORS ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //--------------------------------------------------------------------------------------------------------------------------------------------
        //#region UPDATE VIEW METHODS ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

        //-----------------------------------------------------------------------------------------------------------------------------
        public void SaveLoggerIntoFile()
        {
            /*
                SaveFileDialog fDialog = new SaveFileDialog();
            //fDialog.Title = "Save Intermediate Results of AANG Construction";
            //fDialog.Filter = "AANG-IntermediateResults|*.txt";
            //fDialog.InitialDirectory = @"C:\\AANG// Logger\\AANG-ConstructionStatistics.txt"; // "C:\AANG// Logger\"; IntermediateResults.txt
            fDialog.Title = "Save Construction Statistics of AANG Construction";
            fDialog.Filter = "ANAKG-Results|*.txt";
            fDialog.InitialDirectory = @"Logger\\"; // "C:\AANG// Logger\"; IntermediateResults.txt
            if (fDialog.ShowDialog() == true)   // DialogResult.OK
            {
                try
                {
                    anakg.SaveLoggerIntoFile(fDialog.FileName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unable to save results in this location! Exception: {0}", ex.Message);
                }
            }
            */
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void AutomaticSaveLoggerIntoFile()
        {
            try
            {
                anakg.SaveLoggerIntoFile(dataFileName[0] + "-Results." + dataFileName[1]);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to save results in this location! Exception: {0}", ex.Message);
            }
        }   //#endregion MENU BUTTONS EXECUTORS ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
    }   // End of MainWindow class ******************************************************
    //***********************************************************************************************************************************************
    #region DEFINITION OF ENUM FIELDS
    public enum ActionType : byte
    {
        create = 0,
        stimulate = 1,
        charge = 2,
        relax = 3,
        activate = 4,
        absrefract = 5,
        relrefract = 6
    }
    public enum AdaptationPhase : byte
    {
        CreateNetwork = 0,
        TuneNetwork = 10,
        TuneConflicts = 11,      // The following 11 --> 12 --> 13 --> (consitute a tuning cycle) 
        AvoidIncorrect = 12,
        //AvoidUndemanded = 13,
        //AvoidTooEarly = 14,
        AskNetwork = 20
    }
    #endregion DEFINITION OF ENUM FIELDS
    //***********************************************************************************************************************************************
    public abstract class Vertex // Vertex of the Associative Neural Graph
    {
        public enum VertexType : byte
        {
            vertex = 0,
            // SYNAPSES OF VARIOUS KINDS
            synapse = 10,
            // NEURONS OF VARIOUS KINDS
            neuron = 20,
            sensoryneuron = 21,
            objectneuron = 22,
            rangeneuron = 23,
            subsetneuron = 24,
            // SENSORS OF VARIOUS KINDS
            sensor = 30,
            numericalsensor = 31,
            booleansensor = 32,
            symbolicsensor = 33,
            // EFFECTORS OF VARIOUS KINDS
            effector = 40,
            // SENSORY INPUT FIELDS OF VARIOUS KINDS
            sensinput = 50,
            numericalsensinput = 51,
            booleansensinput = 52,
            symbolicsensinput = 53,
            // EFFECTORY OUTPUT FIELDS OF VARIOUS KINDS
            effoutput = 60
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public enum PlasticityMode : byte
        {
            off = 0,
            create = 1,
            tune = 2,
            ask = 3
        }
        #region STATIC FIELDS
        //protected static PlasticityMode modePlasticity;
        protected static ANAKG anakg;
        protected static EventQueue events;        // Pointer to Priority Queue of EventQueue
        protected static bool animate;   // If true the verteces should be created and animated and there are many actionSteps to provide gradual changes. On the other hand no animation is provided and all actionSteps = 1
        //protected static bool animate = true;
            // All view methods and parameters are separated from the mathematical model and computations
        protected static readonly UInt16 periodCreating = 500;
        protected static AdaptationPhase phase;     // Defines the tuning cycle in which all neurons are tuned in three consecutive phases: TuneConflicts --> AvoidUndemanded --> AvoidTooEearly --> Check how many weights were changed and whether the tuning process should be finished?  
        protected static UInt64 stopStimulatingNeurons;
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected double x;             // Input excitation
        protected double y;             // Output value
        protected string name;          // Name of the represented element
        protected VertexType type;
        protected UInt64 timeUpdate;    // simTime of the last update of this vertex
        protected UInt64 timeActivation;    // Neuron last activation (spike) time     
        protected UInt64 timeCreation;  // The time of creation of this vertex
        protected UInt32 actionInterval;          // Computed interval of time necessary to process this action
        protected UInt64 actionBeginTime;         // Simulation time when this action began
        protected UInt16 actionSteps;             // The number of action steps/events for animation purposes
        protected UInt16 actionStepCntr;          // Action step counter decrementing the rest of steps/events to evaluate this action
        protected UInt32 actionStepInterval;      // The time lapses between following action steps
        protected Event activeEvent;              // active event defines an active process that is currently processed by this neuron, however it can change if external stimuli comes before it fhinishes.
        static protected UInt64 initSimTime = 0;  // The moment of time after which some variables should be automatically initialized before next operations on them. This allows to avoid search through the networks for elements that should be initialized in many nested loops
        protected UInt64 myInitSimTime = 0;       // The sim time when some variables of this vertex were last initialized
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public virtual double X { get { return x; } }
        public virtual double Y { get { return y; } }
        public VertexType Type
        {
            get { return type; }
        }
        public string Name
        {
            get { return name; }
        }
        public static EventQueue Events
        {
            set { events = value; }
        }
        //public static PlasticityMode ModePlasticity
        //{
        //    set { modePlasticity = value; }
        //}
        public static ANAKG Anakg
        {
            set { anakg = value; }
        }
        public static bool Animate
        {
            get { return animate; }
            set { animate = value; }
        }
        //public static bool Animate
        //{
        //    get { return animate; }
        //    set { animate = value; }
        //}
        public static AdaptationPhase Phase
        {
            get { return phase; }
            set { phase = value; }
        }
        public static bool IsCreating
        {
            get { return phase == AdaptationPhase.CreateNetwork; }
        }
        public static bool IsTuning
        {
            get { return (phase >= AdaptationPhase.TuneNetwork) && (phase <= AdaptationPhase.AvoidIncorrect); }
        }
        public static bool IsTuningConflicts
        {
            get { return phase == AdaptationPhase.TuneConflicts; }
        }
        public static bool IsAvoidingIncorrect
        {
            get { return phase == AdaptationPhase.AvoidIncorrect; }
        }
        //public static bool IsAvoidingUndemanded
        //{
        //    get { return phase == AdaptationPhase.AvoidUndemanded; }
        //}
        //public static bool IsAvoidingTooEarly
        //{
        //    get { return phase == AdaptationPhase.AvoidTooEarly; }
        //}
        public static bool IsAsking
        {
            get { return phase == AdaptationPhase.AskNetwork; }
        }
        public UInt64 TimeActivation
        {
            get { return timeActivation; }
        }
        public double RatioSteps
        {
            get { return actionStepCntr / (double)actionSteps; }
        }
        public bool IsLastStepDone
        {
            get { return actionStepCntr == actionSteps; }
        }
        static public UInt64 InitVariablesAfterSimTime
        {
            get { return initSimTime; }
            set { initSimTime = value; }
        }
        static public UInt64 StopStimulatingNeurons
        {
            get { return stopStimulatingNeurons; }
            set { stopStimulatingNeurons = value; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public Vertex(UInt64 simtimeCreation, string name = null)
        {
            type = VertexType.vertex;
            x = 0.0;
            y = 0.0;
            this.name = name;
            timeUpdate = 0;
            timeActivation = 0;
            timeCreation = simtimeCreation;
            activeEvent = null;
            ///view = null;
            //counter++;
            //no++;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public abstract void Update(Vertex sender, UInt64 startSimTime, object eventObject, UInt32 duration);
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    public class Synapse : Vertex // Synapse
    {
        public enum InternalState : sbyte
        {
            Nascent = -100,
            PresynapticTransmission = -1,
            SynapticCleftTransmission = 0,
            PostsynapticTransmission = 1,
            SynapticTransmission = 10,
            Resting = 100,
        }
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        protected static readonly UInt32 periodMultiplyingSynapses = 65000;
        #endregion CONST AND READONLY FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region STATIC FIELDS
        protected static UInt32 counter;                 // Counts up all synapses
        protected static byte permeabilityFormula;        // 0 - default formula, 1 - root formula, 2 - power formula
        protected static double initialMultiplication;
        //protected static UInt32 weightChangesInCycleNo;          // Number of weight changes during an adaptation phase
        protected static UInt32 noCycleWeightChanges;          // Number of weight changes during an adaptation phase
        protected static double changeWeightInCycleMax;
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        //protected SynapseView view;
        protected Vertex presynVertex;  // A receptor or neuron connected as a presynaptic element
        protected Vertex postsynVertex; // A neuron or effektor connected as a postsynaptic element
        double efficiency;  // Synaptic efficiency of activation of postsynaptic neuron on active associative training track AATT (i.e. a training sequence)
        double weight = 0; // Synaptic weight = permeability * multiplication * behavior in the used sense in ANN
        double prevCycleWeight = 0; // used to compute changes between subsequent tuning cycles
        double changeWeightInCycle = 0;
        double permeability; // Synaptic permeability, where weight = permeability * multiplication * behavior in the used sense in ANN
        double multiplication; // Multiplication of synapses between the same two objects
        sbyte behavior;     // Synaptic behavior and influence on postsynaptic neuron: { -1 ; +1 } supression or excitement
        double multiplicationChangeTimeAverage; // Used for stabilization and convergence of tuning
        double multiplicationChangeLast;
        byte tuningOffCycles;   // Defines the number of cycles during which the tuning process is turned off temporarily. When the value is 0, it means that the tuning process is turned on (default value)
        protected UInt32 timeInputConnectionTransmission;     // Time for Transmissioning stimulation throughout the connection to the presynaptic element
        protected UInt32 timeCleftTransmission;                 // Time for Transmissioning stimulation through synaptic Cleft and get a response from postsynaptic element
        protected UInt32 timeOutputConnectionTransmission;    // Time for Transmissioning stimulation throughout the connection from the postsynaptic element the next element
        protected InternalState state;  // Internal state of this Synapse and connections
        protected static UInt16 noCreatedNotBalanced;   //? --> View?
        protected bool created;
        protected UInt32 noAllStimulations; // Number of all stimulation during a tuning cycle
        protected UInt32 noMultiplicationChanges; // Number of multiplication factor changes during a tuning cycle
        protected double sumMultiplicationChanges; // Number of all stimulation during a tuning cycle
        protected double minMultiplicationChange;
        protected double multiplicationProposal; // The proposal of changes of the multiplication because in the moment it is proposed we do not know whether it is correct or not
        protected UInt64 multiplicationProposalApprovalTime;   // The time when the multiplication change will be approved and should be adapted
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        //public static UInt32 WeightChangesInCycleNo
        //{
        //    get { return weightChangesInCycleNo; }
        //    set { weightChangesInCycleNo = value; }
        //}
        public static UInt32 Counter
        {
            get { return counter; }
            set { counter = 0; }    // Only initialization possible, no other changes
        }
        public Vertex PresynVertex
        {
            get { return presynVertex; }
        }
        public Vertex PostsynVertex
        {
            get { return postsynVertex; }
        }
        public static void NullCycleWeightChanges()
        {
            noCycleWeightChanges = 0;
            changeWeightInCycleMax = 0;
        }
        public static UInt32 NoCycleWeightChanges
        {
            get { return noCycleWeightChanges; }
        }
        public static double ChangeWeightInCycleMax
        {
            get { return changeWeightInCycleMax; }
        }
        public static byte PermeabilityFormula
        {
            get { return permeabilityFormula; }
            set { permeabilityFormula = value; }
        }
        public static double InitialMultiplication
        {
            get { return initialMultiplication; }
            set { initialMultiplication = value; }
        }
        public double Permeability
        {
            get { return permeability; }
            set { permeability = value; ComputeWeight(); }
        }
        public double Multiplication
        {
            get { return multiplication; }
        }
        public double Weight
        {
            get { return weight; }
        }
        public sbyte Behavior
        {
            get { return behavior; }
        }
        public double PostsynNeuronInfluence    // This is a percentage part of permeability to postsynaptic neuron threshold value multiplied by a type of synapse: exciting or suppressing
        {
            //get { return ((postsynVertex.Type == VertexType.neuron) ? (permeability / ((Neuron)postsynVertex).Threshold) : permeability); }
            get { return ((postsynVertex.Type == VertexType.neuron) ? (weight / behavior / ((Neuron)postsynVertex).Threshold) : weight / behavior); }
        }
        public bool IsPresynVertexSensor
        {
            get { return ((PresynVertex.Type == VertexType.symbolicsensor) || (PresynVertex.Type == VertexType.numericalsensor) || (PresynVertex.Type == VertexType.booleansensor)); }
        }
        public bool IsPostsynVertexEffector
        {
            get { return PostsynVertex.Type == VertexType.effector; }
        }

        protected UInt32 NoAllStimulations
        {
            set { noAllStimulations = value; }
            get
            {
                if (myInitSimTime < InitVariablesAfterSimTime)
                {
                    noAllStimulations = 0;
                    myInitSimTime = InitVariablesAfterSimTime;
                }
                return noAllStimulations;
            }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public Synapse(Vertex presynVertex, Vertex postsynVertex, UInt64 simtimeCreation, sbyte behavior = 1, double permeability = 1.0)
            : base(simtimeCreation, null)    // for sensors and effectors weights are automatically set to value 1
        {
            counter++;
            type = VertexType.synapse;
            this.presynVertex = presynVertex;
            this.postsynVertex = postsynVertex;
            if (this.presynVertex.Type == VertexType.neuron) ((Neuron)this.presynVertex).AddMeToPostsynConn(this);
            if (this.postsynVertex.Type == VertexType.neuron) ((Neuron)this.postsynVertex).AddMeToPresynConn(this);
            this.permeability = permeability;
            this.behavior = behavior;
            if ((presynVertex.Type == VertexType.neuron) && (postsynVertex.Type == VertexType.neuron))
                multiplication = initialMultiplication; //1.0; Multiplication factors cannot be usually < 1.0, but synapses at the beginning can behave weaker than normally and it avoids the exceeding of the threshold values at the beginning of the tuning process as well as enables more fast adaptation of multiplication factors
            else multiplication = 1.0;
            //ComputeWeight(false);
            noCycleWeightChanges = 0;
            multiplicationChangeTimeAverage = 0;
            multiplicationChangeLast = 0;
            tuningOffCycles = 0;
            if ((this.presynVertex.Type == VertexType.symbolicsensor) || (this.presynVertex.Type == VertexType.numericalsensor) || (this.presynVertex.Type == VertexType.booleansensor) || (this.postsynVertex.Type == VertexType.effector)) efficiency = 1.0;
            else efficiency = 0.0;
            name = presynVertex.Type + "(" + presynVertex.Name + ") ----- " + postsynVertex.Type + "(" + postsynVertex.Name + ")";
            // Logger.LogLine(String.Format("NEW SYNAPSE ADDED between: {0} {1} and {2} {3} with permeability {4}", presynVertex.Type, presynVertex.Name, postsynVertex.Type, postsynVertex.Name, permeability));
            timeInputConnectionTransmission = 200;
            timeCleftTransmission = 700;
            timeOutputConnectionTransmission = 90;
            state = InternalState.Nascent;
            // Compute initial synaptic efficiency and permeability:
            // Add event that will create the view of this synapse
            if ((presynVertex.Type == VertexType.neuron) && (postsynVertex.Type == VertexType.neuron))
                UpdateSynapticEfficiency(((Neuron)postsynVertex).TimeActivation - ((Neuron)presynVertex).TimeActivation);
            else ComputeWeight(false);
            events.AddEvent(presynVertex, this, timeCreation);
            created = false;
            //if (animate) view = new SynapseView(this);
            noAllStimulations = 0; // Number of all stimulation during a tuning cycle
            noMultiplicationChanges = 0; // Number of multiplication factor changes during a tuning cycle
            sumMultiplicationChanges = 0; // Number of all stimulation during a tuning cycle
            minMultiplicationChange = 0;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public override void Update(Vertex sender, UInt64 currentSimTime, object eventObject, UInt32 duration)
        {   // SYNAPSE
            //if (animate)
            //{
            if (created)    //(view.CreatedView)    //! Ten warunek trzeba zmienić, bo musi działać niezależnie od widoku!
            {
                timeUpdate = currentSimTime;
                if (sender != this) // EXTERNAL STIMULATIONS
                {
                    state = InternalState.PresynapticTransmission;
                    // Start sequence of events of transmission of stimulation through presynaptic connection
                    actionInterval = timeInputConnectionTransmission;
                    actionBeginTime = currentSimTime;
                    //actionSteps = SynapseView.NoOfConnectionStateGrades;   // Creation presynaptic Transmission steps
                    actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 0;
                    events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                }
                else // sender == this INTERNAL STIMULATIONS
                {
                    if (state == InternalState.Nascent)
                    {
                        // Animate the next step of synapse creation
                           // Creation of presynaptic connection, postsynaptic connectiona and the synapse in the same moment (parallely)
                        actionStepCntr++;
                        if (actionStepCntr < actionSteps) events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        else if (actionStepCntr == actionSteps) events.AddEvent(this, this, actionBeginTime + actionInterval);
                        else
                        {
                            // The creation process of the neuron is finished. Now it can start working.
                            // Logger.LogLine(String.Format("SYNAPSE {0} HAS BEEN CREATED AT SIMTIME {1}", Name, currentSimTime));
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.Resting; //?
                            //y = x * permeability * behavior; // If the creation process is run instead of Transmissioning the input stimulation it should finish in the same way, i.e. passing the output signal to the next element
                            //To tutaj nie ma sensu? x = presynVertex.Y;
                            //To tutaj nie ma sensu y = x * weight; // If the creation process is run instead of Transmissioning the input stimulation it should finish in the same way, i.e. passing the output signal to the next element
                            noCreatedNotBalanced++;
                            // Update synaptic permeability view
                            
                            // Use postsynaptic stimulation to update the next vertex
                            if (postsynVertex.Type == VertexType.neuron) events.AddEvent(this, postsynVertex, timeUpdate);  // Is this necessary for neurons? For effectors should not be used!
                        }
                    }
                    else if (state == InternalState.PresynapticTransmission)
                    {
              

                        actionStepCntr++;
                        if (actionStepCntr < actionSteps) events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        else if (actionStepCntr == actionSteps) events.AddEvent(this, this, actionBeginTime + actionInterval);
                        else
                        {
                            // Presynaptic Transmission is finished
                            x = presynVertex.Y;
                            // Logger.LogLine(String.Format("Synapse {0} has been stimulated by the {1} {2} with strenth {3}.", Name, presynVertex.Type, presynVertex.Name, x));
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.SynapticCleftTransmission;
                            // Start sequence of events of transmission of stimulation through the synaptic Cleft
                            actionInterval = timeCleftTransmission;
                            actionBeginTime = currentSimTime;
                            //actionSteps = 2;   // Creation presynaptic Transmission steps
                            if (animate) actionSteps = 2;   // Creation presynaptic Transmission steps
                            else actionSteps = 1;
                            actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                            actionStepCntr = 1;
                            state = InternalState.SynapticCleftTransmission;
                            events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        }
                    }
                    else if (state == InternalState.SynapticCleftTransmission)
                    {
                        //+ Change brush for postsynaptic connection
                        
                        actionStepCntr++;
                        if (actionStepCntr < actionSteps) events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        else if (actionStepCntr == actionSteps) events.AddEvent(this, this, actionBeginTime + actionInterval);
                        else
                        {
                            // Synaptic Cleft Transmission is finished and postsynaptic element is appropriatelly stimulated
                            //y = x * permeability * behavior;
                            y = x * weight;
                            //It is unnecessary because I initialize all tuning counters before and after each truning phase: NoAllStimulations++;    // Should be used in Tuning Phase!
                            if (IsTuning)
                                noAllStimulations++;    // Should be used in Tuning Phase!
                            //Logger.LogLine(String.Format("noAllStimulations of the synapse {0} increased to {1}, and its output y = {2}", name, noAllStimulations, y));
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.PostsynapticTransmission;
                            // Start sequence of events of transmission of stimulation through postsynaptic connection
                            actionInterval = timeOutputConnectionTransmission;
                            actionBeginTime = currentSimTime;
                            //actionSteps = (UInt16)(SynapseView.NoOfConnectionStateGrades / 2);   // Creation postsynaptic Transmission steps
                            actionSteps = 1;
                            actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                            actionStepCntr = 1;
                            events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                            // Update activation time of this synapse because it is used during weak synapse multiplication
                            timeActivation = currentSimTime;
                        }
                    }
                    else if (state == InternalState.PostsynapticTransmission)
                    {
                        // Change brush for postsynaptic connection
                        
                        actionStepCntr++;
                        if (actionStepCntr < actionSteps) events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        else if (actionStepCntr == actionSteps) events.AddEvent(this, this, actionBeginTime + actionInterval);
                        else
                        {
                            x = 0;
                            //+ Change brush for presynaptic element
                            // Logger.LogLine(String.Format("Synapse {0} has been stimulated and the postynaptic element through permeability {1} has updated its output influence {2}", Name, permeability, y));
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.Resting;
                            // Send new event to the postsynaptic element
                            events.AddEvent(this, postsynVertex, timeUpdate);
                        }
                    }
                }
            }
            else
            {
                if (state == InternalState.Nascent)
                {
                    // Start sequence of events of creation of a new synapse and connections
                    //actionInterval = (((presynVertex.Type == VertexType.symbolicsensor) || (presynVertex.Type == VertexType.numericalsensor) || (presynVertex.Type == VertexType.booleansensor) || (postsynVertex.Type == VertexType.effector)) ? (UInt16)(periodCreating - 100) : timeInputConnectionTransmission + timeCleftTransmission); // + timeOutputConnectionTransmission; // It should take the same time as is necessary for Transmission
                    actionInterval = periodCreating;
                    actionBeginTime = currentSimTime;
                    //actionSteps = SynapseView.NoOfConnectionStateGrades;   // Creation steps
                    actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 1;
                    events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    created = true;
 
                }
                else
                {
                    // If the synapse view is not created (for sensory and effectory connections) run the simpler code:
                    x = presynVertex.Y;
                    //y = x * permeability * behavior;
                    y = x * weight;
                    timeUpdate = currentSimTime + timeInputConnectionTransmission + timeCleftTransmission + timeOutputConnectionTransmission;   // The synapse does everything in one moment?
                                                                                                                                                //if (presynVertex.Type == VertexType.sensor)
                                                                                                                                                // Logger.LogLine(String.Format("Afferent synapse {0} has been stimulated and the postynaptic element through permeability {1} has updated its output influence {2} sent from the sensor.", Name, permeability, y));
                                                                                                                                                //else // (postsynVertex.Type == VertexType.effector)
                                                                                                                                                // Logger.LogLine(String.Format("Efferent synapse {0} has been stimulated and the postynaptic element through permeability {1} has updated its output influence {2} sent to the effector.", Name, permeability, y));
                    events.AddEvent(this, postsynVertex, timeUpdate);
                }
            }
           
            //}
            //else
            //{   // Only simulate without animation
            //    if (sender != this)
            //    {
            //        state = InternalState.SynapticTransmission;
            //        x = presynVertex.Y;
            //        y = 0;
            //        timeUpdate = currentSimTime + timeInputConnectionTransmission + timeCleftTransmission;
            //        events.AddEvent(this, this, timeUpdate);
            //    }
            //    else
            //    {
            //        state = InternalState.Resting;
            //        x = 0;
            //        y = x * weight;
            //        timeUpdate = currentSimTime + timeOutputConnectionTransmission;
            //        events.AddEvent(this, postsynVertex, timeUpdate);
            //    }
            //}
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void ComputeMultiplicationChange()
        {
            double multiplicationChange = multiplication - weight / (behavior * permeability);  // "multiplicationLast = weight / (behavior * permeability)" is equal old multiplication and prevents the need to create a next variable
            //multiplicationChangeTrend = (multiplicationChangeTimeAverage * (NoCycleWeightChanges) + multiplicationChange) / (NoCycleWeightChanges + 1);
            //multiplicationChangeTimeAverage = (Math.Abs(multiplicationChangeTimeAverage) + Math.Abs(multiplicationChange)) / 2;
            multiplicationChangeTimeAverage = (multiplicationChangeTimeAverage + (multiplicationChangeLast + multiplicationChange) / 2) / 2;
            multiplicationChangeLast = multiplicationChange;
            ANAKG.NoActiveSynapsesInTuningCycle++;
            if ((Math.Abs(multiplicationChangeTimeAverage) < 0.001) && (multiplicationChange < 0))    // We can do it only after the decreasing/weakening change!
                tuningOffCycles = 20;   // 100 - is too much. It avoids training!
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void ComputeWeight(bool countup = true)
        {
            double newWeight = behavior * permeability * multiplication;
            if (weight != newWeight)
            {
                if (Vertex.Phase == AdaptationPhase.AvoidIncorrect)
                {
                    changeWeightInCycle = Math.Abs(prevCycleWeight - newWeight);
                    if (changeWeightInCycleMax < changeWeightInCycle)
                        changeWeightInCycleMax = changeWeightInCycle;
                    prevCycleWeight = newWeight;
                }
                else if (Vertex.Phase == AdaptationPhase.CreateNetwork) prevCycleWeight = newWeight;
                if ((presynVertex.Type == VertexType.neuron) && (postsynVertex.Type == VertexType.neuron))
                {
                    if (changeWeightInCycle > 0.01)
                        noCycleWeightChanges++; // Don't count up initialization of the weight as weight changes
                    //weightChangesInCycleNo++;
                    
                }
                weight = newWeight;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void TransmitStimulation(UInt64 currentSimTime)
        {
            if ((presynVertex.Type == VertexType.neuron) && (postsynVertex.Type == VertexType.neuron))
                events.AddEvent(presynVertex, this, currentSimTime);   // null (is different to this) represent the Sender (ANAKG is not a Vertex) that initiated creation of this neuron
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void UpdateInSynapticEfficiency(UInt64 postsynapticNeuronActivationTime)    // tACT = intervaltoactivationtime
        {
            UpdateSynapticEfficiency(postsynapticNeuronActivationTime - presynVertex.TimeActivation);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void UpdateSynapticEfficiency(double updateInterval)    // tACT = intervaltoactivationtime
        {
            //! REBUILD: New updated equations should be proposed! DONE!
            // There is a crutial mistake! It always takes into account only the last efficiency of this synapse, not the average efficiency for all activations of the postsynaptic neuron!? REBUILD!!! DONE!
            // The efficiency should be computed as the sum of all previous single efficiencies for each postynaptic neuron activation where this synapse tooka a part in stimulation of this neuron, i.e. thanks to the stimulation through this synapse! DONE!

            double thisStimulationEfficiency;
            double delayMaxEfficiency = 1000 * anakg.DelayFollowingObjectLearn;        // Instead of previous: (Neuron)postsynVertex).PeriodCharging
            //if (updateInterval <= ((Neuron)postsynVertex).PeriodCharging) thisStimulationEfficiency = 1;
            //else if (postsynVertex.Type == VertexType.neuron) thisStimulationEfficiency = 1 / (1 + (updateInterval - ((Neuron)postsynVertex).PeriodCharging) / (((Neuron)postsynVertex).Threshold * ((Neuron)postsynVertex).PeriodRelaxation));  // for Neurons
            //else thisStimulationEfficiency = 1 / (1 + (updateInterval - ((Neuron)postsynVertex).PeriodCharging) / ((Neuron)postsynVertex).PeriodRelaxation); // for Effectors
            //efficiency += thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency;    // power4
            if (updateInterval <= ((Neuron)postsynVertex).PeriodRelaxation) // We take into consideration only the recently stimulated synapsis which took a part in activation of the postsynaptic neuron!
            {
                if (updateInterval <= delayMaxEfficiency) thisStimulationEfficiency = 1;
                //OLD else if (postsynVertex.Type == VertexType.neuron) thisStimulationEfficiency = 1 / (1 + (updateInterval - delayMaxEfficiency) / (((Neuron)postsynVertex).Threshold * ((Neuron)postsynVertex).PeriodRelaxation));  // for Neurons     // * 4 experimental!
                else if (postsynVertex.Type == VertexType.neuron) thisStimulationEfficiency = ((Neuron)postsynVertex).PeriodRelaxation / (((Neuron)postsynVertex).PeriodRelaxation + Math.Max(0, updateInterval - delayMaxEfficiency) * Math.Pow(((Neuron)postsynVertex).Threshold, 0.25));
                else thisStimulationEfficiency = 1 / (1 + (updateInterval - delayMaxEfficiency) / ((Neuron)postsynVertex).PeriodRelaxation); // for Effectors
                //TO JEST POPRAWNE!! Dlaczego += w: efficiency += thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency;    // power4
                //TO JEST BŁĘDNE, bo musi być +=: efficiency = thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency;    // power4    // It is mistaken! Must be +=
                efficiency += thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency * thisStimulationEfficiency;    // power4
                //Logger.LogLine(String.Format("Synapse {0} has updated its synaptic efficiency to {1}", name, efficiency));
                UpdatePermeability();
            }
            //return efficiency;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void UpdatePermeability()
        {
            if ((presynVertex.Type == VertexType.neuron) && (postsynVertex.Type == VertexType.neuron))  // It is updated only for interneuronal connections, thus connections to sensors and effectors are always conducted in the same way = threshold
            {
                UInt32 presynNeurActiv;   // etaS = presynNeurActiv
                if (presynVertex.Type == VertexType.neuron) presynNeurActiv = ((Neuron)presynVertex).ActivityNo; else presynNeurActiv = 1;
                double postsynNeurThresh;   // thetaS = postsynNeurThresh
                if (postsynVertex.Type == VertexType.neuron) postsynNeurThresh = ((Neuron)postsynVertex).Threshold; else postsynNeurThresh = 1;

                //OLD NOT ASSOCIATIVELY STABLE: permeability = presynNeurActiv * efficiency * postsynNeurThresh / (presynNeurActiv + (presynNeurActiv - 1) * efficiency);
                switch (permeabilityFormula)
                {
                    case 1: permeability = efficiency / presynNeurActiv; break;    // the experimental proportional formula   // postsynNeurThresh *
                    case 2: permeability = presynNeurActiv / (2 * presynNeurActiv - efficiency); break;   // the fundamental formula   // postsynNeurThresh *
                    case 3: permeability = Math.Sqrt(presynNeurActiv * efficiency) / (Math.Sqrt(presynNeurActiv * efficiency) + presynNeurActiv - efficiency); break;    // the experimental root formula    // postsynNeurThresh * 
                    case 4: permeability = presynNeurActiv * efficiency / (presynNeurActiv * efficiency + presynNeurActiv * presynNeurActiv - efficiency * efficiency); break;    // the experimental quadratic formula   // postsynNeurThresh *
                    case 0: permeability = 2 * efficiency / (presynNeurActiv + efficiency); break;    // the first gold division formula   // postsynNeurThresh *
                    default: permeability = 2 * efficiency / (presynNeurActiv + efficiency); break;    // the first gold division formula   // postsynNeurThresh *
                }
                behavior = 1;   // Temporarily are used only excitatory synapses
                if (permeability > 1)
                    permeability = 1;   // Error! Should not happen!!!
            }
            //else if (postsynVertex.Type == VertexType.effector)
            //
            //    permeability = 1;   // For connections between sensors and neurons
            else if ((presynVertex.Type == VertexType.symbolicsensor) || (presynVertex.Type == VertexType.numericalsensor) || (presynVertex.Type == VertexType.booleansensor))
                permeability = ((Neuron)postsynVertex).Threshold; // *2 will also solve the problem of charging refracting neurons  // For connections between sensors and neurons
            ComputeWeight();
            //Logger.LogLine(String.Format("Synapse {0} has updated its synaptic permeability to {1} and weight={2}", Name, permeability, weight));
            // Update view of this synapse
            //return permeability;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public double GetMultiplicationOfActiveSynapse(UInt64 currentSimTime)
        {
            // 0 is set here experimentaly to avoid situations when other neurons that in a very close periods start to stimulate this neuron is taken into account when computing minMultiplication even though they had not make stimulation of this neuron yet!
            if ((currentSimTime - timeActivation <= periodMultiplyingSynapses) && (currentSimTime - timeActivation > 0))    // the last activity of each synapse we can check after the presynaptic neuron state that must be refracting after its activation that stimulated this synapse and the postsynaptic neuron
            {
                return multiplication;
            }
            else return 0;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void DecreaseMultiplicationOfActiveSynapse(UInt64 currentSimTime, double minMultiplication)
        {
            if (currentSimTime - timeActivation <= periodMultiplyingSynapses)    // the last activity of each synapse we can check after the presynaptic neuron state that must be refracting after its activation that stimulated this synapse and the postsynaptic neuron
            {
                multiplication /= minMultiplication;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public bool MultiplyProposal(UInt64 currentSimTime, double multiply)
        {
            // Only synapses that have been activated and take a part in stimulation of the postsynaptic neuron can update their multiplication factors
            if (currentSimTime - timeActivation <= periodMultiplyingSynapses)    // the last activity of each synapse we can check after the presynaptic neuron state that must be refracting after its activation that stimulated this synapse and the postsynaptic neuron
            {
                //I've forgoten to add it here: multiplicationProposal = multiplication * multiply; // This does not take into account that more charged neuron can faster relax but on the other hand is longer charged so it can be less relaxed, so it may be enough but is very difficult to proof whatever.
                //multiplicationProposal += multiplication * multiply; // This does not take into account that more charged neuron can faster relax but on the other hand is longer charged so it can be less relaxed, so it may be enough but is very difficult to proof whatever.
                //noMultiplicationChanges++; // It must be added to compute the final average change at the end of the tuning phase!
                multiplicationProposal = multiplication * multiply; // This does not take into account that more charged neuron can faster relax but on the other hand is longer charged so it can be less relaxed, so it may be enough but is very difficult to proof whatever.
                //multiplicationProposalApprovalTime = currentSimTime + anakg.DelayFollowingObjectLearn;
                //Logger.LogLine(String.Format("multiplicationProposal of synapse {0} is {1}", name, multiplicationProposal));
                return true;
            }
            else return false;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void MultiplyProposalAdapt()
        {
            if (multiplicationProposal > 0)
            {
                if (tuningOffCycles == 0)
                {
                    //multiplication = multiplicationProposal;
                    //multiplication = multiplicationProposal / noMultiplicationChanges;  // How it is possible that multiplicationProposal > 0 and noMultiplicationChanges == 0?!
                    multiplication = multiplicationProposal;  // How it is possible that multiplicationProposal > 0 and noMultiplicationChanges == 0?!
                    //multiplicationProposalApprovalTime = 0;
                    ComputeMultiplicationChange();
                    ComputeWeight();
                    //Logger.LogLine(String.Format("New adapted multiplication of synapse {0} is {1} and the weight = {2}", name, multiplication, weight));
                    
                }
                else tuningOffCycles--;
                multiplicationProposal = 0;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void MultiplyImmediately(UInt64 currentSimTime, double multiply)
        {
            // Only synapses that have been activated and take a part in stimulation of the postsynaptic neuron can update their multiplication factors
            if (currentSimTime - timeActivation <= periodMultiplyingSynapses)    // the last activity of each synapse we can check after the presynaptic neuron state that must be refracting after its activation that stimulated this synapse and the postsynaptic neuron
            {
                //if (tuningOffCycles == 0)
                //{
                multiplication *= multiply; // This does not take into account that more charged neuron can faster relax but on the other hand is longer charged so it can be less relaxed, so it may be enough but is very difficult to proof whatever.
                                            // Previously computed proposals should not be implemented because they will be outdated after the above change of the multiplication:
                                            //if (multiply > 1) multiplication += multiplication*multiply*trainingCoefficient; // Test it.
                                            //else multiplication *= multiply;
                                            //?if (multiplication > postsynNeuronThreshold) multiplication = postsynNeuronThreshold * 1.000001;   // * 1.000001 to avoid numerical problems // The multiplication of any synapse cannot exceed the postsynaptic threshold because in this case multiplication will substitute conductances that include information about uniqueness of the stimulation
                                            // While updating in the batch mode we cannot update the weight here because the multiplication has not changed!
                ComputeMultiplicationChange();
                ComputeWeight();
                //Logger.LogLine(String.Format("New immediate multiplication of synapse {0} is {1} and the new weight = {2}", name, multiplication, weight));
                
                //}
                //else tuningOffCycles--;
                multiplicationProposal = 0;
                sumMultiplicationChanges = 0;
                minMultiplicationChange = 0;
                noMultiplicationChanges = 0;
            }
            //return multiplication;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public bool Multiply(UInt64 currentSimTime, double multiply)
        {
            // Only synapses that have been activated and take a part in stimulation of the postsynaptic neuron can update their multiplication factors
            if (currentSimTime - timeActivation <= periodMultiplyingSynapses)    // the last activity of each synapse we can check after the presynaptic neuron state that must be refracting after its activation that stimulated this synapse and the postsynaptic neuron
            {
                //multiplication *= multiply; // This does not take into account that more charged neuron can faster relax but on the other hand is longer charged so it can be less relaxed, so it may be enough but is very difficult to proof whatever.
                sumMultiplicationChanges += multiplication * multiply;  // We don't update multiplication on-line but in the batch mode taking into account all correct stimulations as well
                if ((minMultiplicationChange > multiplication * multiply) || (minMultiplicationChange == 0)) minMultiplicationChange = multiplication * multiply;
                noMultiplicationChanges++;
                //Logger.LogLine(String.Format("New proposal multiplication {0} of synapse {1} was added to sumMultiplicationChanges = {2}, and incremented the noMultiplicationChanges = {3}", multiplication * multiply, name, weight, noMultiplicationChanges));
                //if (multiply > 1) multiplication += multiplication*multiply*trainingCoefficient; // Test it.
                //else multiplication *= multiply;
                //?if (multiplication > postsynNeuronThreshold) multiplication = postsynNeuronThreshold * 1.000001;   // * 1.000001 to avoid numerical problems // The multiplication of any synapse cannot exceed the postsynaptic threshold because in this case multiplication will substitute conductances that include information about uniqueness of the stimulation
                // While updating in the batch mode we cannot update the weight here because the multiplication has not changed!
                //ComputeWeight(currentSimTime);
                //if (animate)
                //    if (view.CreatedView) View.UpdateWeightView();
                return true;    // Multiplied
            }
            return false;    // Didn't multiply
            //return multiplication;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void MultiplicationCntrInit()
        {
            noAllStimulations = 0;
            noMultiplicationChanges = 0;
            sumMultiplicationChanges = 0;
            minMultiplicationChange = 0;
            //Logger.LogLine(String.Format("Initialization of noAllStimulations, noMultiplicationChanges and sumMultiplicationChanges of synapse {0} ", name));
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void MultiplicationUpdate(UInt16 tuningPhaseCntr)
        {
            //Logger.LogLine(String.Format("noAllStimulations of {0} is {1}", name, noAllStimulations));
            if (noMultiplicationChanges > 0)  // if (noAllStimulations > 0)
            {
                if (presynVertex.Type == VertexType.neuron)
                {
                    //Logger.LogLine(String.Format("noMultiplicationChanges of {0} is {1}:", name, noMultiplicationChanges));
                    //if (noMultiplicationChanges > 0)
                    //{
                    //if (tuningOffCycles == 0)
                    //{
                    //Logger.LogLine(String.Format("sumMultiplicationChanges of {0} is {1}:", name, sumMultiplicationChanges));
                    //Logger.LogLine(String.Format("Recent multiplication of {0} is {1} and weight = {2}", name, multiplication, weight));
                    //multiplication = (sumMultiplicationChanges + multiplication * (noAllStimulations - noMultiplicationChanges)) / noAllStimulations;
                    //++++++if () multiplication = sumMultiplicationChanges / noMultiplicationChanges; 
                    //++++++else multiplication = minMultiplicationChange;
                    //multiplication = sumMultiplicationChanges / noMultiplicationChanges;
                    //DZIAŁAŁOaleSKRACAŁO:multiplication = minMultiplicationChange;   //++++++ Na początku idziemy ze zmianami małymi kroczkami (nie średnią a po minimum, żeby nie doszło do hiperaktywacji w sieci. Jeśli to nie poskutkuje, można po jakimś czasie (10-50 cykli przełączyć na średnią).

                    // Stopniowo przechodź od korekty względem minimalnej zmiany do średniej zmiany:
                    //if (tuningPhaseCntr < 5) multiplication = minMultiplicationChange;  // Tak musi być na początku, bo inaczej dochodzi do hiperaktywności sieci
                    //else if (tuningPhaseCntr < 10) multiplication = (3 * minMultiplicationChange + sumMultiplicationChanges / noMultiplicationChanges) / 4;
                    //else if (tuningPhaseCntr < 15) multiplication = (minMultiplicationChange + sumMultiplicationChanges / noMultiplicationChanges) / 2;
                    //else if (tuningPhaseCntr < 20) multiplication = (minMultiplicationChange + 3 * sumMultiplicationChanges / noMultiplicationChanges) / 4;
                    //else multiplication = sumMultiplicationChanges / noMultiplicationChanges;

                    if (tuningPhaseCntr < 5) multiplication = minMultiplicationChange;  // Tak musi być na początku, bo inaczej dochodzi do hiperaktywności sieci
                    else if (tuningPhaseCntr < 10) multiplication = (3 * minMultiplicationChange + sumMultiplicationChanges / noMultiplicationChanges) / 4;
                    else multiplication = (minMultiplicationChange + sumMultiplicationChanges / noMultiplicationChanges) / 2;

                    ComputeMultiplicationChange();
                    ComputeWeight();
                    //Logger.LogLine(String.Format("New multiplication of {0} = {1} and new weight = {2}", name, multiplication, weight));
                    
                    //}
                    //else tuningOffCycles--;
                    //}
                }
                noMultiplicationChanges = 0;
                sumMultiplicationChanges = 0;
                minMultiplicationChange = 0;
            }
            noAllStimulations = 0;
            //noMultiplicationChanges = 0;
            //sumMultiplicationChanges = 0;
            //Logger.LogLine(String.Format("Next, Initialization of noAllStimulations, noMultiplicationChanges and sumMultiplicationChanges of synapse {0} ", name));
            //return multiplication;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void AddEvents(Vertex sender, ActionType action, UInt64 currentTime)
        {
            if (action == ActionType.stimulate)
            {
                // Compute the number of events on the basis of bodySize, speed of animation and compute the intervals between following events
                //+ CONTINUE...

                // Add series of update events that will propagate the signal through out the connection to presynaptic element, next through the synapse, and finaly through postsynaptic element
                events.AddEvent(sender, this, currentTime);
                //+ CONTINUE...
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------------------------------------------

        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class Neuron : Vertex // Associative Neuron
    {
        #region DEFINITION OF ENUMERICAL TYPES
        public enum InternalState : sbyte
        {
            Nascent = -100,
            AbsRefraction = -2,
            RelRefraction = -1,
            Resting = 0,
            RestingPlasticity = 1,
            Charging = 2,
            Relaxation = 3,
            Suppression = 4,
            Activation = 100,
        }
        public enum ActivationMoments : sbyte
        {
            none = -3,          // Not defined, used for initialization only
            incorrect = -2,     // Activation happens for neurons which should to achieve activation threshold for the given context
            checking = -1,      // Used in situations when we don't know whether the activation moment is correct because we have to wait for the sensory tuning stimulus
            notachieved = 0,    // The stimulation is too weak to achieve stimulation by this neuron which should be activated for this context
            correct = 1,        // The activation was achieved in the correct moment for this context
            corrected = 2,      // The multiplication factors and weights had been incorrect but they have been immediately corrected so they should not been corrected once again
            correctlater = 3,   // The correction were computed but not implemented; the implementation of the corrections will be made at the end of the tuning phase on the basis of the average correction computed
            uncorrectable = 4,  // It is treated as being correct because there is no context that can be used to make internal stimulation stronger
            toofast = 5,        // The activation was achieved too fast, i.e. for the part of the context
        }
        #endregion DEFINITION OF ENUMERICAL TYPES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        //protected static readonly UInt16 periodCreating = 500;
        #endregion CONST AND READONLY FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region STATIC FIELDS
        protected static UInt32 counter;         // Counts up all synapses
        protected static UInt32 activityNoMax;   // Maksimum of activity number
        protected static double maxThreshold;
        protected static double trainingCoefficient;
        //protected static UInt32 noCycleThresholdChanges;    // Number of threshold changes during an actual adaptation phase
        //protected static double growThresholdCoefInitial; // threshold growth coefficient
        protected static Int32 numberMaxInSynapses;  // The maximum from the numbers of input synapses of all neurons
        protected static UInt32 noIncompleteContextActivations;
        protected static UInt32 insufficientStimulationsNo;
        protected static UInt32 noUndesiredActivations;
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        //protected NeuronView view;            // The view of this neuron
        protected List<Synapse> inSynapses;     // list of input synapses connected to this neuron (to its dendrites)
        protected List<Synapse> outSynapses;    // list of output synapses connected to this neuron (to its akson)
        Synapse lastSender;                     // specifies the last sender which grew the xMax at last and represents the sequential associative connection. This last sender should finally activate the neuron, but the previous stimuli should not do it!
        protected double xMax;                  // the maximum level of excitation that is used to update the threshold > xMax to avoid too early activations
        protected double xMaxContext;           // the maximum level of excitation for the context connections without the last stimulation which should overshoot the activation threshold
        protected double threshold;             // threshold of the neuron should be associated to the activity of the neuron, reducing its sensitivity for weaker combinations of input stimuli and simultaneously specializing the sensitiveness of this neuron
        protected double thresholdAcceleration; // This value is used for accelerating intervals of internal neuron operation accordingly to the 3rd square of the activation threshold. Bigger neurons are faster and less sensitive and take into account shorter context of previous activations as well
        //protected Event eventThresholdPlasticity;   // This Event is determined by the excitation level of the neuron that achieves the threshold potentialy too fast, so this event checks after some time if it is really so?
        protected UInt32 activityNo;             // eta = an activity number of the neuron => It should influence the threshold of this neuron. More active neurons should rise the threshold (logaritmically, sqrt, ...) in order to specialize and react to less number of input combinations
        protected double xCharge;               // defines the currently charged value of excitation (>0) or inhibition (<0). If charging process is finished this variable is equal 0
        double xIntermediateChange;             // measures the actually charged level from the last external stimulation (intermediate levels of the charge) for updating the internal state of the neuron
        protected InternalState state;          // Actual state of the neuron
        protected bool activePlasticity;        // true - neuron is ready and active for plasticity processes with other vertices
        protected UInt64 timePreviousActivation;// Neuron previous activation (spike) time - It is necessary to diffentiate neurons which are activated more than once in the sequence!     
        protected ActivationMoments activationMoment;   // Defines whether the activation moment of the neuron was correct, incorrect, too fast or not happened when it should happen
        protected UInt32 thresholdChangesNo;     // Number of this threshold changes during an actual adaptation phase
        protected UInt32 periodCharge;          // The real computed time of charging the neuron accordingly to the input stimuli, not taking into account the threshold that can interrupt the action and make it shorter. This is necessary for recomputation of time when another charging or inhibiting signal comes before the threshold and time have to be recomputed accordingly to this not action time!
        protected UInt32 periodCharging;        // Individual charging time of the neuron that changes accordingly to the activity and threshold
        protected UInt32 periodRelaxing;        // Individual relaxation time of the neuron that changes accordingly to the activity and threshold (for its recovery and returning back to its resting state)
        protected UInt32 periodActivation;      // Individual activation time of the neuron
        protected UInt32 periodAbsRefracting;   // Individual absolute refraction time of the neuron that changes accordingly to the activity and threshold
        protected UInt32 periodRelRefracting;   // Individual relative refraction time of the neuron that changes accordingly to the activity and threshold (for its recovery and returning back to its resting state)
        protected UInt32 periodPlasticityMin;   // The minimum interval of time that have to elapse between activation of presynaptic and postsynaptic neuron to treat them as successive and connect
        protected UInt32 periodPlasticityMax;   // The minimum interval of time that have to elapse between activation of presynaptic and postsynaptic neuron to treat them as successive and connect
        protected UInt32 periodTuning;          // The time of tuning after activation
        protected UInt64 timeStopTuning;        // Determines the time when the tuninig plasticity is stopped
        //protected UInt32 periodPlasticity;    // The period of time after activation when neuron is plastic and cando the changes in weights
        protected UInt64 timeStopPlasticity;    // Time when the plasticity of this neurons is stoped
        Vertex lastExternalSender;              // The node of the ANAKG graph that has stimulated this neuron as the last: It is used to distinguish external/sensory teaching signals when updating the threshold
        //double growThresholdCoef;               // threshold growth coefficient
        double multiplyProposal;                // It is used to adapt only the first proposals of multiplication changes which are not influenced by the follow-up stimulations coming usually from incorrectly activated neurons
        UInt64 multiplyProposalApprovalTime;    // It is used to notify when the proposed changes of multiplication factors of synapses should be approved 
        //UInt16 uncorrectedCases;                // It is used for repetition of the tuning process for the given sequence when not all overstimulations were corrected at once!
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES 
        static public Int32 NumberMaxInSynapses
        {
            get { return numberMaxInSynapses; }
            set { numberMaxInSynapses = value; } // Initialize
        }
        static public UInt32 Counter
        {
            get { return counter; }
            set { counter = value; }
        }
        static public UInt32 ActivityNoMax
        {
            get { return activityNoMax; }
            set { activityNoMax = value; }
        }
        //static public double GrowThresholdCoefInitial
        //{
        //    get { return growThresholdCoefInitial; }
        //    set { growThresholdCoefInitial = value; }
        //}
        //static public void NullCycleThresholdChanges()
        //{
        //    noCycleThresholdChanges = 0;
        //}
        //static public UInt32 NoCycleThresholdChanges
        //{
        //    get { return noCycleThresholdChanges; }
        //}
        static public double MaxThreshold
        {
            get { return maxThreshold; }
            set { maxThreshold = value; }
        }
        static public void NullNoIncompleteContextActivations()
        {
            noIncompleteContextActivations = 0;
        }
        static public UInt32 NoIncompleteContextActivations
        {
            get { return noIncompleteContextActivations; }
        }
        static public void NullNoUndesiredActivations()
        {
            noUndesiredActivations = 0;
        }
        public static UInt32 NoUndesiredActivations
        {
            get { return noUndesiredActivations; }
        }
        static public void NullInsufficientStimulationsNo()
        {
            insufficientStimulationsNo = 0;
        }
        static public UInt32 InsufficientStimulationsNo
        {
            get { return insufficientStimulationsNo; }
        }
        public static double TrainingCoefficient
        {
            get { return trainingCoefficient; }
            set { trainingCoefficient = value; }
        }
        public double XtoThreshold
        {
            get { return x / threshold; }
        }
        public UInt32 PeriodPlasticityMin
        {
            get { return periodPlasticityMin; }
        }
        public UInt32 PeriodPlasticityMax
        {
            get { return periodPlasticityMax; }
        }
        public double XCharge
        {
            get { return xCharge; }
        }
        public string ChargedProc
        {
            get { return ((sbyte)(100 * x / threshold)).ToString(); }
        }
        public double Threshold
        {
            get { return threshold; }
        }
        public UInt32 ActivityNo
        {
            get { return activityNo; }
        }
        public List<Synapse> InSynapses
        {
            get { return inSynapses; }
        }
        public List<Synapse> OutSynapses
        {
            get { return outSynapses; }
        }
        public UInt32 PeriodCharging
        {
            get { return periodCharging; }
        }
        public UInt32 PeriodRelaxation
        {
            get { return periodRelaxing; }
        }
        public UInt32 PeriodAbsRefraction
        {
            get { return periodAbsRefracting; }
        }
        public UInt32 PeriodRelRefraction
        {
            get { return periodRelRefracting; }
        }
        public InternalState State
        {
            get { return state; }
        }
        public double XChargeView
        {   // Used for filling the sphere representing this neuron
            get { return (xCharge * xCharge) / (threshold * threshold); }
        }
        public UInt64 TimePreviousActivation
        {
            get { return timePreviousActivation; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public Neuron(UInt64 simtimeCreation, Vertex creator, string name = null) : base(simtimeCreation, name)
        {
            counter++;
            type = VertexType.neuron;
            inSynapses = new List<Synapse>();
            outSynapses = new List<Synapse>();
            threshold = 1.0;
            thresholdAcceleration = 1.0;
            thresholdChangesNo = 0;
            xCharge = 0.0;
            periodCharge = 0;
            xIntermediateChange = 0.0;
            activityNo = 0; // New neuron is once activate by external stimuli that has created it
            activeEvent = null; // At the beginning there is no active event that is in the events sorted priority queue
            // Logger.LogLine(String.Format("NEW NEURON {0} ADDED", Name));
            periodCharging = 3000;             // Initial value will be shorten when neuronal activity rise; from almost 0 (dependently on the strength) to a few msec in real biological neurons
            periodRelaxing = 35000;   //20000 - too fast! // 50000 to 100000; // Initial value will be shorten when neuronal activity rise; from a few to tens of msec in real biological neurons [The action potential in mammalian central neurons, Bruce P. Bean, Nature Reviews Neuroscience 8, 451 - 465(June 2007), doi: 10.1038 / nrn2148]
            periodActivation = 1000;           // Initial value will be shorten when neuronal activity rise; from 0,18 (in the biggest Purkinje neurons) to 1msec (in regular spiking neurons) to 2 msec (in dopaminergic neurons)) together with absolute refraction in real biological neurons (the time to the top of the peak)
            periodAbsRefracting = 2000;        // Initial value will be shorten when neuronal activity rise; from 1 to 2 msec (to 5 msec in dopaminergic neurons) in real biological neurons (interval between the top of the peak to the moment when relative refraction starts)
            periodRelRefracting = 17000;      //For 11000 words are not repeated! // 50000;  // Initial value will be shorten when neuronal activity rise; from 3 msec to 15 msec (usually), a few (5 msec in normaly active neurons) to tens of msec (in small new neurons) in real biological neurons
            periodPlasticityMin = periodActivation + periodAbsRefracting;           //!+ Proposal, but it has to be changed regardless to the threshold changes as well
            periodPlasticityMax = (UInt32)(1 * periodRelaxing * threshold);     //!+ Proposal, but it has to be changed regardless to the threshold changes as well
            periodTuning = 20000;
            timeStopTuning = 0;
            timeStopPlasticity = 0;
            timeActivation = 0;
            activationMoment = ActivationMoments.none;
            timePreviousActivation = 0;
            state = InternalState.Nascent;
            activePlasticity = false;
            // Add this neuron to the neuron sort list of ANAKG
            anakg.Neurons.Add(name, this);
            // Add event that will create the view of this neuron
            activeEvent = events.AddEvent(creator, this, simtimeCreation);   // Sensory input has not found existing sensor/neuron representing this word, so it has initiated creation of this neuron
            //growThresholdCoef = growThresholdCoefInitial;    //
            //view = new NeuronView(this);
            lastSender = null;
            xMax = 0;
            xMaxContext = 0;
            multiplyProposal = 0;
            //uncorrectedCases = 0;
            multiplyProposalApprovalTime = 0;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        //protected void CountThresholdChange()
        //{
        //    noCycleThresholdChanges++;
        //    thresholdChangesNo++;
        //    if (animate) View.ViewThresholdChange();   // if (view != null)
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        public void InitCntrSynapticMultiplicationFactors()
        {
            foreach (Synapse synapse in inSynapses)
                synapse.MultiplicationCntrInit();
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void UpdateSynapticMultiplicationFactors(UInt16 tuningPhaseCntr)
        {
            //Logger.LogLine(String.Format("Update synapses for neuron {0}:", name));
            foreach (Synapse synapse in inSynapses)
                synapse.MultiplicationUpdate(tuningPhaseCntr);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected double UpdateInternalChargeLevel(UInt64 currentSimTime)
        {
            // 1. Subtract the intermediate charging level computed in previous step acordingly to the last updateTime
            x -= xIntermediateChange;
            // 2. Now, compute a new intermediate charge in the current time
            xIntermediateChange = xCharge * Math.Sin(Math.PI * (currentSimTime - actionBeginTime) / (2 * (double)periodCharge)); // actionInterval Computed after previous x and up to know charge value of this neuron
            //if (xIntermediateChange <= 0) // Logger.LogLine(String.Format("ERROR: UNEXPECTED VALUE OF INTERMEDIATE CHANGE OF NEURON {0} HAS BEEN DETECTED AT SIMTIME {1} !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Name, currentSimTime));
            // 3. Update the internal state of this neuron in order to appropriately view its state in the graphical interface
            x += xIntermediateChange;   // New updated x value in simTime
            // Update internal state of the neuron and the // Logger output
            state = InternalState.Charging;  // GREEN VIEW, Content = level of charging (numerical)
            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN PARTLY CHARGED TO {1} AT SIMTIME {2}", Name, x, currentSimTime)); // currentSimTime?
            // 4. Update view of the neuron
            
            // 5. Compute the rest of charge that has not been yet charged and should be charged in the future
            return xCharge - xIntermediateChange;  // xRest
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected double UpdateInternalSuppressionLevel(UInt64 currentSimTime)
        {
            // 1. Subtract the intermediate charging level computed in previous step acordingly to the last updateTime
            x -= xIntermediateChange;
            // 2. Now, compute a new intermediate charge in the current time
            //xIntermediateChange = xCharge * (((1 + Math.Cos(Math.PI * (currentSimTime - actionBeginTime) / (double)actionInterval)) / 2) - 1);  //periodRelaxing// x has been already partly recovered to this new value
            xIntermediateChange = xCharge * ((Math.Cos(Math.PI * (currentSimTime - actionBeginTime) / (double)actionInterval) - 1) / 2);
            // 3. Update the internal state of this neuron in order to appropriately view its state in the graphical interface
            x += xIntermediateChange;   // New updated x value in simTime
            // Update internal state of the neuron and the // Logger output
            state = InternalState.Suppression;  // GREEN VIEW, Content = level of charging (numerical)
            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN PARTLY CHARGED TO {1} AT SIMTIME {2}", Name, x, currentSimTime)); // currentSimTime?
            // 4. Update view of the neuron
            
            // 5. Compute the rest of charge that has not been yet charged and should be charged in the future
            return xCharge - xIntermediateChange;  // xRest
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void UpdateInternalRelaxLevel(UInt64 currentSimTime)
        {
            // 1. Subract intermediate relaxatio or refraction in order to computed an updated one
            x -= xIntermediateChange;
            // 2. Now compute a new intermediate relaxation or refraction in the current time
            //xIntermediateChange = x * (((1 + Math.Cos(Math.PI * (currentSimTime - actionBeginTime) / (double)actionInterval)) / 2) - 1);  //periodRelaxing// x has been already partly recovered to this new value
            xIntermediateChange = x * ((Math.Cos(Math.PI * (currentSimTime - actionBeginTime) / (double)actionInterval) - 1) / 2);
            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN RELAXED TO {1} AT SIMTIME {2}", Name, x, currentSimTime)); // currentSimTime?
            state = InternalState.Relaxation;
            // 3. Update the internal state of this neuron in order to appropriately view its state in the graphical interface
            x += xIntermediateChange;
            if (x < 0) x = 0;
            // 4. Update view of the neuron
            
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void UpdateInternalActivationLevel(UInt64 currentSimTime)
        {
            // 1. Subract intermediate refraction in order to computed an updated one
            x -= xIntermediateChange;
            // 2. Now compute a new intermediate refraction in the current time
            xIntermediateChange = 6 * threshold * (currentSimTime - actionBeginTime) / (double)actionInterval; //periodActivation x has been already partly refracted to this new value
            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN REFRACTED TO {1} AT SIMTIME {2}", Name, x, currentSimTime)); // currentSimTime?
            state = InternalState.Activation;
            // 3. Update the internal state of this neuron in order to appropriately view its state in the graphical interface
            x += xIntermediateChange;
            // 4. Update view of the neuron
            
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void UpdateInternalAbsRefractLevel(UInt64 currentSimTime)
        {
            // 1. Subract intermediate refraction in order to computed an updated one
            x -= xIntermediateChange;
            // 2. Now compute a new intermediate refraction in the current time
            xIntermediateChange = -2 * x * ((currentSimTime - actionBeginTime) / (double)actionInterval); //periodAbsRefracting x has been already partly refracted to this new value
            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN REFRACTED TO {1} AT SIMTIME {2}", Name, x, currentSimTime)); // currentSimTime?
            state = InternalState.AbsRefraction;
            // 3. Update the internal state of this neuron in order to appropriately view its state in the graphical interface
            x += xIntermediateChange;
            // 4. Update view of the neuron
            
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void UpdateInternalRelRefractLevel(UInt64 currentSimTime)
        {
            // 1. Subract intermediate refraction in order to computed an updated one
            x -= xIntermediateChange;
            // 2. Now compute a new intermediate refraction in the current time
            xIntermediateChange = x * (-1 - (Math.Tan((((currentSimTime - actionBeginTime) / (double)actionInterval) - 1) * Math.Atan(1)))); //periodRelRefracting x has been already partly refracted to this new value
            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN REFRACTED TO {1} AT SIMTIME {2}", Name, x, currentSimTime)); // currentSimTime?
            state = InternalState.RelRefraction;
            // 3. Update the internal state of this neuron in order to appropriately view its state in the graphical interface
            x += xIntermediateChange;
            // 4. Update view of the neuron
            
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void SwitchToPlasticityRestingState(UInt64 currentSimTime)    // The plasticity period starts at the activation time
        {
            x = 0;
            xIntermediateChange = 0;
            xCharge = 0;
            periodCharge = 0;
            // Logger.LogLine(String.Format("NEURON {0} HAS ACHIEVED RESTING STATE AT SIMTIME {1}", Name, currentSimTime)); // currentSimTime?
            if (IsTuning) state = InternalState.RestingPlasticity; // Only for Tuning Phase
            else state = InternalState.Resting; // For cycles: Create & Ask
            
            // NO NEXT INTERNAL PROCESS IS STARTED
            actionInterval = 0;
            actionBeginTime = currentSimTime;   // it is the time when resting has started
            actionSteps = 0;    // how much msec it takes, so we update the state each msec
            actionStepInterval = 0;
            actionStepCntr = 0;
            activeEvent = null;

            //if (uncorrectedCases > 0) activationMoment = ActivationMoments.incorrect;
            //else activationMoment = ActivationMoments.correct;
            // The above code must be processed before the following method because the uncorrectedCases is initialized inside!
            //AvoidIncorrectActivations(currentSimTime);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void SwitchToInternalRestingState(UInt64 currentSimTime)
        {
            x = 0;
            xIntermediateChange = 0;
            xCharge = 0;
            periodCharge = 0;
            // Logger.LogLine(String.Format("NEURON {0} HAS ACHIEVED RESTING STATE AT SIMTIME {1}", Name, currentSimTime)); // currentSimTime?
            //if (currentSimTime >= plasticityTime) state = InternalState.Resting;
            //else state = InternalState.RestingPlasticity;

            //anakg.NoIncorrectSeqActivations += uncorrectedCases + noIncompleteContextActivations + noUndesiredActivations; // Czemu to służy tutaj?
            //uncorrectedCases = 0;
            //if (uncorrectedCases > 0) activationMoment = ActivationMoments.incorrect;
            //else activationMoment = ActivationMoments.correct;
            // The above code must be processed before the following method because the uncorrectedCases is initialized inside!
            if (IsTuning)   //+++++ only for U and E, not for C tuning phase
                AvoidIncorrectActivations(currentSimTime);
            //++++ It was computed in the above method but not added?: anakg.NoIncorrectSeqActivations += uncorrectedCases;

            InitializeActivityParameters(); //++++ Dodane by przeciwdziałać podwójnemy AvoidIncorrectActivations, np. dla HAVE w I HAVE A MONKEY
            // Finally, we can initialize internal variables:
            //if ((currentSimTime >= timeStopTuning) || (xMax == 0))  // xMax == 0 suggests that the update of the weights was already done after the tuning stimulus!
            if ((IsCreating || IsAsking) || (currentSimTime >= timeStopTuning) || (activationMoment == ActivationMoments.uncorrectable) || (activationMoment == ActivationMoments.correct)) //|| (xMax == 0))  // xMax == 0 suggests that the update of the weights was already done after the tuning stimulus!
            {
                // NO NEXT INTERNAL PROCESS IS STARTED
                actionInterval = 0;
                actionBeginTime = currentSimTime;   // it is the time when resting has started
                actionSteps = 0;    // how much msec it takes, so we update the state each msec
                actionStepInterval = 0;
                actionStepCntr = 0;
                activeEvent = null;
                //InitializeActivityParameters(); było zduplikowane z powyższym
                state = InternalState.Resting;
                
            }
            else
            {
                // THE PLASTICITY IS STILL ACTIVE AND POSSIBLE UNTIL
                activeEvent = events.AddEvent(this, this, timeStopTuning);  // After this time, this method will be executed once again to initialize Activity Parameters!
                state = InternalState.RestingPlasticity;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void WeakenTooLargeWeights(UInt64 currentSimTime, Vertex sender)
        {
            //+++ It is necessary to use xMaxContext here!!!

            //! It should be executed only in the Tuning mode
            //if (modePlasticity == PlasticityMode.tune)
            //{
            if (((Synapse)sender).PresynVertex.Type != VertexType.neuron) // The sensory training stimulus came so the too fast activations must be find out and the weights must be decreased.
            {   // The stimulation came from a sensor (training/tuning stimulus)
                //if (threshold < xMax)   // UNNECESSARY: While this is obvious because this method is called when this neuron is absolute refreaction, relative refraction or activation state
                //{
                // BE CAREFUL AND CAUTIOUS because changing of this code can maybe spoil the algorithm in other cases when correcting this one! Must be checked!!!

                if ((multiplyProposal > 0) && (multiplyProposalApprovalTime <= currentSimTime))
                {
                    if ((xMaxContext < threshold) && (xMax >= threshold))
                    {
                        // It is correct, so the proposals are forgoten and not implemented
                        multiplyProposal = 0;
                        activationMoment = ActivationMoments.correct;
                    }
                    else if (IsTuning)        // (IsAvoidingTooEarly || IsTuningConflicts)
                    {
                        multiplyProposal = 0;
                        if (xMaxContext >= threshold)
                        {
                            if ((noIncompleteContextActivations == 0) && (noUndesiredActivations == 0))    // Poprawiamy tylko pierwsze takie wystąpienie, bo inne mogą być pod jego wpływem
                            {
                                // Forgot the proposals and compute immediately the changes for contextual connections only
                                double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
                                foreach (Synapse synapse in inSynapses)
                                {
                                    if ((synapse != sender) && (synapse != lastSender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                                    {
                                        //synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                        synapse.MultiplyImmediately(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                    }
                                }

                            }

                            // DODANE ŻEBY ZABLOKOWAĆ KILKUKROTNE ZMIANY TYCH SAMYCH WAG PRZEZ AvoidIncorrectActivations:
                            //InitializeActivityParameters(); //???
                            //???? uncorrectedCases++;
                            noIncompleteContextActivations++;    // Po co to zlicza, skoro nigdzie nie jest wykorzystane?!
                        }
                        else // Check whether this else has sense any more?!
                        {
                            //Logger.LogLine(String.Format("WeakenTooLargeWeights of neuron {0} when multiplyProposal == {1} > 0 after Receptor stimulation:", name, multiplyProposal));
                            foreach (Synapse synapse in inSynapses)
                            {
                                if (synapse != sender) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                                    synapse.MultiplyProposalAdapt(); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                            }

                            // DODANE ŻEBY ZABLOKOWAĆ KILKUKROTNE ZMIANY TYCH SAMYCH WAG PRZEZ AvoidIncorrectActivations:
                            //InitializeActivityParameters(); //???
                            //???? uncorrectedCases++;
                            activationMoment = ActivationMoments.corrected;
                            //noIncompleteContextActivations++;
                        }
                    }
                }
                else if (IsTuning)  // (IsAvoidingTooEarly || IsTuningConflicts)
                {
                    if (threshold <= xMaxContext)    // else the situation is correct, i.e. when threshold > xMaxContext, the training stimulus confirmes the right situation
                    {
                        //Logger.LogLine(String.Format("WeakenTooLargeWeights of neuron {0} when multiplyProposal == 0 and threshold <= xMaxContext = {1} (too fast activation) after Receptor stimulation:", name, xMaxContext));
                        // The stimulation is too strong and the weights must be decreased
                        double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
                        foreach (Synapse synapse in inSynapses)
                        {
                            if ((synapse != sender) && (synapse != lastSender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                            {
                                //synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                synapse.MultiplyImmediately(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                            }
                        }
                        //! If not MultiplyImmediately but Multiply we could not update xMax and xMaxContext!
                        // After the change we have to weaken the xMax and xMaxContext adapting it to the new weights after this immediate change! We do it in order to take into account corrected xMax ana xMaxContext values for the next possible stimulation of this neuron!
                        xMax -= xMaxContext;        // Here, we subtract the current xMaxContext which was >= threshold
                        xMaxContext *= multiply;    // Here, we adapt it according to the computed multiply factor
                        xMax += xMaxContext;        // Here, we add the updated xMaxContext to correctly compute the change of xMax

                        noIncompleteContextActivations++;

                        //Logger.LogLine(String.Format("Update xMax = {0} and xMaxContex = {1} of neuron {2}", xMax, xMaxContext, name));
                        activationMoment = ActivationMoments.correct;   // After the immediate change it is treated as corrected
                  
                    }
                    else
                    {
                        //Logger.LogLine(String.Format("Don't WeakenTooLargeWeights of neuron {0} because ActivationMoments.correct", name));
                        activationMoment = ActivationMoments.correct;   // Before doing it the previous preposals of changes must be done
                                                                        //multiplyProposal = 0;  //? May be it should be left until the end of the tuning of this sequence? // The proposals will not be taken into account because the tuning stimulation came so the neuron was correctly activated in the right order!
                    }
                }
                //}
                // else cannot happen because we go to this method only when the neuron was recently activated (it is in absolute or relative refraction pediod or during activation)
                //xMax = x;
                //++++ PO CO POWYŻEJ AKTUALIZUJĘ STAN xMax skoro tutaj poniżej go zeruję:
                lastSender = null;
                //++++++ Prawdopodobnie tu jest problem z VERY, dla którego zerowane jest xMax i nie może dokonać jego AvoidUndesiredActivations
                xMax = 0;   //? This value should be better in this context than x because sensory stimulations return back its excitation to x = 0 so xMax should be 0 as well.
                xMaxContext = 0;
                //? InitializeActivityParameters();
            }
            else if (IsTuning)  //  (IsAvoidingTooEarly || IsTuningConflicts) // The stimulation came from a neuron
            {   // It is executed for neurons which were activated too fast and it was detected by the stimulus coming from other neurons, so ALL input stimuli should be weaken to avoid such situations
                if (threshold <= xMax) // The stimulation is too large anyway, i.e. the subcontext is enough to activate the neuron, so the weights must be decreased!
                {
                    if (multiplyProposal == 0)
                    {
                        if ((noIncompleteContextActivations == 0) && (noUndesiredActivations == 0))    // Poprawiamy tylko pierwsze takie wystąpienie, bo inne mogą być pod jego wpływem
                        {
                            //uncorrectedCases = 0;
                            // The stimulation is too strong and the weights must be decreased
                            multiplyProposal = threshold / (xMax + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
                                                                            //Logger.LogLine(String.Format("WeakenTooLargeWeights of neuron {0} when multiplyProposal == {1} > 0 after Neuron stimulation:", name, multiplyProposal));
                            foreach (Synapse synapse in inSynapses)
                            {
                                if ((synapse != sender) && (synapse.PresynVertex.Type == VertexType.neuron)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                                {    //synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                    if (IsAvoidingIncorrect)  // (IsAvoidingTooEarly)
                                    {
                                        synapse.MultiplyImmediately(currentSimTime, multiplyProposal);
                                    }
                                    else if (synapse.MultiplyProposal(currentSimTime, multiplyProposal)) //; // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                    {
                                        multiplyProposalApprovalTime = currentSimTime + anakg.DelayFollowingObjectLearn;
                                        //activationMoment = ActivationMoments.correct;   // This avoid updating the synapse once again in the method AvoidIncorrectActivations
                                        activationMoment = ActivationMoments.checking;   // This avoid updating the synapse once again in the method AvoidIncorrectActivations
                                    }
                                }
                            }
                            if (IsAvoidingIncorrect)  // (IsAvoidingTooEarly)
                            {
                                multiplyProposal = 0;
                                activationMoment = ActivationMoments.corrected;
                            }
                        }
                        noIncompleteContextActivations++;
                        // After the change we have to weaken the xMax and xMaxContext adapting it to the new weights after this immediate change!  We do it in order to take into account corrected xMax ana xMaxContext values for the next possible stimulation of this neuron!
                        // I cannot do if for proposal because when the other stimulation comes it the new multiply factor will be computed incorrectly xMax *= multiply;   //? for MultiplyProposal???
                        // I cannot do if for proposal because when the other stimulation comes it the new multiply factor will be computed incorrectly xMaxContext *= multiply;    //? for MultiplyProposal???
                        //activationMoment = ActivationMoments.toofast;
                        //if (animate)
                        //{
                        //    foreach (Synapse synapse in inSynapses)
                        //    {
                        //        synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
                        //    }
                        //}
                    }
                    //else;// uncorrectedCases++; // count up uncorrected cases to repeat the tuning process for this training sequence  // else ignore it because the follow-up stimulations usually come from the incorrectly activated neurons and will spoil the tuning process. If necessary the changes will be done in the next tuning phase
                }
            }
            //else // The stimulation came from neuron
            //{
            //    if (threshold <= xMaxContext) // The stimulation is too large anyway, i.e. the subcontext is enough to activate the neuron, so the weights must be decreased!
            //    {
            //        // The stimulation is too strong and the weights must be decreased
            //        double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
            //        foreach (Synapse synapse in inSynapses)
            //        {
            //            if ((synapse != sender) && (synapse.PresynVertex.Type == VertexType.neuron)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
            //                synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
            //        }
            //        activationMoment = ActivationMoments.toofast;
            //        if (animate)
            //        {
            //            foreach (Synapse synapse in inSynapses)
            //            {
            //                synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
            //            }
            //        }
            //    }
            //}
            //}
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        //protected void WeakenTooLargeWeights(UInt64 currentSimTime, Vertex sender)
        //{
        //    //+++ It is necessary to use xMaxContext here!!!

        //    //! It should be executed only in the Tuning mode
        //    //if (modePlasticity == PlasticityMode.tune)
        //    //{
        //    if (((Synapse)sender).PresynVertex.Type != VertexType.neuron) // The sensory training stimulus came so the too fast activations must be find out and the weights must be decreased.
        //    {
        //        //if (threshold < xMax)   // UNNECESSARY: While this is obvious because this method is called when this neuron is absolute refreaction, relative refraction or activation state
        //        //{
        //        if (threshold <= xMaxContext)    // else the situation is correct, i.e. when threshold > xMaxContext, the training stimulus confirmes the right situation
        //        {
        //            // The stimulation is too strong and the weights must be decreased
        //            double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
        //            foreach (Synapse synapse in inSynapses)
        //            {
        //                if ((synapse != sender) && (synapse != lastSender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
        //                    synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
        //            }
        //            activationMoment = ActivationMoments.toofast;
        //            if (animate)
        //            {
        //                foreach (Synapse synapse in inSynapses)
        //                {
        //                    synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                }
        //            }
        //        }
        //        else activationMoment = ActivationMoments.correct;
        //        //}
        //        // else cannot happen because we go to this method only when the neuron was recently activated (it is in absolute or relative refraction pediod or during activation)
        //        //xMax = x;
        //        lastSender = null;
        //        xMax = 0;   //? This value should be better in this context than x because sensory stimulations return back its excitation to x = 0 so xMax should be 0 as well.
        //        xMaxContext = 0;
        //    }
        //    else // The stimulation came from neuron
        //    {
        //        if (threshold <= xMaxContext) // The stimulation is too large anyway, i.e. the subcontext is enough to activate the neuron, so the weights must be decreased!
        //        {
        //            // The stimulation is too strong and the weights must be decreased
        //            double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
        //            foreach (Synapse synapse in inSynapses)
        //            {
        //                if ((synapse != sender) && (synapse.PresynVertex.Type == VertexType.neuron)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
        //                    synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
        //            }
        //            activationMoment = ActivationMoments.toofast;
        //            if (animate)
        //            {
        //                foreach (Synapse synapse in inSynapses)
        //                {
        //                    synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                }
        //            }
        //        }
        //    }
        //    //}
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        //protected void UpdateThreshold(UInt64 currentSimTime, Vertex sender)
        //{
        //    //+++ It is necessary to use xMaxContext here!!!



        //    if (modePlasticity == PlasticityMode.tune)
        //    {
        //        if (((Synapse)sender).PresynVertex.Type == VertexType.neuron)
        //        {
        //            if (threshold < xMax)
        //            {
        //                // The stimulation is too strong and the weights must be decreased
        //                double multiply = threshold / (xMax + 0.001);   // 0.001 to avoid numerical errors and the situation when threshold == xMax
        //                foreach (Synapse synapse in inSynapses)
        //                {
        //                    if ((synapse != sender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
        //                        synapse.Multiply(currentSimTime, multiply);
        //                }
        //                if (animate)
        //                {
        //                    foreach (Synapse synapse in inSynapses)
        //                    {
        //                        synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                    }
        //                }

        //                //double minMultiplication = xMax + 1.000001;    // This is only to initialize it
        //                //double multiplication;
        //                //// First decrease xMax by min value from all multiplications of all synapses if multiplications > 1
        //                //foreach (Synapse synapse in inSynapses)
        //                //{
        //                //    if (synapse != sender)
        //                //    {
        //                //        multiplication = synapse.GetMultiplicationOfActiveSynapse(currentSimTime);  // It returns 0 if synapse was not active and has taken no part in activation of this neuron.
        //                //        if ((multiplication > 0) && (multiplication < minMultiplication)) minMultiplication = multiplication;
        //                //    }
        //                //}
        //                //// Second increase threshold if this was not enought
        //                ////!!!? Review the following code:
        //                //if (minMultiplication > 1)
        //                //{
        //                //    foreach (Synapse synapse in inSynapses)
        //                //    {
        //                //        if (synapse != sender) synapse.DecreaseMultiplicationOfActiveSynapse(currentSimTime, minMultiplication);
        //                //    }
        //                //    //+ xMaxContext = ???
        //                //    xMax /= minMultiplication;  //! This equation does not take into account temporal and nonlinear influence of multiplications on xMax
        //                //}

        //                //if (threshold < xMax)   // If it is still true made necessary changes to the threshold
        //                //{
        //                //    //threshold = xMax + (threshold / 1000);  // where (threshold / 1000) is a small value that makes the new threshold a little bit bigger than the maximal excitation that made too early activation of this neuron
        //                //    // TUTAJ SIĘ DZIEJE ŹLE. Nie można tak zwiększać progu, gdy neuron jest już w stanie aktywacji. Wtedy kolejne sygnały nie mają znaczenia...
        //                //    // Może chciałem to załatwić za szybko i dodać wszystkie nadchodzące sygnały do czasu nadejścia sygnału uczącego, a trzeba to robić stopniowo, bo tutaj może być wiele fałszywych pobudzeń, które zostaną wyeliminowane w przyszłości, ale próg wzrośnie i tego się nie cofnie!
        //                //    //too fast: threshold = xMax + sender.Y / 2;  // we add here a half of the new stimulation because it enable us to avoid situations when any weight slightly changes and the threshold is again too small and over exceeded
        //                //    threshold += growThresholdCoef * ((xMax + sender.Y / 2) - threshold);  // we add here a half of the new stimulation because it enable us to avoid situations when any weight slightly changes and the threshold is again too small and over exceeded
        //                //    growThresholdCoef = Math.Sqrt(growThresholdCoef);   // Gradually grow this coefficient
        //                //    CountThresholdChange();
        //                //    if (threshold > maxThreshold) maxThreshold = threshold;
        //                //    //eventThresholdPlasticity = null;
        //                //    inSynapses.First().Permeability = threshold; // Updates weights for sensory connections in order to be able to activate neurons by sensors nevertheless of threshold changes. It models and responds to longer time sensors need to activate connected neurons
        //                //    thresholdAcceleration = Math.Pow(threshold, 1 / (double)3);
        //                //    if (animate)
        //                //    {
        //                //        //ChangeViewSize();
        //                //        View.UpdateViewShapeView();  // Change of neuron body size necessary?
        //                //        //UpdateThresholdView(); // When Asking update threshold view
        //                //                                // New xMax value has to be established because it is not guaranteed that this situation will not repeat again. This sender neuron has not to be the last one that wanted to stimulate this neuron before training external/sensory signal comes
        //                //    }
        //                //    xMaxContext = xMax;
        //                //    lastSender = (Synapse)sender;
        //                //    xMax += sender.Y;   // Here we add to the last xMax actual stimulation coming from the sender neuron. If the next neuronal stimulation comes the threshold could be updated again taking into account this updated xMax value.
        //                //}
        //                //if (animate)
        //                //{
        //                //    foreach (Synapse synapse in inSynapses)
        //                //    {
        //                //        synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                //    }
        //                //}

        //            }
        //        }
        //        else // Training sensory stimulation finishes the adapation process of the threshold for this neuron. It means that xMax should not grow further on.
        //        {
        //            if (threshold < xMax)
        //            {
        //                if (threshold <= xMaxContext)    // else the situation is correct, i.e. when threshold > xMaxContext, the training stimulus confirmes the right situation
        //                {
        //                    // The stimulation is too strong and the weights must be decreased
        //                    double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
        //                    foreach (Synapse synapse in inSynapses)
        //                    {
        //                        if ((synapse != sender) && (synapse != lastSender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
        //                            synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
        //                    }
        //                    activationMoment = ActivationMoments.toofast;
        //                    if (animate)
        //                    {
        //                        foreach (Synapse synapse in inSynapses)
        //                        {
        //                            synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                        }
        //                    }
        //                }
        //                else activationMoment = ActivationMoments.correct;
        //            }
        //            // else cannot happen because we go to this method only when the neuron was recently activated (it is in absolute or relative refraction pediod or during activation)
        //            //xMax = x;
        //            lastSender = null;
        //            xMax = 0;   //? This value should be better in this context than x because sensory stimulations return back its excitation to x = 0 so xMax should be 0 as well.
        //            xMaxContext = 0;
        //        }
        //    }
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        //protected void AvoidTooFastActivations(UInt64 currentSimTime, Vertex sender = null)
        //{
        //    //+++ It is necessary to use xMaxContext here!!!

        //    if (activationMoment != ActivationMoments.correct)
        //    {
        //        if (IsTuning)
        //            if (xMaxContext >= threshold)   //(xMax > threshold)
        //            {
        //                //+! It must be changed because it increases the noMultiplicationCorrects over noAllStimulations!!! and causes logical error!

        //                // The stimulation is too strong and the weights must be decreased
        //                // This is not a good solution: MUST BE REBUILD because if the average change suppresses such change, the thresold will be overshot again!
        //                double multiply = threshold / (xMaxContext + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMax
        //                //Logger.LogLine(String.Format("AvoidTooFastActivations of neuron {0} because (xMaxContext >= threshold) and this neuron should not be activated!", name));
        //                foreach (Synapse synapse in inSynapses)
        //                {
        //                    if ((synapse != sender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
        //                        synapse.Multiply(currentSimTime, multiply);
        //                }
        //                if (animate)
        //                {
        //                    foreach (Synapse synapse in inSynapses)
        //                    {
        //                        synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                    }
        //                }
        //                noIncompleteContextActivations++;
        //            }
        //    }
        //    lastSender = null;
        //    xMaxContext = 0;
        //    xMax = 0;   // If neuron achieves its resting state this factor should be always nulled before next training sequences.
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void AvoidIncorrectActivations(UInt64 currentSimTime, Vertex sender = null)
        {
            //+++ It is necessary to use xMaxContext somewhere here!!!
            if ((activationMoment != ActivationMoments.correct) && (activationMoment != ActivationMoments.corrected) && (activationMoment != ActivationMoments.uncorrectable))
            {
                if (IsTuning)
                {
                    if (xMax >= threshold)   //(xMax > threshold)   // Many correctly activated neurons have xMax = 0, while undesired activations satisfy this condition!
                    {                           // Some correctly activated neurons can also satisfy this condition
                        //Logger.LogLine(String.Format("AvoidIncorrectActivations of neuron {0} because (xMax >= threshold) and this neuron should not be activated!", name));

                        //+! It must be changed because it increases the noMultiplicationCorrects over noAllStimulations!!! and causes logical error!
                        // Use the computed multiplyProposal here to update multiplication factors:
                        if (multiplyProposal > 0)   // Adapt the proposed changes if they were proposed
                        {
                            //Logger.LogLine(String.Format("multiplyProposal > 0 of neuron {0} so we adapt the proposed multiplications for synapses:", name));
                            foreach (Synapse synapse in inSynapses)
                                if ((synapse != sender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                                    synapse.MultiplyProposalAdapt();
                            //InitializeActivityParameters();  Unnecessary here because will be called by the calling function
                            //++++ Zastanowić się czy poniższe nie powinno być wewnątrz powyższego ifa:
                            insufficientStimulationsNo++;   //?! Ja obniżam bo za dużo stymulowane a tu zlicza ilość niewystarczających?!
                        }
                        else // Propose and do the change here
                        {
                            // The stimulation is too strong and the weights must be decreased
                            //double multiply = threshold / (xMax + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMax
                            //Logger.LogLine(String.Format("multiplyProposal == 0 of neuron {0} so we compute and immediately adapt the multiply computed here as {1} for synapses:", name, multiply));
                            //foreach (Synapse synapse in inSynapses)
                            //{
                            //    if ((synapse != sender) && (synapse.PresynVertex.Type == VertexType.neuron)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                            //        synapse.MultiplyImmediately(currentSimTime, multiply); // synapse.Multiply(currentSimTime, multiply);
                            //}

                            // WCHODZI TUTAJ Z HAVE dla sekwencji I HAVE A MONKEY a potem nie poprawia, bo synapse != sender

                            //uncorrectedCases = 0;
                            // Poniższe dwa liczniki mają gwarantować, iż poprawiony zostanie tylko pierwszy neuron, który doszedł do stanu spoczynku, a zmiany dla pozostałych będą zignorowane:
                            if ((noUndesiredActivations == 0) && (noIncompleteContextActivations == 0))    // Poprawiamy tylko pierwsze takie wystąpienie, bo inne mogą być pod jego wypływem!
                            {
                                // The stimulation is too strong and the weights must be decreased
                                multiplyProposal = threshold / (xMax + 0.01);   // 0.01 to avoid numerical errors and the situation when threshold == xMaxContext
                                                                                //Logger.LogLine(String.Format("WeakenTooLargeWeights of neuron {0} when multiplyProposal == {1} > 0 after Neuron stimulation:", name, multiplyProposal));
                                foreach (Synapse synapse in inSynapses)
                                {
                                    if ((synapse != sender) && (synapse.PresynVertex.Type == VertexType.neuron)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
                                    {    //synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                        if (IsAvoidingIncorrect)  // (IsAvoidingUndemanded)
                                        {
                                            synapse.MultiplyImmediately(currentSimTime, multiplyProposal);
                                            //insufficientStimulationsNo++;   // DLACZEGO TO SIĘ TAK GŁUPIO NAZYWA?!
                                            //uncorrectedCases = 1;   // // To check this sentence again
                                        }
                                        else
                                        {
                                            if (synapse.MultiplyProposal(currentSimTime, multiplyProposal)) //; // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                                            {
                                                multiplyProposalApprovalTime = currentSimTime + anakg.DelayFollowingObjectLearn;
                                                //activationMoment = ActivationMoments.correct;   // This avoid updating the synapse once again in the method AvoidIncorrectActivations
                                                activationMoment = ActivationMoments.checking;   // This avoid updating the synapse once again in the method AvoidIncorrectActivations
                                            }
                                        }
                                    }
                                }
                            }
                            noUndesiredActivations++;
                            //It will be done by the calling function: if (x == 0) ; // Event must be added to the GEQ at multiplyProposalApprovalTime
                            // We should not InitializeActivityParameters(); until the changes will not be adapted, or recalculated in cases when xMaxContext >= threshold
                        }
                        if (IsAvoidingIncorrect)  // (IsAvoidingUndemanded) 
                            multiplyProposal = 0;
                        // If the changes were applied we should initialize parameters to avoid repeated adaptation of the same changes!!!
                        //InitializeActivityParameters();
                     
                    }
                    else
                    {   // To nie zawsze oznacza, że neuron był aktywowany w poprawnym momencie, ale również, iż niewłaściwy neuron nie był aktywowany lecz tylko podprogowo stymulowany!
                        activationMoment = ActivationMoments.correct;
                        //Logger.LogLine(String.Format("AvoidIncorrectActivations of neuron {0} not necessary because (xMax < threshold) is correct!", name));
                    }
                    //uncorrectedCases = 0;   // Initialize this variable before the next tuning of this sequence or another one
                }
            }
            // The following variables cannot be initialized here because we loose the information that is necessary to compute multiply proposals or updates. We have to wait longer!
            //lastSender = null;
            //xMaxContext = 0;
            //xMax = 0;   // If neuron achieves its resting state this factor should be always nulled before next training sequences.
            //multiplyProposal = 0;
            //activationMoment = ActivationMoments.none;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void InitializeActivityParameters()
        {
            lastSender = null;
            xMaxContext = 0;
            xMax = 0;   // If neuron achieves its resting state this factor should be always nulled before next training sequences.
            multiplyProposal = 0;
            activationMoment = ActivationMoments.none;
            //Logger.LogLine(String.Format("InitializeActivityParameters (xMax, xMaxContext, multiplyProposal, ActivationMoments.none, lastSender) of neuron {0}", name));
        }
        //protected void AvoidIncorrectActivations(UInt64 currentSimTime, Vertex sender = null)
        //{
        //    //+++ It is necessary to use xMaxContext here!!!

        //    if (activationMoment != ActivationMoments.correct)
        //    {
        //        if (modePlasticity == PlasticityMode.tune)
        //            if (xMaxContext >= threshold)   //(xMax > threshold)
        //            {
        //                //+! It must be changed because it increases the noMultiplicationCorrects over noAllStimulations!!! and causes logical error!

        //                // The stimulation is too strong and the weights must be decreased
        //                double multiply = threshold / (xMax + 0.001);   // 0.001 to avoid numerical errors and the situation when threshold == xMax
        //                foreach (Synapse synapse in inSynapses)
        //                {
        //                    if ((synapse != sender)) // The weights of the contextual connections without the last Sender (directly previous/recent sender) must be decreased because they are too strong!
        //                        synapse.Multiply(currentSimTime, multiply);
        //                }
        //                if (animate)
        //                {
        //                    foreach (Synapse synapse in inSynapses)
        //                    {
        //                        synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                    }
        //                }

        //                //threshold = xMax + (threshold / 1000);  // where (threshold / 1000) is a small value that makes the new threshold a little bit bigger than the maximal excitation that made too early activation of this neuron
        //                //threshold = xMax * 1.01;  // where (threshold / 1000) is a small value that makes the new threshold a little bit bigger than the maximal excitation that made too early activation of this neuron
        //                //TOO FAST: threshold = 2 * xMax - threshold;  // If the threshold need to grow with speed of xMax - threshold it should be risen twice this value to avoid future oversteps and shorten training/tuning process
        //                //threshold += growThresholdCoef * (xMax - threshold) + 0.000001;  // we add here a half of the new stimulation because it enable us to avoid situations when any weight slightly changes and the threshold is again too small and over exceeded
        //                //threshold += 0.5 * growThresholdCoef * (xMax - threshold) + 0.000001;  // 0.5 should enable to grow threshold not so rapidly in order not to disable alternatives that should be desirable.
        //                //growThresholdCoef = Math.Sqrt(growThresholdCoef);   // Gradually grow this coefficient
        //                //CountThresholdChange();
        //                //if (threshold > maxThreshold) maxThreshold = threshold;
        //                //inSynapses.First().Permeability = threshold; // Updates weights for sensory connections in order to be able to activate neurons by sensors nevertheless of threshold changes. It models and responds to longer time sensors need to activate connected neurons
        //                //thresholdAcceleration = Math.Pow(threshold, 1 / (double)3);
        //                //if (animate)
        //                //{
        //                //    //ChangeViewSize();
        //                //    View.UpdateViewShapeView();  // Change of neuron body size necessary?
        //                //    // UpdateThresholdView(); // When Asking update threshold view
        //                //    foreach (Synapse synapse in inSynapses)
        //                //    {
        //                //        synapse.View.UpdateWeightView(); // Update view of all presynaptic synapses weights
        //                //    }
        //                //}
        //                // xMax = 0;
        //            }
        //    }
        //    lastSender = null;
        //    xMaxContext = 0;
        //    xMax = 0;   // If neuron achieves its resting state this factor should be always nulled before next training sequences.
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void MultiplyWeakSynapses(UInt64 currentSimTime, Vertex sender)   // StrengthenTooWeakSynapses
        {
            if (IsTuningConflicts)
            {
                //if (((Synapse)sender).PresynVertex.Type != VertexType.neuron)  // it means any sensory (non-neuronal) stimulation
                //{
                // Update multiplication factors of weights: weight = multiplication * permeability
                // When external/sensorial teaching signal comes and the neuron has not been yet activated the multiplication factors should be risen. Take into account the context whether it is unique
                if ((xMax > 0) && (xMax < threshold))   // It has be always true except the situation that xMax = threshold but in this case multiplication factors do not need to be updated. This is equal for synapse == sender == sensor
                {   // 0 <= xMaxContext < xMax < threshold
                    //double multiply = 1.000001 * threshold / xMax;  // We add a small factor threshold / 1000000 to eliminate numerical errors
                    //double multiply = 1.000001 + trainingCoefficient * (threshold / xMax - 1);  // We add a small factor threshold / 1000 to eliminate numerical errors
                    //double multiply = 1.000001 + 1.1 * trainingCoefficient * (threshold / xMax - 1);  // 1.1 has been added to enable the grow of weights a little more than only to achieve the exact threshold! Because when threshold will rise these weights will not be enough again!
                    // Training coefficient should change during the tuning process in such a way to sharpen the multiplication values at the end of this process!
                    //double multiply = 1.01 + trainingCoefficient * (threshold / xMax - 1);  //+! Consider to update it off-line (batch) for all proposals of changes. It means that the multiplication is applied to the weight after presentation of all training sequences.
                    // We can change only the context connection so the multiply should base on them only, not on all stimuli:
                    double multiply;
                    if (xMaxContext > 0)
                    {
                        //multiply = 1.01 + trainingCoefficient * ((threshold - (xMax - xMaxContext)) / xMaxContext - 1);  //1.05 //+! Consider to update it off-line (batch) for all proposals of changes. It means that the multiplication is applied to the weight after presentation of all training sequences.
                        // Multiply computed here do not take into account the lastSender, assuming that the multiplication of it will not be changed:
                        //multiply = 1.01 * ((threshold - (xMax - xMaxContext)) / xMaxContext);  //1.05 //+! Consider to update it off-line (batch) for all proposals of changes. It means that the multiplication is applied to the weight after presentation of all training sequences.
                        //Impossible taking into account previous condition: if ((xMax > threshold) && (multiply > threshold)) multiply = threshold * 1.001;  //  * 1.000001 to avoid numerical problems   // Multiplication factor cannot exceed the threshold in order not to spoil conductances (that contain information about uniqueness) computed by presynaptic neurons.
                        // Multiply can be typically applied to lastSender only to the level when multiplication achieves its level == threshold
                        // The rest of necessary change must be applied to other synapses, so the change done to the lastSender should be subtracted from other necessary changes:
                        //+ ...

                        //+ Contextually choose one of the following options:
                        // 1.	Adapt only the context connections:
                        //multiply = 1.01 * (threshold - (xMax - xMaxContext)) / xMaxContext;
                        // 2.	Adapt only the direct predecessor connection
                        //multiply = 1.01 * ((threshold - xMax) + (xMax - xMaxContext)) / (xMax - xMaxContext);   // BUT we should not multiply multiplication over 1!
                        // 3.	Adapt both the context and direct predecessor connections
                        //multiply = 1.01 * (threshold / xMax);
                        // 4. Use a new way of adaptation moving the middle of the strength of the direct predecessor stimulus to the threshold level
                        //??? multiply = threshold / (xMaxContext + (xMax - xMaxContext)/2);  // where (xMax - xMaxContext)/2 is the half of the strength of the direct predecessor stimulus
                        //??? multiply = threshold / (xMaxContext + lastSender.Weight / 2);
                        // 5. Gdy wagi są już dostrojone, nie mogę je tak bardzo dźwigać, bo powoduje to znowu popsucie innych:
                        //multiply = threshold / (xMaxContext + 2 * lastSender.Weight / 3);  //+++ Spróbujmy delikatniej ALE TO BĘDZIE DLA WSZYSTKICH - WARTO BYŁOBY ROZRÓŻNIĆ TE SYTUACJE!
                        //multiply = threshold / (xMaxContext + lastSender.Weight - 0.01);
                        //multiply = threshold / (xMax - 0.01);   //+++++ Find the rightmost formula! 
                        //multiply = threshold / (xMax - 0.05);   //+++++ Find the rightmost formula! 
                        multiply = threshold / (9 * xMaxContext / 10 + lastSender.Weight - 0.01);   //+++++ Find the rightmost formula! 
                    }
                    else
                    {   // There is only one stimulation equal xMax from the direct predecessor!
                        multiply = threshold * lastSender.Permeability / xMax;  // It returns the weight value (in one step) to the level of the synaptic permeability (initial one)
                    }
                    //Logger.LogLine(String.Format("MultiplyWeakSynapses of neuron {0} with computed multiply = {1} because threshold > xMax = {2} and this neuron should be activated!", name, multiply, xMax));
                    bool multiplied = false;
                    if (multiply != 1)  // Only in this case some changes will be applied, so there is no sense to do any change when multiply == 1
                    {
                        foreach (Synapse synapse in inSynapses)
                        {
                            //if ((synapse != sender) && (synapse != lastSender)) // We should not change the multiplication factor of the direct predecessor "lastSender" here
                            //    multiplied |= synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                            if (synapse == lastSender) // The last sender has the biggest influence on the activation
                            {   // If we don't change the direct predecessor multiplication here, it has no chance to grow but only be decreased when avoiding incorrect activations!
                                //+ ???????????? multiply = lastSender.Permeability / xMax;
                                //It spoils connections like A---NICE and improves NICE-CAT: multiplied |= synapse.Multiply(currentSimTime, multiply);   // Added extra to make this growth also possible
                                //multiply = lastSender.Permeability / xMax;  // This should not multiply over multiplication <= 1;
                                //if (lastSender.Multiplication * multiply > threshold)
                                //    multiply = threshold / lastSender.Multiplication; // This limited all changes of all synapses not only of the lastSender!
                                //multiplied |= synapse.Multiply(currentSimTime, multiply);
                                if (lastSender.Multiplication * multiply > threshold)
                                {
                                    double limitedMultiply = threshold / lastSender.Multiplication;
                                    if (limitedMultiply != 1) multiplied |= synapse.Multiply(currentSimTime, limitedMultiply);
                                }
                                else multiplied |= synapse.Multiply(currentSimTime, multiply);  // if multiply ==1 then nothing is change but multipied = true!?
                            }
                            else if (synapse != sender) // Działa to!  //??? not receptor connection  // && (synapse != lastSender)) // We should not change the multiplication factor of the direct predecessor "lastSender" here
                            {   // we multiply here only synapses of the context
                                multiplied |= synapse.Multiply(currentSimTime, multiply); // We do not add the training sensory signal to the excitation sum that should activate the neuron if the context is unique
                            }
                        }
                    }
                    lastSender = null;
                    xMaxContext = 0; //???
                    xMax = 0; // This is necessary to stop threshold plasticity process after training sensory signal has come!
                              //activationMoment = ActivationMoments.notachieved;   // Too small stimulation, but here was the try to correct it!
                    if (multiplied == true)
                    {
                        activationMoment = ActivationMoments.correctlater;   // It has been corrected if it was possible, i.e. there were more than one predecessor because we can update only multiplication factors of the context connections, not the direct predecessor because it is well defined by its permeability, and if it is < 1 it means that not in every case this neuron can be activated, so we cannot do it here changing the multiplication factor of this synapse!
                                                                             //Logger.LogLine(String.Format("Neuron {0} is ActivationMoments.correctlater", name));
                    }
                    else
                    {
                        activationMoment = ActivationMoments.uncorrectable;
                        //Logger.LogLine(String.Format("Neuron {0} is ActivationMoments.uncorrectable", name));
                    }
                }
                else if ((xMax >= threshold) && (xMaxContext < threshold)) // 0 <= xMaxContext < threshold <= xMax 
                {
                    activationMoment = ActivationMoments.correct;   // That is the goal of training, so it's fully correct
                                                                    //Logger.LogLine(String.Format("Neuron {0} is ActivationMoments.correct", name));
                }
                else // 0 = xMaxContext = xMax
                {
                    activationMoment = ActivationMoments.uncorrectable;   // because we cannot do anything to improve the stimulation for this context which is none
                                                                          //Logger.LogLine(String.Format("Neuron {0} is ActivationMoments.uncorrectable", name));
                }
                //}
            }
            // To musi być zrobione również dla phase 1 i 2:
            lastSender = null;
            xMaxContext = 0; //???
            xMax = 0; // This is necessary to stop threshold plasticity process after training sensory signal has come!
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public override void Update(Vertex sender, UInt64 currentSimTime, object eventObject, UInt32 duration)
        {   // NEURON
            timeUpdate = currentSimTime;
            // The update process can be started in various states of a neuron:
            // - for external stimulus (from synapse) that charges or dischages it due to its excitatory or inhibitory type
            // - for internal stimulus that processes internal changes of the neuron in time: gradual charging or dischargin, gradual relaxation, gradual relative refraction and even activation and absolute refraction that are not immediate
            // Sender is the vertex that initiated the event that has stated this update
            // The currentSimTime is the time when this update should start
            //if ((sender != this) && ((state != InternalState.Nascent) || !viewCreated))
            //if ((sender != this) && ((state != InternalState.Nascent) || (animate && (view == null))))   // || (!animate) ?  //! I cannot use (|| !viewCreated) because sometimes we do not create views at all!!!
            if (sender != this) // && ((state != InternalState.Nascent) || (animate && (view == null))))
            {
                // External stimulation executes this update
                if (state == InternalState.Nascent) // was: if (viewDiameter == 0) //(state == InternalState.Nascent)    // This means that this is a new neuron, never activated (timeActivation == 0). Its view should be created and animated parallely in time with other processes, e.g at the same time many neurons can be created.
                {   // If this is the first external stimulation to this neuron its addition have to be visualized:
                    // Start sequence of events of creation of a new neuron
                    actionInterval = periodCreating; //? Sensor.timeSensing = 1000 + Synapse.timeTransmission = 1000; It has to be finished before sensory stimulation comes
                    actionBeginTime = currentSimTime;
                    if (animate) actionSteps = 10;
                    else actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 1;
                    activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);

                }
                else if ((state == InternalState.Activation) || (state == InternalState.AbsRefraction)) //?  || (state == InternalState.RelRefraction) - relative refraction is risky to take into account here
                {
                    //UpdateThreshold(currentSimTime, sender);
                    //?if ((IsCreating) || (IsTuning))
                    //Managed inside: if (phase >= 2)   //if (IsTuning)
                    WeakenTooLargeWeights(currentSimTime, sender);
                }
                //else if (state == InternalState.Activation)
                //{
                //    // Logger.LogLine(String.Format("NEURON {0} DOES NOT REACT ON STIMULATION DURING ITS ACTIVATION AT SIMTIME {1}", Name, currentSimTime));
                //    // But if during this time in the tuning phase next non-sensory stimulations happen it means that the neuron has been activated using not the full context, so now threshold should be updated:
                //    WeakenTooLargeWeights(currentSimTime, sender);
                //}
                //else if (state == InternalState.AbsRefraction)  // (x < threshold) // if neuron is during absolute refraction process all external charges or suppressions are ignored
                //{
                //    // Logger.LogLine(String.Format("NEURON {0} DOES NOT REACT ON STIMULATION DURING ITS ABSOLUTE REFRACTION AT SIMTIME {1}", Name, currentSimTime));
                //    // But if during this time in the tuning phase next non-sensory stimulations happen it means that the neuron has been activated using not the full context, so now threshold should be updated:
                //    WeakenTooLargeWeights(currentSimTime, sender);    //+ It is not enough, because it can happen even during relative refraction!
                //}
                else
                {
                    if (IsTuning)  //+! Powtórzony warunek, który jest sprawdzany wewnątrz UpdateThreshold ale nie w MultiplyWeakSynapses
                    {
                        //if ((state == InternalState.RelRefraction) || (state == InternalState.AbsRefraction) || (state == InternalState.Activation)) the other two cases were considered before!
                        if (currentSimTime - timeActivation < periodTuning)  // (state == InternalState.RelRefraction) // || (state == InternalState.AbsRefraction) || (state == InternalState.Activation))
                        {
                            // But if during this time in the tuning phase next non-sensory stimulations happen it means that the neuron has been activated using not the full context, so now threshold should be updated:
                            //Managed inside: if (phase >= 2)
                            WeakenTooLargeWeights(currentSimTime, sender);    //+ It is not enough, because it can happen even during relative refraction!
                        }
                        else if (((Synapse)sender).PresynVertex.Type != VertexType.neuron) // Call this method only for sensory tuning stimulations
                        {
                            //: It is managed inside: if (phase >= 3) // Start Strengthening of Weak Synapses and Fine Tuning of Conflicts from the 3rd Tuning Cycle
                            MultiplyWeakSynapses(currentSimTime, sender);
                        }
                    }
                    // Remember the last external sender:
                    lastExternalSender = sender;
                    // Update possible only if this neuron is not during absolute refraction process (that is started and not finished)
                    double xRest = 0.0;     // This is the rest of the active (interrupted) charging process
                    UInt32 timeRest = 0;    // This is the rest of the time interval necessary to finish active (interrupted) charging process
                    if (xCharge > 0)    // External excitation xCharge>0 or suppression xCharge<0
                    {
                        xRest = UpdateInternalChargeLevel(currentSimTime);
                        // timeRest is computed only for Charging, not for Relaxing or Refracting
                        timeRest = (UInt32)(actionBeginTime + periodCharge - currentSimTime);    // Rest of time is computed taking into account real periodCharge, not actionInterval that can be shorter because of achieving threshold faster.
                        //if (timeRest > periodCharging) // Logger.LogLine(String.Format("ERROR: Unexpected value of timeRest of NEURON {0} has been detected AT SIMTIME {1}!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", Name, currentSimTime));
                    }
                    else if (xCharge < 0)    // External excitation xCharge>0 or suppression xCharge<0
                    {
                        xRest = UpdateInternalSuppressionLevel(currentSimTime);
                        // timeRest is computed only for Charging, not for Relaxing or Refracting
                        timeRest = (UInt32)(actionBeginTime + periodCharge - currentSimTime);    // Rest of time is computed taking into account real periodCharge, not actionInterval that can be shorter because of achieving threshold faster.
                    }
                    else // (xCharge == 0) - i.e.: recovering or relative refraction (except relaxation) have to update their x value and all have to update their timeUpdate
                    {
                        if (x > 0) UpdateInternalRelaxLevel(currentSimTime);
                        else if (x < 0) UpdateInternalRelRefractLevel(currentSimTime);
                    }
                    // Compute new charge and current output signal
                    xIntermediateChange = 0;
                    //!? The question is about the sensory stimulations. Should they (sender.Y) be equal 1 or more it the neuron is in the recovery process?
                    //!? Biologically they should stimulate the neuron longer (in time) charging it to the activation level value if the signal is strong enough
                    //No! Don't force to activate the neurons in the relative refraction state:
                    //if ((((Synapse)sender).PresynVertex.Type == VertexType.symbolicsensor) && (x > 0)) xCharge = 1.00000001 * threshold - x; // May be it is unnecessary. It only avoids faster activation of the already stimulated neurons  //ADDED: If the neuron is stimulated from sensor the charge must be sometimes stronger and equal the difference = threshold - x
                    //else
                    xCharge = sender.Y + xRest; // New xCharge value has been computed after the rest of previous unfinished charge and current external stimulation
                                                //periodCharge = Math.Max(timeRest, (UInt32)(0.5 + periodCharging * sender.Y / threshold));   // We take the longer interval of current stimuli charge or the previous not finished one
                    if (xCharge <= threshold) periodCharge = Math.Max(timeRest, (UInt32)(/*0.5 + */periodCharging * xCharge / threshold));   // We take the longer interval of current stimuli charge or the previous not finished one
                    else periodCharge = Math.Max(timeRest, (UInt32)(/*0.5 + */periodCharging * threshold / xCharge));

                    // Remove the previously send event in events because it becomes to be outdated!
                    if (activeEvent != null) events.RemoveOutdatedEvent(activeEvent);

                    if ((x < 0) && (xCharge < 0))
                    {
                        // Suppressive stimulations in hyperpolarization state accelerate return back into the resting state in the similar way as they will be charging stimuli, but they do not surpass the resting state as real charging stimuli
                        if (xCharge < x) xCharge = -x;  // Do not surpass the resting state
                        else xCharge = -xCharge;    // or * -1 The suppression signal in refraction state changes into the charging onel
                    }

                    if (xCharge > 0)
                    {
                        // Start charging
                        state = InternalState.Charging;  // GREEN VIEW, Content = level of charging (numerical)
                        //+ this charging process is not tracked by the event in the GEQ! Hence this neuron crashes in this state!!!



                        // Logger.LogLine(String.Format("NEURON {0} HAS STARTED ITS NEW CHARGING AT SIMTIME {1}", Name, currentSimTime));

                        //- Incorrect option because x relaxes in time: xMax += xCharge - ((((Synapse)sender).PresynVertex.Type != VertexType.neuron) ? sender.Y : 0);     // Store the maximal excitation to this neuron
                        //xMax = x + xCharge - ((((Synapse)sender).PresynVertex.Type != VertexType.neuron) ? sender.Y : 0);     // Store the maximal excitation to this neuron
                        //if (xMax < 0) xMax = 0;
                        if ((((Synapse)sender).PresynVertex.Type == VertexType.neuron) && (state != InternalState.RestingPlasticity))   // Don't update xMax and xMax during Resting Plasticity because it can be fake!
                        {
                            xMaxContext = xMax;
                            lastSender = (Synapse)sender;
                            if (currentSimTime - timeActivation < 50000)
                            {
                                xMax += xCharge; // We have to add extra stimulations even after activation of the neuron to compute threshold of this neuron correctly
                                // xMax += xCharge - ((((Synapse)sender).PresynVertex.Type != VertexType.neuron) ? sender.Y : 0); // We have to add extra stimulations even after activation of the neuron to compute threshold of this neuron correctly
                            }
                            else
                            {
                                xMax = x + xCharge;     // Store the maximal excitation to this neuron
                                // xMax = x + xCharge - ((((Synapse)sender).PresynVertex.Type != VertexType.neuron) ? sender.Y : 0);     // Store the maximal excitation to this neuron
                            }
                        }
                        else
                        {
                            //xMax should stay to be 0 after training signal  // - ((((Synapse)sender).PresynVertex.Type != VertexType.neuron) ? sender.Y : 0)

                            // Training signals should charge refracted neurons only to its resting state
                            //if (x < 0)  // Only when refracting
                            //{
                            //    xCharge = -x;    // This is a modification of the strength of input sensory stimuliti to avoid situations when this training signal charges this neuron again in its refraction period
                            //    periodCharge = Math.Max(timeRest, (UInt32)(0.5 + periodCharging * xCharge / threshold));
                            //}
                        }
                        // START THE SEQUENCE OF CHARGING EVENTS:
                        actionInterval = periodCharge;    //! Time of charging is dependent on the strength of stimulation AND of the size of the neuron (threshold, activationNo)
                        if (x + xCharge > threshold)    // If peakTime occurs it should be computed:
                            actionInterval = (UInt32)(1 + 2 * (double)periodCharge * Math.Asin((threshold - x) / xCharge) / Math.PI);   //actionInterval = (UInt32)(1 + 2 * (double)periodCharging * Math.Asin((threshold - x) / xCharge) / Math.PI); // "1 + " insures that rounding will be to the upper integer value what is necessary to avoid numerical problems with achieving a threshold value!
                        actionBeginTime = currentSimTime;
                        //actionSteps = Math.Min((UInt16)10, (UInt16)(10 * Math.Truncate(actionInterval / (double)periodCharging)));    // If threshold is achieved faster, there is less actionSteps
                        if (animate)
                        {
                            actionSteps = Math.Min((UInt16)(0.5 + 100 * xCharge / threshold), (UInt16)(0.5 + 100 * (threshold - x) / threshold));    // It should be updated each single step showing following natural numbers as its charge when animating dependently on the charge value
                            if (actionSteps < 1) actionSteps = 1;
                        }
                        else actionSteps = 1;
                        actionStepInterval = (UInt32)(0.5 + actionInterval / (double)actionSteps);
                        actionStepCntr = 1;
                        if (actionStepCntr <= actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                    else if (xCharge < 0)
                    {
                        if ((x > 0) && (x + xCharge < 0)) xCharge -= x; // You cannot suppress to the valeus lower than the resting state (do not surpass the resting state)
                                                                        // Start suppression and inhibition process
                        state = InternalState.Suppression;  // GREEN VIEW, Content = level of still positive suppression (numerical)
                        // Logger.LogLine(String.Format("NEURON {0} HAS STARTED ITS NEW SUPPRESSION/INHIBITION PROCESS AT SIMTIME {1}", Name, currentSimTime));
                        // START THE SEQUENCE OF CHARGING EVENTS:
                        actionInterval = (UInt32)(periodCharge / thresholdAcceleration);    //! Time of charging is dependent on the strength of stimulation AND of the size of the neuron (threshold, activationNo)
                        actionBeginTime = currentSimTime;
                        if (animate) actionSteps = (UInt16)(0.5 + 100 * -xCharge);    // It should be updated each single step showing following natural numbers as its charge when animating dependently on the charge value
                        else actionSteps = 1;
                        actionStepInterval = (UInt32)(0.5 + actionInterval / (double)actionSteps);
                        actionStepCntr = 1;
                        if (actionStepCntr <= actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                    else // xCharge == 0 can happen when the rest of charging stimulation is added to the exact the same value of the suppression/inhibition stimulation
                    {
                        state = InternalState.Charging;  // GREEN VIEW, Content = level of charging (numerical)
                        actionInterval = (UInt32)(periodCharge / thresholdAcceleration);    //! Time of charging is dependent on the strength of stimulation AND of the size of the neuron (threshold, activationNo)
                        actionBeginTime = currentSimTime;
                        actionSteps = 1;    // It should be updated each single step showing following natural numbers as its charge when animating dependently on the charge value
                        actionStepInterval = actionInterval;
                        actionStepCntr = 1;
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                }
            }
            else // (sender == this)
            {
                //// Check whether Threshold should be updated
                //if (eventThresholdPlasticity != null)
                //{
                //    // If until this time the training sensory/external input signal has not come it means that the activity of this neuron was too fast so the threshold must be rised up
                //    ThresholdUpdate();
                //}
                // Internal finishing of previous process executes this update: After finishing of Recovery
                if ((activePlasticity == true) && (timeStopPlasticity <= currentSimTime))
                {
                    activePlasticity = false;
                 

                }
                if (state == InternalState.Nascent)    // This means that this is a new neuron, never activated. // timeActivation == 0
                {
                    // Animate the next step of Neuron creation
                   
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        // The creation process of the neuron is finished. Now it can start working.
                        // Logger.LogLine(String.Format("NEURON {0} HAS BEEN CREATED AT SIMTIME {1}", Name, currentSimTime));
                        //// CHANGE OF ITS INTERNAL STATE:
                        //state = InternalState.Resting; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                        //UpdateChargeView(noOfNeuralStateGrades, "");
                        //activeEvent = null;
                        SwitchToInternalRestingState(currentSimTime);

                        // After creation make charging and activityNo visible
                       

                        // Now a new effector for this neuron should be created
                        anakg.EffOutputs.AddEffector(this, currentSimTime, name);
                    }
                }
                else if (xCharge > 0)   // CHARGE OR RELAX
                {
                    // Update intermediate state of the neuron
                    if (actionStepCntr <= actionSteps)
                    {
                        // Compute the intermediate state for this neuron
                        UpdateInternalChargeLevel(currentSimTime);
                    }
                    // SEND THE NEXT SEQUENCE EVENT FOR THE CHARGING ACTION:
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        // The charging process is finished. Now stard Relaxation or Activation process accordingly to the neural state
                        double xChargeStrength = x - xIntermediateChange + xCharge;     // This full charge value is used to update the threshold
                        xCharge = 0;
                        xIntermediateChange = 0;
                        periodCharge = 0;
                        if (x >= threshold)
                        {   // Activate the neuron
                            x = threshold;
                            timePreviousActivation = timeActivation;
                            timeActivation = currentSimTime;  // Remember last activation time. It is used to model neuronal plasticity and create new connections
                            timeStopTuning = timeActivation + periodTuning;
                            y = 1.0;    // Output signal
                            //Logger.LogLine(String.Format("Neuron {0} is activated now and starts stimulation of connected neurons!", name));
                            if (IsCreating) // Only when training in creation mode
                            {
                                activityNo++;   // It counts up activations if this neuron (graph) is in the plasticity mode
                                if (activityNo > activityNoMax) activityNoMax = activityNo;
                                 // true means that Layout should be updated
                                UpdatePermeabilitiesOfAxsonalSynapses();    //!! UpdatePermeabilitiesOfAxsonalSynapses ==> UpdatePermeabilitiesOfAxsonalSynapses
                            }
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.Activation; // RED VIEW, Content = "A" - activation
                            // Logger.LogLine(String.Format("NEURON {0} HAS BEEN ACTIVATED AT SIMTIME {1}", Name, currentSimTime));

                            // START THE SEQUENCE OF ACTIVATION EVENTS:
                            actionInterval = (UInt32)(periodActivation / thresholdAcceleration);
                            actionBeginTime = currentSimTime;
                            if (animate) actionSteps = 2;    // In the middle and at the top of the spike peak
                            else actionSteps = 1;
                            actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                            actionStepCntr = 1;
                            activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);

                            //! REBUILD:
                            if (IsCreating)    // This is ANAKG plasticity that enable changes to all elements in the ANAKG
                            {
                                // Make the neuron temporality ready for plasticity processes.
                                activePlasticity = true;    // This is neuronal plasticity
                                timeStopPlasticity = currentSimTime + periodPlasticityMax;
                               
                                events.AddEvent(this, this, timeStopPlasticity);
                                anakg.StartNeuralPlasticityWith(this);
                                // It does not passes the signal to the Effector
                                outSynapses.First().AddEvents(this, ActionType.stimulate, currentSimTime);    // The First Synapse connects this neuron with its Effector
                            }
                            else
                            {
                                if (!(IsTuning && (currentSimTime > stopStimulatingNeurons))) // This condition avoids overstimulating the network during tuning after TuneConflicts where many neurons can be activated indefinitely
                                {
                                    // Forward the activation to all output synapses
                                    foreach (Synapse synapse in outSynapses)
                                        synapse.AddEvents(this, ActionType.stimulate, currentSimTime);  // events.AddEvent(this, synapse, timeUpdate);
                                }
                            }
                        }
                        else if (x > 0)
                        {   // Relax the neuron
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.Relaxation;  // GREEN VIEW, Content = level of relaxation (numerical)
                            // Logger.LogLine(String.Format("NEURON {0} HAS STARTED ITS RELAXATION AT SIMTIME {1}", Name, currentSimTime));
                            // START THE SEQUENCE OF RELAXATION EVENTS:
                            actionInterval = (UInt32)((periodRelaxing * x + 0.5) / thresholdAcceleration);
                            actionBeginTime = currentSimTime;
                            //actionSteps = Math.Min((UInt16)10, (UInt16)(10 * Math.Truncate(actionInterval / (double)periodCharging)));    // If threshold is achieved faster, there is less actionSteps
                            if (animate) actionSteps = (UInt16)(0.5 + 100 * x / threshold);    // It should be updated each single step showing following natural numbers as its charge when animating dependently on the charge value
                            else actionSteps = 1;
                            actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                            actionStepCntr = 1;
                            activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        }
                        else if (x < 0) // Continue Relative Refraction, because the input charging stimulation was too weak and the neuron is still in hyperpolarization state (under the resting state)
                        {
                            // CHANGE OF ITS INTERNAL STATE:
                            state = InternalState.RelRefraction;     //! Too early switches the state of neuron
                            // Logger.LogLine(String.Format("NEURON {0} HAS STARTED ITS RELATIVE REFRACTION AT SIMTIME {1}", Name, currentSimTime));
                            // START THE SEQUENCE OF ACTIVATION EVENTS:
                            actionInterval = (UInt32)((periodRelRefracting * -x + 0.5) / thresholdAcceleration);
                            actionBeginTime = currentSimTime;
                            if (animate) actionSteps = (UInt16)(0.5 + 100 * -x / threshold);    // how much msec it takes, so we update the state each msec
                            else actionSteps = 1;
                            actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                            actionStepCntr = 1;
                            activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                        }
                        else // x == 0
                        {
                            
                            state = InternalState.Resting; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                            // Logger.LogLine(String.Format("NEURON {0} HAS REACHED ITS RESTING STATE AT SIMTIME {1}", Name, currentSimTime));
                            // NO NEXT INTERNAL PROCESS IS STARTED
                            actionInterval = 0;
                            actionBeginTime = currentSimTime;   // it is the time when resting has started
                            actionSteps = 0;    // how much msec it takes, so we update the state each msec
                            actionStepInterval = 0;
                            actionStepCntr = 0;
                            activeEvent = null;

                            //anakg.NoIncorrectSeqActivations += uncorrectedCases;
                            //if (uncorrectedCases > 0) activationMoment = ActivationMoments.incorrect;
                            //else activationMoment = ActivationMoments.correct;
                            // The above code must be processed before the following method because the uncorrectedCases is initialized inside!
                            // Everywhere where training signal came xMax is nulled (xMax = 0). In the other cases neurons for which xMax > their threshold should be also updated in order to avoid their incorrect activations
                            if (IsTuning)
                                AvoidIncorrectActivations(currentSimTime, sender);
                            InitializeActivityParameters(); //???
                        }
                    }
                }
                else if (state == InternalState.Suppression)   // (xCharge < 0)   // SUPPRESSION OR INHIBITION
                {
                    // Update intermediate state of the neuron
                    if (actionStepCntr <= actionSteps)
                    {
                        // Compute the intermediate state for this neuron
                        UpdateInternalSuppressionLevel(currentSimTime);
                    }
                    // SEND THE NEXT SEQUENCE EVENT FOR THE CHARGING ACTION:
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        // The charging process is finished. Now stard Relaxation or Activation process accordingly to the neural state
                        xCharge = 0;
                        xIntermediateChange = 0;
                        periodCharge = 0;
                    }
                }
                else if (state == InternalState.Relaxation)
                {
                    if (actionStepCntr <= actionSteps) UpdateInternalRelaxLevel(currentSimTime);
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) // PARTLY GREEN VIEW, Content = level of charging (numerical); in between the polarization and the resting state (-70mV)
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                    else if (actionStepCntr == actionSteps) // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    }
                    else
                    {
                        SwitchToInternalRestingState(currentSimTime);
                    }
                }
                else if (state == InternalState.RestingPlasticity)
                {
                    SwitchToInternalRestingState(currentSimTime);
                }
                else if (state == InternalState.Activation)   // (x >= threshold) - unnecessary
                {
                    //x = threshold + 6 * threshold * actionStepCntr / (double)actionSteps;   // Computing of the internal state of the neuron during rising activation peak (from -50/55mV to +30/35mV), where (35mV - (-55mV))/(-75mV-(-55mV)) = 90/15 = 6
                    if (actionStepCntr <= actionSteps) UpdateInternalActivationLevel(currentSimTime);
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) // RED + YELLOW VIEW, Content = "S" - spiking
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                    else if (actionStepCntr == actionSteps) // RED + YELLOW VIEW, Content = "S!" - top of the spiking peak
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    }
                    else
                    {
                        // x is now equal threshold + 6 * threshold , the neuron internal state is at the top of the activation peak (about +30/35 mV), where (35mV - (-55mV))/(-75mV-(-55mV)) = 90/15 = 6
                        // The activation process is finished. Now stard Absolute Refraction process accordingly to the neural state
                        // CHANGE OF ITS INTERNAL STATE:
                        xIntermediateChange = 0;
                        state = InternalState.AbsRefraction;    //! Too early to change to this stage
                        // Logger.LogLine(String.Format("NEURON {0} HAS STARTED ITS ABSOLUTE REFRACTION AT SIMTIME {1}", Name, currentSimTime));
                        // START THE SEQUENCE OF ACTIVATION EVENTS:
                        actionInterval = periodAbsRefracting;
                        actionBeginTime = currentSimTime;
                        if (animate) actionSteps = 2;    // in half and top of the activation peak
                        else actionSteps = 1;
                        actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                        actionStepCntr = 1;
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                }
                else if (state == InternalState.AbsRefraction)
                {
                    // x if meaning the stimulation ability should be set to minus infinity and not to the levels of membrane potential
                    if (actionStepCntr <= actionSteps) UpdateInternalAbsRefractLevel(currentSimTime);
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) // RED + BLUE VIEW, Content = "R" - in between the peak spike (+30/35mV) and the hyperpolarization minimum (-85/90mV)
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                    else if (actionStepCntr == actionSteps) // BLUE VIEW, Content = "R" - at the hyperpolarization minimum (-85/90mV) and at the last moment of the absolute refraction process
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);  // periodAbsRefracting
                    }
                    else
                    {
                        //+ Change the border color of the neuron to red color to show that this neuron is ready for plasticity processes and new connection creation
                        //+ CONTINUE...
                        xIntermediateChange = 0;
                        // x is now equal -threshold; May be -threshold is too little and should be "- alpha * threshold", where alpha > 1. Here, x does not mean the potential but the level of reactivity or the necessary excitation stimulus needed in a given moment to activate the neuron again after the absolute refraction
                        x = -threshold; // Let's start the relative refraction process from - threshold, however it can be changed using for example tangensoid that goes from - infinity to 0 at some distance. This function nicely models what is happening with stimulation susceptibility of the neuron during hyperpolarization
                        y = 0.0;    // Output signal is switched off after absolute refraction duration finishes
                                    // The absolute refraction process is finished. Now stard Relative Refraction process accordingly to the neural state
                                    // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.RelRefraction;     //! Too early switches the state of neuron
                        // Logger.LogLine(String.Format("NEURON {0} HAS STARTED ITS RELATIVE REFRACTION AT SIMTIME {1}", Name, currentSimTime));
                        // START THE SEQUENCE OF ACTIVATION EVENTS:
                        actionInterval = periodRelRefracting;
                        actionBeginTime = currentSimTime;
                        if (animate) actionSteps = (UInt16)(0.5 + 100 * -x / threshold);    // how much msec it takes, so we update the state each msec
                        else actionSteps = 1;
                        actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                        actionStepCntr = 1;
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                }
                else if (state == InternalState.RelRefraction)
                {
                    if (actionStepCntr <= actionSteps) UpdateInternalRelRefractLevel(currentSimTime);
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) // PARTLY BLUE VIEW, Content = level of charging (numerical); in between the hyperpolarization minimum (-85/90mV) to the resting state (-70mV)
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                    else if (actionStepCntr == actionSteps) // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                    {
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);  // periodRelRefracting
                    }
                    else
                    {
                        SwitchToInternalRestingState(currentSimTime);
                        //+ Change the border color of the neuron to standard grey to show that this neuron is not longer ready for plasticity processes and new connection creation
                        //+ CONTINUE...
                        xIntermediateChange = 0;
                        //// x is now equal 0;
                        //x = 0; // The relative refraction process is finished. Now the neuron is in its resting state awaiting for next external stimulation. Interanal processes are finished. 
                        //viewCharge.Content = "";
                        //state = InternalState.Resting; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                        //// Logger.LogLine(String.Format("NEURON {0} HAS REACHED ITS RESTING STATE AT SIMTIME {1}", Name, currentSimTime));
                        //// NO NEXT INTERNAL PROCESS IS STARTED
                        //actionInterval = 0;
                        //actionBeginTime = currentSimTime;   // it is the time when resting has started
                        //actionSteps = 0;    // how much msec it takes, so we update the state each msec
                        //actionStepInterval = 0;
                        //actionStepCntr = 0;
                        //activeEvent = null;
                    }
                }
            }
            
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void UpdatePermeabilitiesOfAxsonalSynapses()
        {
            // Permeabilities of all axonal synapses and connections have to be updated whenever noActivity of the neuron changes
            //Logger.LogLine(String.Format("Update permeabilities of neuron {0}:", name));
            foreach (Synapse synapse in outSynapses)
            {
                synapse.UpdatePermeability();
            }
            // Permeability of the sensor connection must be updated if the threshold of postsynaptic neuron changes. On the other hand it will stop activating this neurons.
            if (inSynapses.First().PresynVertex.Type != VertexType.neuron)
                inSynapses.First().UpdatePermeability();
            // There must be updated synaptic efficiencies and permeabilities of all input synapses which took a part in activation of this neuron
            //It was doubled!
            //foreach (Synapse synapse in inSynapses)
            //{
            //    if (synapse.PresynVertex.Type == VertexType.neuron)
            //        synapse.UpdateInSynapticEfficiency(timeActivation);
            //}
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void SpreadInSynapses()
        {
          
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void AddMeToPresynConn(Synapse synapse)
        {
            inSynapses.Add(synapse);    // A created synapse is responsible for being added to the presynaptic list of synapses of neurons
            if (inSynapses.Count > numberMaxInSynapses) numberMaxInSynapses = inSynapses.Count;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void AddMeToPostsynConn(Synapse synapse)
        {
            outSynapses.Add(synapse);    // A created synapse is responsible for being added to the postynaptic list of synapses of neurons
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public Synapse AddSensConn(Sensor sensor, UInt64 currentSimTime)
        {
            Synapse synapse = new Synapse(sensor, this, currentSimTime);
            return synapse;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public Synapse AddEffConn(Effector effector, UInt64 currentSimTime)
        {
            Synapse synapse = new Synapse(this, effector, currentSimTime);
            return synapse;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public Synapse AksonConnectToVertex(Vertex postsynVertex, UInt64 currentSimTime)
        {
            Synapse synapse = new Synapse((Vertex)this, postsynVertex, currentSimTime);
            return synapse;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void SynapsePlasticity(Neuron targetNeuron, UInt64 currentSimTime)
        {
            Synapse synapse = null;
            // Try to find the aksonal connection to this postsynNeuron if exists
            foreach (Synapse outSynapse in outSynapses)
                if (outSynapse.PostsynVertex == targetNeuron) { synapse = outSynapse; break; }
            // If a synapse does not exist, create it and the connection
            if (synapse == null)
            {
                synapse = AksonConnectToVertex((Vertex)targetNeuron, currentSimTime);
                //synapse.CreateView();
            }
            else
            {
                synapse.TransmitStimulation(currentSimTime);
                // Update synaptic efficiency and permeability
                synapse.UpdateSynapticEfficiency(targetNeuron.TimeActivation - timeActivation);
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
       
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class SensoryNeuron : Neuron // Associative Sensory Neurons are used to react on sensory inputs provided by Sensors of various types and connect with each other in case when there is an order between input data of a given parameter represented by sensory fields
    {
        // Sensory Neurons relax and refract faster. During the time the signal is going to the connected Object Neuron and back to it, it finishes its Absolute Refraction in order to be charged to its resting state by this back excitation and be ready for next stimulations 
        // Only Sensory Neurons can connect with Sensors. When there is no reaction of existing Sensors until some short period of time Sensory Input Field should create a new Sensor and this Sensor a new SensoryNeuron that will charge adequatelly to the similarity of the presented input to the value represented by this Sensor
        // There is no necessity to represent each single input value (e.g. all real numbers) but only these values that are different enough not to charge any of the existing SensoryNeurons in a given time, e.g. 1,001.
        // These kind of neurons also charge faster in comparison to the other types of neurons, e.g. ObjectNeurons
        #region FIELDS

        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public SensoryNeuron(UInt64 simtimeCreation, Vertex creator, string name = null) : base(simtimeCreation, creator, name)
        {
            type = VertexType.sensoryneuron;
            // During creation of this neuron genetic code should be activated and recall some preprogrammed actions for this type of neuron

        }
        #endregion CONSTRUCTORS
    }
    //***********************************************************************************************************************************************
    public class ObjectNeuron : Neuron // Associative Object Neurons are used to define classes of various spatio-temporal combinations of input data. They are not directly connected to the sensors but to the Sensory Neurons. They can produce useful outputs so they can be connected to Effectors
    {
        #region CONSTRUCTORS
        public ObjectNeuron(UInt64 simtimeCreation, Vertex creator, string name = null) : base(simtimeCreation, creator, name)
        {
            type = VertexType.objectneuron;
        }
        #endregion CONSTRUCTORS
    }
    //***********************************************************************************************************************************************
    public class RangeNeuron : ObjectNeuron // An associative Range Neuron is a kind of ObjectNeurons which aggregate information from connected SensoryNeurons connected to the same SensoryInput that value can be ordered
    {
        #region CONSTRUCTORS
        public RangeNeuron(UInt64 simtimeCreation, Vertex creator, string name = null) : base(simtimeCreation, creator, name)
        {
            type = VertexType.rangeneuron;
        }
        #endregion CONSTRUCTORS
    }
    //***********************************************************************************************************************************************
    public class SubsetNeuron : ObjectNeuron // An associative Subset Neuron is a kind of ObjectNeurons which aggregate information from connected SensoryNeurons connected to the same SensoryInput that value cannot be ordered 
    {
        #region CONSTRUCTORS
        public SubsetNeuron(UInt64 simtimeCreation, Vertex creator, string name = null) : base(simtimeCreation, creator, name)
        {
            type = VertexType.subsetneuron;
        }
        #endregion CONSTRUCTORS
    }
    //***********************************************************************************************************************************************
    public class Sensor : Vertex // Associative Sensor
    {
        public enum InternalState : sbyte
        {
            Nascent = -100,
            Appearing = -50,
            Recovering = -1,
            Resting = 0,
            Sensing = 1,
        }
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        //protected static readonly UInt16 periodCreating = 500; // This should be equal timeSensing = 1000 to make no difference between existing and created sensors: timeSensing == timeCreateView + Synapse.timeCreateView!!!
        #endregion CONST AND READONLY FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected SensInput sensInput;      // A sensory input to which this receptor is connected and for which it is reactive in the presented data are sensed by this receptor
        protected Synapse receiver;         // A synapse or neuron that receives output from this receptor (usually all connections between receptors and neurons have an intermediate synapse)
        protected UInt32 timeSensing;       // The time that lapses from starting stimulation of this sensor to make it stimulating next connected Vertex (usually Synapse)
        protected UInt32 timeRecovering;    // The time that have to lapse from the last stimulation of this sensor to return it back to its resting state
        protected InternalState state;      // Actual state
        //protected SensorView view;          // The class view for this sensor
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public UInt32 TimeSensing
        {
            get { return timeSensing; }
        }

        public Synapse Receiver
        {
            get { return receiver; }
        }
        public bool IsStateNascent
        {
            get { return state != InternalState.Nascent; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public Sensor(SensInput sensInput, UInt64 simtimeCreation, string name = null)
            : base(simtimeCreation, name)
        {
            type = VertexType.sensor;
            this.sensInput = sensInput;
            // Logger.LogLine(String.Format("NEW SENSOR {0} ADDED", Name));
            receiver = null;        // neuron.AddSensConn(this, simtimeCreation);
            timeSensing = 1500;     // Initial sensing time after which stimulated sensor starts to react on intput presented to the sensor y = 1
            timeRecovering = 5000;     // The time after which sensor returns to its resting state y = 0 if no other stimulation comes again during this time
            state = InternalState.Nascent;
            
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public override void Update(Vertex sender, UInt64 currentSimTime, object eventObject, UInt32 duration)
        {   // SENSOR
            if (sender == this)
            {
                if ((state == InternalState.Nascent) || (state == InternalState.Appearing))
                {
                    // Do not update timeUpdate here!!! because of:  events.AddEvent(this, this, timeUpdate + timeSensing);
                    // timeSensing > timeCreateView HAVE TO BE!
               
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        if (state == InternalState.Nascent)
                        {
                            // The creation process of the neuron is finished. Now it can start working.
                            // Logger.LogLine(String.Format("SENSOR {0} HAS BEEN CREATED AT SIMTIME {1}", Name, currentSimTime));
                        }

                        

                        // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.Sensing;

                        // Now it can start sensing that will take: timeSensing - timeCreateView
                        events.AddEvent(this, this, timeUpdate + timeSensing);  // timeUpdate not currentSimTime! BECAUSE Creation is included in the timeSensing

                        // If the sensor is new and not other vertex responses, the neuron and the connection between them should be created now:
                        if (receiver == null)
                        {
                            Neuron neuron = new Neuron(currentSimTime, this, Name);
                            receiver = neuron.AddSensConn(this, currentSimTime);    // The connection should be created in time <= timeSensing - timeCreateView
                        }
                    }
                }
                else if (state == InternalState.Sensing)
                {
                    timeUpdate = currentSimTime;

                    // The sensors starts stimulating the connected vertex and recovering to its resting state
                    y = 1;

                   

                    // Start stimulation of the connected vertex
                    events.AddEvent(this, receiver, timeUpdate);

                    // CHANGE OF ITS INTERNAL STATE:
                    state = InternalState.Recovering; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)

                    // START RECOVERING PROCESS OF THE SENSOR AND ITS GRADUAL DISAPPEARING:
                    actionInterval = timeRecovering;   // Time of gradual recovering and disappearing in the view
                    actionBeginTime = currentSimTime;
                    if (animate) actionSteps = 10;
                    else actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 1;
                    activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                }
                else if (state == InternalState.Recovering)
                {
                    // Start disappearing proces of the sensor
                   
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        timeUpdate = currentSimTime;
                        // Recover the sensor to its resting state
                        x = 0;
                        y = 0;
                        

                        // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.Resting; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                        activeEvent = null;
                    }
                }
            }
            else    //  (sender != this)
            {
                x = 1; // x = -1    - Sensors can be excitatory or inhibitory. Not implemented. Now only excitatory sensors exist!
                timeUpdate = currentSimTime;
                if (state == InternalState.Nascent)
                {
                    
                    // Start the creation process of its view
                    actionInterval = periodCreating;   // Time of creation the view
                    actionBeginTime = currentSimTime;
                    if (animate) actionSteps = 10;
                    else actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 1;
                    activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                }
                else
                {
                    // Quickly change Opacity = 1 of the sensor, connection and synapse
                    //SwitchVisability();
                    
                    // When new external stimulation comes I can only extend the Recovering process of the sensor. Not implemented.
                    // Logger.LogLine(String.Format("Sensor {0} has been stimulated at time {1}", Name, timeUpdate));

                    // Remove the recovering event if active! It enables to make the stimulation of the sensor repeated again. Sensing event is not stopped but continued.
                    if ((activeEvent != null) && (state == InternalState.Recovering))
                        events.RemoveOutdatedEvent(activeEvent);
                    // Do not repeat or start a new sensing during sensing process
                    if ((state != InternalState.Appearing) || (state != InternalState.Sensing))
                    {
                        // Start APPEARING making this sensor gradually visable again during timeCreateView time
                        actionInterval = periodCreating;   // appearing time is equal to creation time
                        actionBeginTime = currentSimTime;
                        actionSteps = 1;
                        actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                        actionStepCntr = 1;
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);

                        // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.Appearing; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)
                    }
                }
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
       
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class NumericalSensor : Sensor // Accepting various numerical data (double), with min, max available and sorted order using ASSORT
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        #endregion CONST AND READONLY FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected double value;
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public NumericalSensor(SensInput sensInput, UInt64 simtimeCreation, double value, string name = null)
            : base(sensInput, simtimeCreation, name)
        {
            type = VertexType.numericalsensor;
            this.value = value;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        //public void CreateView()
        //{
        //    ;
        //}
        //public void DestroyView()
        //{
        //    ((SensorView)view).DestroyView();
        //    view = null;
        //}
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    public class BooleanSensor : Sensor // Accepting various numerical data (double), with min, max available and sorted order using ASSORT
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        #endregion CONST AND READONLY FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected bool value;
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public BooleanSensor(SensInput sensInput, UInt64 simtimeCreation, bool value, string name = null)
            : base(sensInput, simtimeCreation, name)
        {
            type = VertexType.booleansensor;
            this.value = value;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        //public void CreateView()
        //{
        //    ;
        //}
        //public void DestroyView()
        //{
        //    ((SensorView)view).DestroyView();
        //    view = null;
        //}
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    public class SymbolicSensor : Sensor // Accepting various numerical data (double), with min, max available and sorted order using ASSORT
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        #endregion CONST AND READONLY FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected string value;
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public SymbolicSensor(SensInput sensInput, UInt64 simtimeCreation, string value, string name = null)
            : base(sensInput, simtimeCreation, name)
        {
            type = VertexType.symbolicsensor;
            this.value = value;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        //public new void CreateView()
        //{
        //    view = new SensorView(this);
        //    actionStepCntr = actionSteps = 1;
        //    ((SensorView)view).RecreateView();
        //}
        //public new void DestroyView()
        //{
        //    ((SensorView)view).DestroyView();
        //    view = null;
        //}
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    public class Effector : Vertex // Associative Effector
    {
        public enum InternalState : sbyte
        {
            Nascent = -100,
            Appearing = -50,
            Recovering = -1,
            Resting = 0,
            Effecting = 1,
        }
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONST AND READONLY FIELDS
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected EffOutput effOutput;      // An effector output to which this effector is connected
        protected Synapse sender;           // A synapse or neuron that sends the output
        protected UInt32 timeEffecting;     // The time that lapses from starting stimulation of this effector to make change in Effectorial Output
        protected UInt32 timeRecovering;    // The time that have to lapse from the last stimulation of this sensor to return it back to its resting state
        protected InternalState state;      // Actual state
        //protected EffectorView view;        // The view for this effector
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public Synapse Sender
        {
            get { return sender; }
        }
        public UInt32 TimeEffecting
        {
            get { return timeEffecting; }
        }
        public bool IsStateNascent
        {
            get { return state != InternalState.Nascent; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public Effector(EffOutput effOutput, Neuron neuron, UInt64 simtimeCreation, string name = null)
            : base(simtimeCreation, name)
        {
            type = VertexType.effector;
            this.effOutput = effOutput;
            // Logger.LogLine(String.Format("NEW EFFECTOR {0} ADDED", Name));
            timeEffecting = 1000;       // The time necessary to respond to the input stimulation and produce reaction of the effector that passes its Name to the EffOutput
            timeRecovering = 5000;     // The time after which sensor returns to its resting state y = 0 if no other stimulation comes again during this time
            state = InternalState.Nascent;
            activeEvent = events.AddEvent(effOutput, this, simtimeCreation); // The effector view must be created before the connection to it!
            sender = neuron.AddEffConn(this, simtimeCreation);
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public override void Update(Vertex sender, UInt64 currentSimTime, object eventObject, UInt32 duration)
        {   // EFFECTOR
            if (sender == this)
            {
                if (state == InternalState.Nascent)
                {
                    // Do not update timeUpdate here!!! because of:  events.AddEvent(this, this, timeUpdate + timeEffecting);
                    // timeEffecting > timeCreateView HAVE TO BE!
                    // Animate and continue the creation process of its view
                    
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        // The creation process of the neuron is finished. Now it can start working.
                        // Logger.LogLine(String.Format("EFFECTOR {0} HAS BEEN CREATED AT SIMTIME {1}", Name, currentSimTime));
                        
                        // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.Resting;
                        activeEvent = null;
                    }
                }
                else if (state == InternalState.Effecting)
                {
                    timeUpdate = currentSimTime;

                    // The sensors starts stimulating the connected vertex and recovering to its resting state
                    y = 1;

                   
                    // Start stimulation of the connected vertex
                    events.AddEvent(this, effOutput, timeUpdate);

                    // CHANGE OF ITS INTERNAL STATE:
                    state = InternalState.Recovering; // WHITE WITH YELLOW CENTER VIEW, Content = 0 - at the resting state (-70mV)

                    // START RECOVERING PROCESS OF THE SENSOR AND ITS GRADUAL DISAPPEARING:
                    actionInterval = timeRecovering;   // Time of gradual recovering and disappearing in the view
                    actionBeginTime = currentSimTime;
                    if (animate) actionSteps = 10;
                    else actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 1;
                    activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                }
                else if (state == InternalState.Recovering)
                {
                    // Start disappearing proces of the effector
                   
                    actionStepCntr++;
                    if (actionStepCntr < actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    else if (actionStepCntr == actionSteps) activeEvent = events.AddEvent(this, this, actionBeginTime + actionInterval);
                    else
                    {
                        timeUpdate = currentSimTime;
                        // Recover the sensor to its resting state
                        x = 0;
                        y = 0;

                       

                        // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.Resting;
                        activeEvent = null;
                    }
                }
            }
            else    //  (sender != this)
            {
                timeUpdate = currentSimTime;
                if (state == InternalState.Nascent)
                {

                    // Start the creation process of its view
                    actionInterval = periodCreating;   // Time of creation the view
                    actionBeginTime = currentSimTime;
                    if (animate) actionSteps = 10;
                    else actionSteps = 1;
                    actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                    actionStepCntr = 1;
                    activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                }
                else
                {
                    x = sender.Y; // * -1/+1    - Effectors can be excitatory or inhibitory. Not implemented. Now only excitatory sensors exist!
                    // When new external stimulation comes I can only extend the Recovering process of the sensor. Not implemented.
                    // Logger.LogLine(String.Format("Effector {0} has been stimulated at time {1}", Name, timeUpdate));

                    // Remove the recovering event if active! It enables to make the stimulation of the sensor repeated again. Sensing event is not stopped but continued.
                    if ((activeEvent != null) && (state == InternalState.Recovering))
                        events.RemoveOutdatedEvent(activeEvent);

                    if (x != 0)
                    {
                        // CHANGE OF ITS INTERNAL STATE:
                        state = InternalState.Effecting;

                        // Start the effecting process of its view
                        actionInterval = timeEffecting;
                        actionBeginTime = currentSimTime;
                        actionSteps = 1;
                        actionStepInterval = (UInt32)(actionInterval / (double)actionSteps);
                        actionStepCntr = 1;
                        activeEvent = events.AddEvent(this, this, actionBeginTime + actionStepCntr * actionStepInterval);
                    }
                }
            }
        }
        
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public abstract class SensInput : Vertex // Sensorial Input
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        //protected SortedList<string, Sensor> sensors; // list of sensors connected to this SensInput field
        //protected SensInputView view;
        protected string inputData;
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES

        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public SensInput(ANAKG anakg, string name)
            : base(0, "SensInputFor " + name)  // Created in SimTime = 0
        {
            type = VertexType.sensinput;
            //sensors = new SortedList<string, Sensor>(StringComparer.CurrentCultureIgnoreCase);
            //// Logger.LogLine(String.Format("NEW SENSORY INPUT ADDED"));
            inputData = "";
            //this.name = name;
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        //public Sensor AddSensor(UInt64 currentSimTime, string name)
        //{
        //    Sensor sensor = new Sensor(this, currentSimTime, name);
        //    sensors.Add(name, sensor);
        //    return sensor;
        //}

        //public void IntroduceSequence(String[] words, bool plasticity = false, byte repetitions = 1)
        //{
        //    // Add new events into EventList after external stimuli:
        //    UInt64 stimulationTimeOfNextObject = anakg.Events.SimTime;    // The actual simulation time is the time when the sequence will be presented to the ANAKG
        //    // Clean EffOutput
        //    Erase();
        //    byte repetitionCntr = 0;
        //    // First, add to the event queue all events 
        //    do
        //    {
        //        repetitionCntr++;
        //        inputData = "";
        //        for (int i = 0; i < words.Length; i++)  // foreach (string word in words), because words have to be processed in order!
        //        {
        //            // Compute simulation time of presenting this word
        //            if (plasticity) stimulationTimeOfNextObject += (uint)(1000 * anakg.DelayFollowingObjectLearn);
        //            else stimulationTimeOfNextObject += (uint)(1000 * anakg.DelayFollowingObjectAsk);
        //            // Show the next word
        //            inputData += words[i] + " ";
        //            ShowInView();
        //            // Try to find the existing Sensor that will recognize this stimuli/word. It it does not exist create new one and simulataneously neuron and effector that also do not exist
        //            Sensor sensor = null;
        //            if (!(sensors.TryGetValue(words[i], out sensor)))
        //            {
        //                if (plasticity)
        //                {
        //                    // Create a new sensor for this input
        //                    sensor = AddSensor(stimulationTimeOfNextObject, words[i]);
        //                }
        //            }
        //            // If sensor exist or have been created add an Event else if we are in asking mode and sensor does not exist don't send an Event
        //            if (sensor != null) events.AddEvent((Vertex)this, (Vertex)sensor, stimulationTimeOfNextObject);
        //        }
        //    } while (repetitionCntr < repetitions);
        //    anakgMainWindow.SensInput.Text = inputData + " [" + repetitions + "x]";
        //    anakgMainWindow.UpdateView();
        //}
        public override void Update(Vertex sender, UInt64 startSimTime, object eventObject, UInt32 duration)
        {
        }
        public void EraseInputData()
        {
            inputData = "";
            //ShowInView();
        }
        public abstract void AddDuration(UInt32 stimulationDuration, UInt64 expositionSimTime);
        public abstract void AddObject(object objectData, UInt64 expositionSimTime);
        public abstract void AddEventsForObjects();
        //public abstract void CreateView();
        //public abstract void DestroyView();
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class NumericalObject
    {
        public double valueNumerical { get; set; }
        public UInt64 startSimTime { get; set; }
        public UInt32 durationStimulation { get; set; }
    }
    //***********************************************************************************************************************************************
    public class NumericalSensInput : SensInput // Numerical Sensorial Input
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        List<NumericalObject> inputObjectList;
        protected SortedList<double, NumericalSensor> sensors; // list of sensors connected to this SensInput field
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public SortedList<double, NumericalSensor> Sensors
        {
            get { return sensors; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public NumericalSensInput(ANAKG anakg, string name = "") : base(anakg, name)
        {
            type = VertexType.numericalsensinput;
            inputObjectList = new List<NumericalObject>();
            sensors = new SortedList<double, NumericalSensor>();
            // Logger.LogLine(String.Format("NEW NUMERICAL SENSORY INPUT ADDED"));
           
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS

        public override void AddObject(object numericalData, UInt64 expositionSimTime)
        {
            NumericalObject newNumericalObject = new NumericalObject();
            newNumericalObject.valueNumerical = (double)numericalData;
            newNumericalObject.startSimTime = expositionSimTime;
            newNumericalObject.durationStimulation = 0;       // All input stimulations are sent once by default
            inputObjectList.Add(newNumericalObject);
        }
        public override void AddDuration(UInt32 stimulationDuration, UInt64 expositionSimTime)
        {
            foreach (NumericalObject newNumericalObject in inputObjectList)
            {
                if (newNumericalObject.startSimTime == expositionSimTime)
                    if (newNumericalObject.durationStimulation == 0)    // It is applied only to objects which were not previously set, because there can be many groups of objects insite the group of parallel objects
                        newNumericalObject.durationStimulation = stimulationDuration;
            }
        }
        public override void AddEventsForObjects()
        {
            // The completed list for each pattern will be terminated and all objects will be converted to events
            foreach (NumericalObject newNumericalObject in inputObjectList)
            {
                events.AddEvent(this, this, newNumericalObject.startSimTime, newNumericalObject.valueNumerical, newNumericalObject.durationStimulation);
            }
            inputObjectList.RemoveRange(0, inputObjectList.Count);  // RemoveAll:    inputObjectList.RemoveAll();
        }
        protected NumericalSensor AddSensor(UInt64 currentSimTime, object eventObject)
        {
            String name = String.Format("{0:G6}", (double)eventObject);
            name = name.Replace(',', '.'); // Use English decimal point
            NumericalSensor sensor = new NumericalSensor(this, currentSimTime, (double)eventObject, name);
            sensors.Add((double)eventObject, sensor);
            return sensor;
        }
        public override void Update(Vertex sender, UInt64 startSimTime, object eventObject, UInt32 duration)
        {
            if (sender == this)
            {
                // Try to find the existing Sensor that will recognize this stimuli/word. If it does not exist create new one and simulataneously neuron and effector that also do not exist
                NumericalSensor sensor = null;
                //if (!(sensors.TryGetValue(words[i], out sensor)))
                if (!(sensors.TryGetValue((double)eventObject, out sensor)))
                {
                    if (anakg.Plasticity)
                    {
                        // Create a new sensor for this input
                        sensor = AddSensor(startSimTime, eventObject);
                    }
                }
                // If sensor exist or have been created add an Event else if we are in asking mode and sensor does not exist don't send an Event
                if (sensor != null) events.AddEvent(this, sensor, startSimTime);
            }
        }
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class BooleanObject
    {
        public bool valueBoolean { get; set; }
        public UInt64 startSimTime { get; set; }
        public UInt32 durationStimulation { get; set; }
    }
    //***********************************************************************************************************************************************
    public class BooleanSensInput : SensInput // Boolean Sensorial Input
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        List<BooleanObject> inputObjectList;
        protected SortedList<bool, BooleanSensor> sensors; // list of sensors connected to this SensInput field
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public SortedList<bool, BooleanSensor> Sensors
        {
            get { return sensors; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public BooleanSensInput(ANAKG anakg, string name = "") : base(anakg, name)
        {
            type = VertexType.booleansensinput;
            inputObjectList = new List<BooleanObject>();
            sensors = new SortedList<bool, BooleanSensor>();
            // Logger.LogLine(String.Format("NEW BOOLEAN SENSORY INPUT ADDED"));
            ///view = new BooleanSensInputView(this);
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS

        public override void AddObject(object booleanData, UInt64 expositionSimTime)
        {
            BooleanObject newBooleanObject = new BooleanObject();
            newBooleanObject.valueBoolean = (bool)booleanData;
            newBooleanObject.startSimTime = expositionSimTime;
            newBooleanObject.durationStimulation = 0;       // All input stimulations are sent once by default
            inputObjectList.Add(newBooleanObject);
        }
        public override void AddDuration(UInt32 stimulationDuration, UInt64 expositionSimTime)
        {
            foreach (BooleanObject newBooleanObject in inputObjectList)
            {
                if (newBooleanObject.startSimTime == expositionSimTime)
                    if (newBooleanObject.durationStimulation == 0)    // It is applied only to objects which were not previously set, because there can be many groups of objects insite the group of parallel objects
                        newBooleanObject.durationStimulation = stimulationDuration;
            }
        }
        public override void AddEventsForObjects()
        {
            // The completed list for each pattern will be terminated and all objects will be converted to events
            foreach (BooleanObject newBooleanObject in inputObjectList)
            {
                events.AddEvent(this, this, newBooleanObject.startSimTime, newBooleanObject.valueBoolean, newBooleanObject.durationStimulation);
            }
            inputObjectList.RemoveRange(0, inputObjectList.Count);  // RemoveAll:    inputObjectList.RemoveAll();
        }
        protected BooleanSensor AddSensor(UInt64 currentSimTime, object eventObject)
        {
            string name = ((bool)eventObject ? "TRUE" : "FALSE");
            BooleanSensor sensor = new BooleanSensor(this, currentSimTime, (bool)eventObject, name);
            sensors.Add((bool)eventObject, sensor);
            return sensor;
        }
        public override void Update(Vertex sender, UInt64 startSimTime, object eventObject, UInt32 duration)
        {
            if (sender == this)
            {
                // Try to find the existing Sensor that will recognize this stimuli/word. It it does not exist create new one and simulataneously neuron and effector that also do not exist
                BooleanSensor sensor = null;
                if (!(sensors.TryGetValue((bool)eventObject, out sensor)))
                {
                    if (anakg.Plasticity)
                    {
                        // Create a new sensor for this input
                        sensor = AddSensor(startSimTime, eventObject);
                    }
                }
                // If sensor exist or have been created add an Event else if we are in asking mode and sensor does not exist don't send an Event
                if (sensor != null) events.AddEvent(this, sensor, startSimTime);
            }
        }
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class SymbolicObject
    {
        public string valueSymbolic { get; set; }
        public UInt64 startSimTime { get; set; }
        public UInt32 durationStimulation { get; set; }
    }
    //***********************************************************************************************************************************************
    public class SymbolicSensInput : SensInput // Numerical Sensorial Input
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        List<SymbolicObject> inputObjectList;
        protected SortedList<string, SymbolicSensor> sensors; // list of sensors connected to this SensInput field
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public SortedList<string, SymbolicSensor> Sensors
        {
            get { return sensors; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public SymbolicSensInput(ANAKG anakg, string name = "") : base(anakg, name)
        {
            type = VertexType.symbolicsensinput;
            inputObjectList = new List<SymbolicObject>();
            sensors = new SortedList<string, SymbolicSensor>();
            // Logger.LogLine(String.Format("NEW SYMBOLIC SENSORY INPUT ADDED"));
            ///view = new SymbolicSensInputView(this); // Sensory Input and Effectory Output Views are always created to enable learning and asking
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
       
        //-----------------------------------------------------------------------------------------------------------------------------
        public override void AddObject(object symbolicData, UInt64 expositionSimTime)
        {
            SymbolicObject newSymbolicObject = new SymbolicObject();
            if ((symbolicData.GetType()).Equals(typeof(Double))) newSymbolicObject.valueSymbolic = symbolicData.ToString();
            else if ((symbolicData.GetType()).Equals(typeof(Boolean))) newSymbolicObject.valueSymbolic = symbolicData.ToString();
            else newSymbolicObject.valueSymbolic = (string)symbolicData;
            newSymbolicObject.startSimTime = expositionSimTime;
            newSymbolicObject.durationStimulation = 0;       // All input stimulations are sent once by default
            inputObjectList.Add(newSymbolicObject);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public override void AddDuration(UInt32 stimulationDuration, UInt64 expositionSimTime)
        {
            foreach (SymbolicObject newSymbolicObject in inputObjectList)
            {
                if (newSymbolicObject.startSimTime == expositionSimTime)
                    if (newSymbolicObject.durationStimulation == 0)    // It is applied only to objects which were not previously set, because there can be many groups of objects insite the group of parallel objects
                        newSymbolicObject.durationStimulation = stimulationDuration;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public override void AddEventsForObjects()
        {
            // The completed list for each pattern will be terminated and all objects will be converted to events
            foreach (SymbolicObject newSymbolicObject in inputObjectList)
            {
                events.AddEvent(this, this, newSymbolicObject.startSimTime, newSymbolicObject.valueSymbolic, newSymbolicObject.durationStimulation);
            }
            inputObjectList.RemoveRange(0, inputObjectList.Count);  // RemoveAll:    inputObjectList.RemoveAll();
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected SymbolicSensor AddSensor(UInt64 currentSimTime, object eventObject)
        {
            string name = ((string)eventObject).ToUpper();    // If the string is too long its name is truncated to 7 first letters
            SymbolicSensor sensor = new SymbolicSensor(this, currentSimTime, (string)eventObject, name);
            sensors.Add((string)eventObject, sensor);
            return sensor;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public override void Update(Vertex sender, UInt64 startSimTime, object eventObject, UInt32 duration)
        {   // Symbolic Sensory Input
            if (sender == this)
            {
                // Try to find the existing Sensor that will recognize this stimuli/word. It it does not exist create new one and simulataneously neuron and effector that also do not exist
                SymbolicSensor sensor = null;
                if (!(sensors.TryGetValue((string)eventObject, out sensor)))
                {
                    if (anakg.Plasticity)
                    {
                        // Create a new sensor for this input
                        sensor = AddSensor(startSimTime, eventObject);
                    }
                }
                //if (animate)
                //{
                // View this exposed value in the SensInput field
         
                //}
                // Update last update time of this element
                timeUpdate = startSimTime;  // defines a moment of last update of the effectorial output field / console
                // If sensor exist or have been created add an Event else if we are in asking mode and sensor does not exist don't send an Event
                if (sensor != null) events.AddEvent(this, sensor, startSimTime);
            }
        }
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class EffOutput : Vertex // Effectorial Output
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected SortedList<string, Effector> effectors; // list of effectors connected to this EffOutput field
        protected String outputSequencePattern;    // String output representing output sequence pattern
        //protected EffOutputView view;   // This is the view created for this elemement
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES

        public String OutputSequencePattern
        {
            get { return outputSequencePattern; }
        }
        public SortedList<string, Effector> Effectors
        {
            get { return effectors; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public EffOutput(ANAKG anakg)
            : base(0, "EffOutput")  // Created in SimTime = 0
        {
            type = VertexType.effoutput;
            effectors = new SortedList<string, Effector>(StringComparer.CurrentCultureIgnoreCase);
            // Logger.LogLine(String.Format("NEW WORD OUTPUT ADDED"));
            outputSequencePattern = "";
            ///view = new EffOutputView(this); // Sensory Input and Effectory Output Views are always created to enable learning and asking
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public Effector AddEffector(Neuron neuron, UInt64 currentSimTime, string name)
        {
            Effector effector = new Effector(this, neuron, currentSimTime, name);
            effectors.Add(name, effector);
            return effector;
        }
        public override void Update(Vertex sender, UInt64 startSimTime, object eventObject, UInt32 duration)
        {
            timeUpdate = startSimTime;  // defines a moment of last update of the effectorial output field / console
            outputSequencePattern += sender.Name + " ";
            
            // EffOutput is not generating a new event because signal goes outside the ANG (output console) that can be read in various way by the computer program, real effector (a muscule, a engine) etc.
        }
        public void Erase()
        {
            outputSequencePattern = "";
        }
       
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    //***********************************************************************************************************************************************
    public class Event // Effectorial Output
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected Vertex sender;        // The element that sends the event into the queue of events (initiator)
        protected Vertex receiver;      // The element (vertex) that receives this event from the queue of events to start a defined action (actor)
        protected UInt64 startTime;     // Simulation time of starting this event in receiver as well as the time when sender has sent this event to receiver
        protected object eventObject;   // eventObject that starts at startTime
        protected UInt32 duration;      // Duration of the event that is sometimes not an impuls with duration 0 (default) but longer, especially for external input stimulation of sensors
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public Vertex Sender
        {
            get { return sender; }
        }
        public Vertex Receiver
        {
            get { return receiver; }
        }
        public UInt64 StartTime
        {
            get { return startTime; }
        }
        public UInt32 Duration
        {
            get { return duration; }
        }
        public object EventObject
        {
            get { return eventObject; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public Event(Vertex sender, Vertex receiver, UInt64 startTime, object eventObject = null, UInt32 duration = 0)
        {
            this.sender = sender;
            this.receiver = receiver;
            this.startTime = startTime;
            this.eventObject = eventObject;
            this.duration = duration;
            // Logger.LogLine(String.Format("NEW EVENT {0} ADDED (by {1}). It will start at SIMTIME {2} and will take {3} time (duration)", receiver.Name, sender.Name, startTime, duration));
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS

        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    public class EventQueue // Priority Queue of EventQueue
    {
        #region STATIC FIELDS
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected ANAKG anakg;
        protected SortedList<UInt64, Event> events;
        protected UInt64 simTime;   // simulation time
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public UInt64 SimTime
        {
            get { return simTime; }
            set { simTime = value; }
        }
        public SortedList<UInt64, Event> EventSortList
        {
            get { return events; }
        }
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public EventQueue(ANAKG anakg)
        {
            this.anakg = anakg;
            // Utwórz pustą kolejkę zdarzeń:
            events = new SortedList<UInt64, Event>();
            simTime = 0;
            //Logger.Reset(); // Kasuje zawartość // Loggera
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public Event AddEvent(Vertex sender, Vertex receiver, UInt64 sendSimTime, object eventObject = null, UInt32 duration = 0)  // sendTime is the absolute simulation time, in which sender generates this Event, receiver itself decides how much time is necessary for it to receive and process this Event to finish it. 
        {
            UInt64 sequentialTime = sendSimTime;  // actual sequential time that slightly differs from simulation time, because sequentialTime for each Event must differ in comparison to simTime of various events can be sometimes the same!
            Event newEvent = new Event(sender, receiver, sendSimTime, eventObject, duration);   // Each event remembers the exact simTime + relStartTime
            while (events.ContainsKey(sequentialTime)) sequentialTime++;    // This is necessary to use SortList in which all keys must differ! This loop is searching for the first unused key bigger than the given simTime + relStartTime
            events.Add(sequentialTime, newEvent);
            return newEvent;    // The pointer to the created event is send back to the sender in order to delete this event in case something happend before this event will come into action.
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void RemoveOutdatedEvent(Event outdatedEvent)
        {
            // Logger.LogLine(String.Format("OUTDATED EVENT {0} REMOVED AT SIMTIME {1}", outdatedEvent.Receiver.Name, outdatedEvent.StartTime));
            if (events.IndexOfValue(outdatedEvent) >= 0)    // Check if outdatedEvent does exist in the queue of events? If yes remove it.
            {
                int indexOfOutdatedEvent = events.IndexOfValue(outdatedEvent);
                events.RemoveAt(indexOfOutdatedEvent);
                //- events.Remove(outdatedEvent.StartTime); This cannot be applied because a few Events have the same simTime and this will sometimes remove the another event!!!
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void StartSimulation()
        {
            // Read sequentially simulation events and execute them (run defined actions)
            Event firstEvent;
            //UInt64 lastViewUpdate = 0;
            UInt64 lastSensoryStimulus = events.Last().Key;
            if (Vertex.IsTuning)
                Vertex.StopStimulatingNeurons = lastSensoryStimulus + 1 * 4 * 1000;  // 10 - a number of objects after the last stimulus, 4 - next object, 1000 - time multiplicator
            else Vertex.StopStimulatingNeurons = 0; // Means do not stop it!
            while (events.Count > 0)
            {
                // Take off the earliest event and update simulation time
                firstEvent = events.First().Value;
                simTime = firstEvent.StartTime;   // Discretely update simulation time
                events.RemoveAt(0);

                // Process the fristEvent
                firstEvent.Receiver.Update(firstEvent.Sender, firstEvent.StartTime, firstEvent.EventObject, firstEvent.Duration);   // When updating there is taken the exactly remembered simTime, not sequentialTime!

            
                //else
                //{
                //if ((simTime - lastViewUpdate >= 1000) || (events.Count == 0))
                //{
                //    anakg.View.UpdateView();
                //    lastViewUpdate = simTime;
                //}
                //}
            }
            simTime += 150000;  // 60000;   // It allows for cutting of objects from the following training sequences that are not in context.
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public UInt64 AddSimulatioTime(UInt64 interval)
        {
            // You can move simulation time only if there are no Events in the queue
            if (events.Count == 0) simTime += interval;
            return simTime;
        }
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
    public class ANAKG // Associative Neural Graph
    {
        public enum AttributeType : byte
        {
            Undefined = 0,
            Symbolic = 1,
            Numerical = 2,
            Boolean = 3,        //+ Not implemented
            Structured2D = 4,   //+ Not implemented
            Structured3D = 5    //+ Not implemented
        }
        #region STATIC FIELDS
        protected static UInt32 noActiveSynapsesInTuningCycle;
        #endregion STATIC FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region FIELDS
        protected static bool animate;
        protected static bool collectStatistics;
        ANAKGMainWindow anakgMainWindow;
        protected bool plasticity;
        protected byte delayFollowingSequence;
        protected byte delayFollowingObjectMin;
        protected byte delayFollowingObjectMax;
        protected byte delayFollowingObject;
        protected byte delayFollowingObjectAsk;
        protected byte delayFollowingObjectSpace;
        protected byte delayFollowingObjectLearn;
        protected UInt16 maxTuneCycles;     // Maximum tuning cycles when the tuning process will be not convergent and does not stop earlier
        protected EventQueue events;
        //        protected SensInput sensInput;  // connected to the input console to gather sequences
        protected SortedDictionary<string, SensInput> sensInputs; // list of sensory inputs
        protected EffOutput effOutput;  // connected to the output console to show up results
        protected SortedDictionary<string, Neuron> neurons; // list of neurons that can be used in the interface (View & Controler)
        protected List<string> sequenceSet; // list of (training) sequences, read from a text file or a keaboard input
        protected List<String> data;
        //protected UInt16 createPhaseCntr;
        protected UInt16 tuningPhaseCntr;
        private int dataCntr;
        //protected ANAKGView view;
        protected int noLearnedObjects;
        protected int noLearnedSequences;
        long ticksLearningTime;
        TimeSpan elapsedSequenceLearningTime;
        AttributeType attributeType;
        //protected UInt32 noIncorrectSeqActivations;
        #endregion FIELDS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region PROPERTIES
        public static UInt32 NoActiveSynapsesInTuningCycle
        {
            get { return noActiveSynapsesInTuningCycle; }
            set { noActiveSynapsesInTuningCycle = value; }
        }
        public static bool Animate
        {
            get { return animate; }
            set { animate = value; }
        }
        public static bool CollectStatistics
        {
            get { return collectStatistics; }
            set { collectStatistics = value; }
        }
        public byte DelayFollowingObjectLearn
        {
            get { return delayFollowingObjectLearn; }
            set { delayFollowingObjectLearn = value; }
        }
        public byte DelayFollowingObjectAsk
        {
            get { return delayFollowingObjectAsk; }
            set { delayFollowingObjectAsk = value; }
        }
        public UInt16 MaxTuneCycles
        {
            get { return maxTuneCycles; }
            set { maxTuneCycles = value; }
        }
        public byte DelayFollowingSequence
        {
            get { return delayFollowingSequence; }
        }
        public byte DelayFollowingObjectSpace
        {
            get { return delayFollowingObjectSpace; }
            set { delayFollowingObjectSpace = value; }
        }
        public EventQueue Events
        {
            get { return events; }
        }
        public SortedDictionary<string, SensInput> SensInputs
        {
            get { return sensInputs; }
        }
        public EffOutput EffOutputs
        {
            get { return effOutput; }
        }
        public SortedDictionary<string, Neuron> Neurons
        {
            get { return neurons; }
        }
        public List<string> SequenceSet
        {
            get { return sequenceSet; }
        }
        public bool Plasticity
        {
            get { return plasticity; }
        }
        public int NoLearnedObjects
        {
            get { return noLearnedObjects; }
        }
        public int NoLearnedSequences
        {
            get { return noLearnedSequences; }
        }
        public TimeSpan ElapsedSequenceLearningTime
        {
            get { return elapsedSequenceLearningTime; }
        }
        //public UInt32 NoIncorrectSeqActivations
        //{
        //    get { return noIncorrectSeqActivations; }
        //    set { noIncorrectSeqActivations = value; }
        //}
        #endregion PROPERTIES
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region CONSTRUCTORS
        public ANAKG()
        {
            plasticity = true;
            //this.anakgMainWindow = anakgMainWindow;
            
            Vertex.Anakg = this;

            // It should not create the view when this application starts
            animate = true;
            ///view = null;
            collectStatistics = false;

            // Revise because delayFollowingObjectSpace == delayFollowingObjectLearn (== delayFollowingObjectAsk) == delayFollowingObject
            delayFollowingObjectMin = 3;
            delayFollowingObjectMax = 10;   // Cannot be less than 4 bacause the neuron must be able to charge the next one:  3 charging + 0.95 transfering + 3 charging = 6.95. But the following internal activations can come after less than 4!
            delayFollowingObjectSpace = 4; // 4 - was not enough Cannot be less than 4 bacause the neuron must be able to charge the next one:  3 charging + 0.95 transfering + 3 charging = 6.95. But the following internal activations can come after less than 4!
            delayFollowingObjectLearn = 4;  // 4 - was not enough Cannot be less than 4 bacause the neuron must be able to charge the next one:  3 charging + 0.95 transfering + 3 charging = 6.95. But the following internal activations can come after less than 4!
            delayFollowingObjectAsk = 4;   // 4 - was not enough Cannot be less than 4 bacause the neuron must be able to charge the next one:  3 charging + 0.95 transfering + 3 charging = 6.95. But the following internal activations can come after less than 4!
            delayFollowingObject = delayFollowingObjectLearn;
            delayFollowingSequence = 100;
            maxTuneCycles = 50;    // Initial value

            // Create Event Queue and pass it to all vertices as a static field to make it available
            events = new EventQueue(this);
            Vertex.Events = events;

            // Create Sensory Input and Effector Output
            sensInputs = new SortedDictionary<string, SensInput>(StringComparer.CurrentCultureIgnoreCase);
            //sensInput = new SensInput(this);
            effOutput = new EffOutput(this);

            // Create Neuron List for storing all Neurons sorted lexicographicaly after words they represent
            neurons = new SortedDictionary<string, Neuron>(StringComparer.CurrentCultureIgnoreCase);
            //Vertex.No = 0;
            Vertex.Phase = AdaptationPhase.CreateNetwork;
            Neuron.Counter = 0;
            Neuron.ActivityNoMax = 0;
            //Neuron.GrowThresholdCoefInitial = 1.0;  // 0.1 disables initial fast grow of thresholds
            Neuron.MaxThreshold = 1;
            Neuron.TrainingCoefficient = 1.0;   // 0.5;
            Neuron.NumberMaxInSynapses = 0;
            Synapse.Counter = 0;
            Synapse.PermeabilityFormula = 0;
            
            Synapse.InitialMultiplication = 1.0;   // 1.0 ensures that unique items will be correctly multiplied // 0.2-1.0;    // In order to avoid incorrect order of activations at the beginning of the tuning process initial multiplication should not be equal 1.
            noLearnedSequences = 0;
            noLearnedObjects = 0;
            ticksLearningTime = 0;

            // Training or Asking data:
            data = null;    //+ You can read some default training data
            //createPhaseCntr = 0;
            tuningPhaseCntr = 0;
            dataCntr = 0;

            attributeType = AttributeType.Undefined;

            // Switch on LogBuilder
            //Logger.LogBuilder = true;   // Włącza LogBuilder
            //Logger.LogLine(String.Format("Sequences\tObjects\tNeurons\tConnections\tThresholdChanges\tWeightsChanges\tSimTime\tRealTime"));
            //Logger.LogLine(String.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}", 0, 0, Neuron.Counter, Synapse.Counter, Neuron.NoCycleThresholdChanges, Synapse.NoCycleWeightChanges, events.SimTime, elapsedSequenceLearningTime.TotalSeconds));  // DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        }
        #endregion CONSTRUCTORS
        //--------------------------------------------------------------------------------------------------------------------------------------------
        #region METHODS
        public void SaveLoggerIntoFile(string pathandfileName)
        {
            //Logger.Save(pathandfileName);   // Zapisuje zwartość loggera do pliku
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public bool Learn(string universalSequencePattern, AdaptationPhase phase = AdaptationPhase.CreateNetwork, UInt32 maxTuningCycles = 0)
        {
            Vertex.InitVariablesAfterSimTime = events.SimTime;
            if (phase == AdaptationPhase.CreateNetwork)
            {
                ///view.ShowActivationNos();
                if (!LearnPattern(universalSequencePattern)) return false;
            }
            if (phase == AdaptationPhase.AskNetwork)
            {
                Vertex.Phase = AdaptationPhase.AskNetwork;
                if (!LearnPattern(universalSequencePattern)) return false;
                ///view.ShowThresholds();
            }
            if (maxTuningCycles > 0)
            {
                //Vertex.InitVariablesAfterSimTime = events.SimTime;
                //Vertex.Phase = AdaptationPhase.AvoidUndemanded;
                //if (!LearnPattern(universalSequencePattern)) return false;
                //Vertex.InitVariablesAfterSimTime = events.SimTime;
                //Vertex.Phase = AdaptationPhase.AvoidTooEarly;
                //if (!LearnPattern(universalSequencePattern)) return false;
                Vertex.InitVariablesAfterSimTime = events.SimTime;
                Vertex.Phase = AdaptationPhase.AvoidIncorrect;
                if (!LearnPattern(universalSequencePattern)) return false;
            }
            for (Int32 cycle = 1; cycle <= maxTuningCycles; cycle++)
            {
                //for (byte tuningPhase = 1; tuningPhase <= 3; tuningPhase++)
                //{
                //    Vertex.InitVariablesAfterSimTime = events.SimTime;
                //    if (tuningPhase == 1) Vertex.Phase = AdaptationPhase.TuneConflicts;
                //    else if (tuningPhase == 2) Vertex.Phase = AdaptationPhase.AvoidUndemanded;
                //    else Vertex.Phase = AdaptationPhase.AvoidTooEarly;
                //    if (!LearnPattern(universalSequencePattern)) return false;
                //}
                for (byte tuningPhase = 1; tuningPhase <= 2; tuningPhase++)
                {
                    Vertex.InitVariablesAfterSimTime = events.SimTime;
                    if (tuningPhase == 1) Vertex.Phase = AdaptationPhase.TuneConflicts;
                    else Vertex.Phase = AdaptationPhase.AvoidIncorrect;
                    if (!LearnPattern(universalSequencePattern)) return false;
                }
                ///view.ShowThresholds();
            }
            return true;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void ReadDefaultData()
        {
            FileStream streampath = new FileStream("DefaultDataPath.txt", FileMode.Open, FileAccess.Read);
            StreamReader readerpath = new StreamReader(streampath);
            string datapath = readerpath.ReadLine();

            FileStream stream = new FileStream(datapath, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(stream);
            ReadData(reader);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void ReadData(StreamReader reader)
        {
            if (data != null) data.Clear();
            data = new List<String>();
            //createPhaseCntr = 0;
            tuningPhaseCntr = 0;
            string readLine = "";
            do
            {
                readLine = reader.ReadLine();
                if (readLine.Length > 0) data.Add(readLine);
            } while (reader.EndOfStream == false);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public string PreviousTrainingSequence()
        {
            if (dataCntr > 0) dataCntr--;
            return data.ElementAt(dataCntr);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public string NextTrainingSequence()
        {
            if (dataCntr < data.Count - 1) dataCntr++;
            return data.ElementAt(dataCntr);
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public string FirstTrainingSequence()
        {
            dataCntr = 0;
            return data.First();
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public string LastTrainingSequence()
        {
            dataCntr = data.Count - 1;
            return data.Last();
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public bool LearnFullSet(AdaptationPhase phase = AdaptationPhase.CreateNetwork, UInt32 maxTuningcycles = 200)
        {
            if (data == null) ReadDefaultData();

            // Moved into the loop
            //foreach (Neuron neuron in neurons.Values)
            //    neuron.InitCntrSynapticMultiplicationFactors();    // It is necessary because counters are incremented also for asking!

            if (phase == AdaptationPhase.TuneNetwork)   //++++++ Faza Create kończy się fazą AvoidIncorrect, więc powtórzenie jej na początku fazy tuningu jest zbędne i stratą czasu, bo robi to samo!
            {
                if (tuningPhaseCntr == 0) Vertex.Phase = AdaptationPhase.AvoidIncorrect;   // AdaptationPhase.AvoidUndemanded;   // If it is triggered immediatelly after Creation Phase, then AvoidUndemanded and AvoidTooEarly must be done before starting normal TuningCycle consisting of three tuning phases
                else Vertex.Phase = AdaptationPhase.TuneConflicts;
            }
            else Vertex.Phase = phase;
            UInt32 tuningCycles = maxTuningcycles;
            //Neuron.NullCycleThresholdChanges();
            Synapse.NullCycleWeightChanges();
            do
            {
                Vertex.InitVariablesAfterSimTime = events.SimTime;
                Neuron.NullNoIncompleteContextActivations();
                Neuron.NullInsufficientStimulationsNo();
                Neuron.NullNoUndesiredActivations();
                noActiveSynapsesInTuningCycle = 0;
                
                if (Vertex.IsTuning)
                {
                    if (Vertex.Phase == AdaptationPhase.TuneConflicts)
                    {
                        // The sums and counters of multiplication changes must be nulled always before the TuneConflicts Phase to compute average changes during this phase!
                        foreach (Neuron neuron in neurons.Values)
                            neuron.InitCntrSynapticMultiplicationFactors();    // It is necessary because counters are incremented also for asking!
                        //Neuron.NullCycleThresholdChanges();
                        Synapse.NullCycleWeightChanges();
                        tuningCycles--;
                        tuningPhaseCntr++;
                    }
                    //anakgMainWindow.Phase.Content = "Tune " + tuningPhaseCntr + (Vertex.Phase == AdaptationPhase.AvoidUndemanded ? "U" : (Vertex.Phase == AdaptationPhase.AvoidTooEarly ? "E" : "C"));
                    //anakgMainWindow.Phase.Content = "Tune " + tuningPhaseCntr + (Vertex.Phase == AdaptationPhase.AvoidIncorrect ? "I" : "C");
                    //Logger.LogLine(String.Format("START TUNING PHASE {0}", tunePhaseCntr));
                }
                else
                {
                    //anakgMainWindow.Phase.Content = "Create";
                    //Logger.LogLine(String.Format("START CREATION PHASE {0}", createPhaseCntr));
                }

                foreach (string line in data)
                {
                    LearnPattern(line);
                    // Here simulation time have to be shifted to cut off associations between words of the following training sequences!
                }
                // Update weights in the tuning mode
                //++++ Start from Vertex.Phase >= 3 because the 1. is AvoidUdesiredActivations, 2. AvoidTooEarlyActivations, 3. Tune
                if (Vertex.IsTuningConflicts)  //++++ if (Vertex.Phase >= 3)     if (Vertex.IsTuning)  //++++ if (Vertex.Phase >= 3)
                {   //!!! It does not do anything?! Could never satisfy inside condition to be exectuted!? CHECK IT!
                    //Logger.LogLine(String.Format("UPDATE SYNAPSES AT THE END OF THE TUNING PHASE AFTER COMPUTED PROPOSALS"));
                    foreach (Neuron neuron in neurons.Values)
                        neuron.UpdateSynapticMultiplicationFactors(tuningPhaseCntr);   // This function is used also before the tuning to initialize all multiplication counters, so it is correctly run for mode == 0!
                }
                
                //mode++;
                //if (Vertex.Phase == AdaptationPhase.CreateNetwork) Vertex.Phase = AdaptationPhase.AvoidUndemanded;
                if (collectStatistics && ((Vertex.Phase == AdaptationPhase.CreateNetwork) || (Vertex.Phase == AdaptationPhase.AvoidIncorrect)))
                {
                    AdaptationPhase currentPhase = Vertex.Phase;
                    AskFullSet();
                    Vertex.Phase = currentPhase;
                }

                if ((Vertex.Phase == AdaptationPhase.CreateNetwork) && (tuningCycles > 0)) Vertex.Phase = AdaptationPhase.AvoidIncorrect;
                else if (Vertex.Phase == AdaptationPhase.AvoidIncorrect) Vertex.Phase = AdaptationPhase.TuneConflicts;
                //else if (Vertex.Phase == AdaptationPhase.AvoidUndemanded) Vertex.Phase = AdaptationPhase.AvoidTooEarly;
                //else if (Vertex.Phase == AdaptationPhase.AvoidTooEarly) Vertex.Phase = AdaptationPhase.TuneConflicts;
                //else if (Vertex.Phase == AdaptationPhase.TuneConflicts) Vertex.Phase = AdaptationPhase.AvoidUndemanded;
                else if (Vertex.Phase == AdaptationPhase.TuneConflicts) Vertex.Phase = AdaptationPhase.AvoidIncorrect;
            } while (((Synapse.NoCycleWeightChanges > 0) && (Synapse.ChangeWeightInCycleMax > 0.01) && (tuningCycles > 0)) || (Vertex.Phase == AdaptationPhase.AvoidIncorrect));

            return true;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void AskFullSet()
        {
            if (data == null) ReadDefaultData();
            //? if (...) LearnFullSet(1, 200, 0);
            /*
            if (Vertex.Phase == AdaptationPhase.CreateNetwork) Logger.LogLine(String.Format("CREATION PHASE:0"));
            else Logger.LogLine(String.Format("TUNING PHASE Cycle:{0}:{1}:weights changes = {2} : maximum weight change = {3}", tuningPhaseCntr, Vertex.Phase, Synapse.NoCycleWeightChanges, Synapse.ChangeWeightInCycleMax));
            */
            //anakgMainWindow.Phase.Content = "Asking All";
            effOutput.Erase();
            // Change the behaviour of ANAKG to asking mode that does not change the structure and parameters of the ANAKG
            plasticity = false;
            Vertex.Phase = AdaptationPhase.AskNetwork;
            //Synapse.NullCycleWeightChanges();
            //Neuron.NullCycleThresholdChanges();
            foreach (string line in data)
            {
                string lineWithoutPunctuations = line.Replace(".", "");
                lineWithoutPunctuations = lineWithoutPunctuations.Replace("?", "");
                lineWithoutPunctuations = lineWithoutPunctuations.Replace("!", "");
                lineWithoutPunctuations = lineWithoutPunctuations.Replace(",", "");
                lineWithoutPunctuations = lineWithoutPunctuations.Replace(";", "");
                // Convert the line into the table of words
                string[] rowWords = lineWithoutPunctuations.Split(' ');

                string sequencialPattern = "";
                for (int cntrWords = 0; cntrWords < rowWords.Length - 1; cntrWords++)
                {
                    sequencialPattern += rowWords[cntrWords];

                    // Split pattern into sensory input channels and create lists of objects for each sensory input
                    ParseIntroducedPattern(sequencialPattern);

                    // Change these lists of objects to events that could be parallel, sequencial or both
                    foreach (SensInput sensInput in sensInputs.Values)
                    {
                        sensInput.AddEventsForObjects();
                    }

                    // Clean EffOutput
                    if (animate) effOutput.Erase();

                    // Start Simulation for this sequence of words added to EventList
                    events.StartSimulation();

                    // Write the result into the outputFile:
                    //Logger.LogLine(String.Format("CYCLE:{0}:ASKINGWordsNo:{1}:ASKINGContext:{2}:RECALLING:{3}", tuningPhaseCntr, cntrWords + 1, sequencialPattern, effOutput.OutputSequencePattern));

                    sequencialPattern += " ";
                }
            }
        }
        protected double ExtractNumericalData(string introducedPattern, ref int dataStartCntr)
        {
            double dataNumerical = 0;
            String patternNumerical = "";
            Regex regExpression = new Regex(@"^[+-]?\d+([,.]\d)?[0-9]*$");    //+ we don't consider here scientific format of numbers, if necessary the regular expression can be upgraded
                                                                              //Regex regExpressionInText = new Regex(@"^\d+([.\)])?$");    //+ we don't consider here scientific format of numbers, if necessary the regular expression can be upgraded
            if (regExpression.IsMatch(patternNumerical + introducedPattern[dataStartCntr]))
            {
                while (regExpression.Match(patternNumerical + introducedPattern[dataStartCntr]).Success)   //, RegexOptions.IgnoreCase
                {
                    patternNumerical += introducedPattern[dataStartCntr];
                    dataStartCntr++;
                    if (((introducedPattern[dataStartCntr] == '.') || (introducedPattern[dataStartCntr] == ',')) && (attributeType == AttributeType.Numerical))
                    {
                        patternNumerical += ',';    // There must be coma to pass Double.TryParse
                        dataStartCntr++;
                    }
                    if (dataStartCntr == introducedPattern.Length) break;
                }
                if ((patternNumerical[patternNumerical.Length - 1] == '.') || (patternNumerical[patternNumerical.Length - 1] == ',')) patternNumerical = patternNumerical.Substring(0, patternNumerical.Length - 1);
                Double.TryParse(patternNumerical, out dataNumerical);
            }
            //else if (regExpressionInText.IsMatch(patternNumerical + introducedPattern[dataStartCntr]))
            //{
            //    while (regExpressionInText.Match(patternNumerical + introducedPattern[dataStartCntr]).Success)   //, RegexOptions.IgnoreCase
            //    {
            //        if ((introducedPattern[dataStartCntr] != '.') && (introducedPattern[dataStartCntr] != ')')) Some numerical objects can include ranges, e.g. (1786-1859) - it means from to and shold be correctly interpreted!
            //        {
            //            patternNumerical += introducedPattern[dataStartCntr];
            //            dataStartCntr++;
            //        }
            //        else break;
            //        if (dataStartCntr == introducedPattern.Length) break;
            //    }
            //    int.TryParse(patternNumerical, out dataNumericalInText);
            //    dataNumerical = dataNumericalInText;
            //}
            //if (regExpression.IsMatch(patternNumerical + introducedPattern[dataStartCntr]))
            //{
            //    while ((Regex.Match(patternNumerical + introducedPattern[dataStartCntr], regExpression)).Success)   //, RegexOptions.IgnoreCase
            //    {
            //        patternNumerical += introducedPattern[dataStartCntr];
            //        dataStartCntr++;
            //        if (dataStartCntr == introducedPattern.Length) break;
            //    }
            //    Double.TryParse(patternNumerical, out dataNumerical);
            //}
            //else if (Regex.IsMatch(patternNumerical + introducedPattern[dataStartCntr], regExpressionInText))
            //{
            //    while ((Regex.Match(patternNumerical + introducedPattern[dataStartCntr], regExpressionInText)).Success)   //, RegexOptions.IgnoreCase
            //    {
            //        if ((introducedPattern[dataStartCntr] != '.') && (introducedPattern[dataStartCntr] != ')'))
            //        {
            //            patternNumerical += introducedPattern[dataStartCntr];
            //            dataStartCntr++;
            //        }
            //        else break;
            //        if (dataStartCntr == introducedPattern.Length) break;
            //    }
            //    int.TryParse(patternNumerical, out dataNumericalInText);
            //    dataNumerical = dataNumericalInText;
            //}
            return dataNumerical;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected bool ExtractBooleanData(string introducedPattern, ref int dataStartCntr)
        {
            String patternBoolean = "";
            do
            {
                patternBoolean += introducedPattern[dataStartCntr];
                dataStartCntr++;
            } while ((byte)GetPatternObjectType(introducedPattern[dataStartCntr]) < 10);
            patternBoolean = patternBoolean.ToUpper();
            if ((patternBoolean[0] == 'T') || (patternBoolean[0] == 'Y') || (patternBoolean[0] == 'P') || (patternBoolean[0] == '1')) return true;
            else return false;  // ((patternBoolean[0] == 'F') || (patternBoolean[0] == 'N') || (patternBoolean[0] == '0') || (patternBoolean[0] == '-'))
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected string ExtractSymbolicData(string introducedPattern, ref int dataStartCntr)
        {
            String patternSymbolic = "";
            string regExpression = @"^[A-Za-z#][-0-9A-Za-z_%$#@']*$";
            //patternSymbolic += introducedPattern[dataStartCntr];
            //dataStartCntr++;
            while ((Regex.Match(patternSymbolic + introducedPattern[dataStartCntr], regExpression)).Success)   //, RegexOptions.IgnoreCase
            {
                patternSymbolic += introducedPattern[dataStartCntr];
                dataStartCntr++;
                if (dataStartCntr == introducedPattern.Length) break;
            }
            patternSymbolic = patternSymbolic.ToUpper();  //! Temporary it is changed to Upper in order to enable the same treatment of words nevertheless the capital or small letter e.g. "My" and "my"
            return patternSymbolic;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected AttributeType SpecifyAttributeType(string nameAttributeType)
        {
            switch (nameAttributeType)
            {
                case "N": return AttributeType.Numerical;
                case "S": return AttributeType.Symbolic;
                case "B": return AttributeType.Boolean;
                case "2D": return AttributeType.Structured2D;
                case "3D": return AttributeType.Structured3D;
                default: return AttributeType.Undefined;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected string ExtractAttributeName(string introducedPattern, ref int dataStartCntr, out AttributeType attributeType)
        {
            String nameAttribute = "";
            String nameAttributeType = "";
            attributeType = AttributeType.Undefined;
            if (introducedPattern[dataStartCntr] == '{')
            {
                dataStartCntr++;
                while ((introducedPattern[dataStartCntr] != ':') && (introducedPattern[dataStartCntr] != '}') && (introducedPattern[dataStartCntr] != '\n'))
                {
                    nameAttribute += introducedPattern[dataStartCntr];
                    dataStartCntr++;
                }
                if (introducedPattern[dataStartCntr] == ':')    // After colon the attribute type should be defined: N - numerical, S - symbolic, B - boolean, ..., e.g. {P1:N}, {P2:S}, {P3:B} etc.
                {
                    dataStartCntr++;
                    do
                    {
                        nameAttributeType += introducedPattern[dataStartCntr];
                        dataStartCntr++;
                    } while ((introducedPattern[dataStartCntr] != '}') && (introducedPattern[dataStartCntr] != '\n'));
                    attributeType = SpecifyAttributeType(nameAttributeType);
                }
                dataStartCntr++;
            }
            return nameAttribute;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected UInt32 ExtractStimulationDuration(string introducedPattern, ref int dataStartCntr)
        {
            UInt32 durationStimulation = 0;
            if (introducedPattern[dataStartCntr] == '<')
            {
                String patternNumerical = "";
                dataStartCntr++;
                while ((introducedPattern[dataStartCntr] != '>') && (introducedPattern[dataStartCntr] != '\n'))
                {
                    patternNumerical += introducedPattern[dataStartCntr];
                    dataStartCntr++;
                }
                UInt32.TryParse(patternNumerical, out durationStimulation);
            }
            return durationStimulation;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected UInt32 ExtractDelayInterval(string introducedPattern, ref int dataStartCntr)
        {
            UInt32 intervalDelay = 0;
            if (introducedPattern[dataStartCntr] == '[')
            {
                String patternNumerical = "";
                dataStartCntr++;
                while ((introducedPattern[dataStartCntr] != ']') && (introducedPattern[dataStartCntr] != '\n'))
                {
                    patternNumerical += introducedPattern[dataStartCntr];
                    dataStartCntr++;
                }
                dataStartCntr++;
                UInt32.TryParse(patternNumerical, out intervalDelay);
            }
            return intervalDelay;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected enum PatternObjectType : byte
        {
            Error = 0,              // undefined symbol
            // Object elements
            Number = 1,             // 0-9
            Symbol = 2,             // A-Z or a-z
            // Brackets
            Attribute = 10,          // {
            Duration = 11,           // <
            Delay = 12,              // [
            Parallel = 13,           // (
            // Object separators
            NextRow = 20,           // |
            Space = 21,             // [space]
            Tab = 22,               // [tab]
            Coma = 23,              // ,
            Semicolon = 24,         // ;
            Colon = 25,             // :
            // Pattern separators
            NewLine = 30,           // [new line]
            FullStop = 31,          // .
            QuestionMark = 32,      // ?
            ExclamationMark = 33,   // !
            // Other special symbols
            Apostrophe = 40,
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected PatternObjectType GetPatternObjectType(char startChar)
        {
            if (((int)startChar >= 48) && ((int)startChar <= 57)) return PatternObjectType.Number;  // 0-9
            if ((((int)startChar >= 64) && ((int)startChar <= 90)) || (((int)startChar >= 97) && ((int)startChar <= 122)) || ((int)startChar == 35)) return PatternObjectType.Symbol; // A-Z OR a-z OR #    //  || ((int)startChar == 39)
            switch (startChar)
            {
                case '{': return PatternObjectType.Attribute;
                case '<': return PatternObjectType.Duration;
                case '[': return PatternObjectType.Delay;
                case '(': return PatternObjectType.Parallel;
                case '|': return PatternObjectType.NextRow;
                case ' ': return PatternObjectType.Space;
                case '\t': return PatternObjectType.Tab;
                case ',': return PatternObjectType.Coma;
                case ';': return PatternObjectType.Semicolon;
                case ':': return PatternObjectType.Colon;
                case '.': return PatternObjectType.FullStop;
                case '?': return PatternObjectType.QuestionMark;
                case '!': return PatternObjectType.ExclamationMark;
                case '\n': return PatternObjectType.NewLine;
                case '\'': return PatternObjectType.Apostrophe;
                default: return PatternObjectType.Error;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected SensInput AttributeSensInput(string objectAttribute)
        {
            SensInput attributeSensInput;
            if (sensInputs.TryGetValue(objectAttribute, out attributeSensInput))
                return attributeSensInput;
            else
            {
                if (objectAttribute == "Undefined")
                {
                    attributeSensInput = new SymbolicSensInput(this);
                    sensInputs.Add(objectAttribute, attributeSensInput);
                    return attributeSensInput;
                }
                return null;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void IdentifyAndHandleNextObject(string introducedPattern, ref UInt64 expositionSimTime, ref int dataStartCntr, ref string objectAttribute)
        {
            PatternObjectType typeObject = GetPatternObjectType(introducedPattern[dataStartCntr]);
            switch (typeObject)
            {
                case PatternObjectType.Number: (AttributeSensInput(objectAttribute)).AddObject(ExtractNumericalData(introducedPattern, ref dataStartCntr), expositionSimTime); break;
                case PatternObjectType.Symbol: (AttributeSensInput(objectAttribute)).AddObject(ExtractSymbolicData(introducedPattern, ref dataStartCntr), expositionSimTime); break;
                case PatternObjectType.Apostrophe:
                    {
                        if (dataStartCntr > 0)
                        {
                            if (((GetPatternObjectType(introducedPattern[dataStartCntr - 1]) == PatternObjectType.Symbol) && (GetPatternObjectType(introducedPattern[dataStartCntr + 1]) == PatternObjectType.Symbol)) ||
                                ((introducedPattern[dataStartCntr - 1] == 's') && (introducedPattern[dataStartCntr + 1] == ' ')))
                            {
                                (AttributeSensInput(objectAttribute)).AddObject(ExtractSymbolicData(introducedPattern, ref dataStartCntr), expositionSimTime);
                            }
                            else
                            {
                                expositionSimTime += 150000; dataStartCntr++;
                            }
                        }
                        else
                        {
                            expositionSimTime += 150000; dataStartCntr++;
                        }
                    }
                    break;
                case PatternObjectType.Attribute:
                    {
                        objectAttribute = ExtractAttributeName(introducedPattern, ref dataStartCntr, out attributeType);
                        // Check if this attribute is already represented by any SensInput. If it is not, create a new SensInput for it and add to the list of SensInputs
                        if (!(sensInputs.ContainsKey(objectAttribute)))
                        {
                            if (attributeType == AttributeType.Numerical) sensInputs.Add(objectAttribute, new NumericalSensInput(this, objectAttribute));
                            else if (attributeType == AttributeType.Boolean) sensInputs.Add(objectAttribute, new BooleanSensInput(this, objectAttribute));
                            else /*attributeType == AttributeType.Symbolic or Undefined*/
                                sensInputs.Add(objectAttribute, new SymbolicSensInput(this, objectAttribute)); // Undefined attributes are treated as Symbolic (without an order)!
                        }
                    }
                    break;
                case PatternObjectType.Duration: (AttributeSensInput(objectAttribute)).AddDuration(ExtractStimulationDuration(introducedPattern, ref dataStartCntr), expositionSimTime); break;   // This is evaluated only for single objects
                case PatternObjectType.Delay: expositionSimTime += ExtractDelayInterval(introducedPattern, ref dataStartCntr); break;
                case PatternObjectType.Space: { expositionSimTime += (ulong)DelayFollowingObjectSpace * 1000; dataStartCntr++; } break;   // Default interpretation: successive objects
                case PatternObjectType.Coma: { expositionSimTime += (ulong)DelayFollowingObjectSpace * 1000/*10*/; dataStartCntr++; } break;      // Default interpretation: almost parallel objects (in sentence not always if before subordinate clauses)
                case PatternObjectType.Tab: { expositionSimTime += 0; dataStartCntr++; } break;       // Default interpretation: parallel objects, dividing next attribute values
                case PatternObjectType.Semicolon: { expositionSimTime += (ulong)DelayFollowingObjectSpace * 1000/*0*/; dataStartCntr++; } break;  // Default interpretation: parallel objects, dividing next attribute values
                case PatternObjectType.FullStop: { expositionSimTime += 10000; dataStartCntr++; } break;           // 150000 Default interpretation: next sentence
                case PatternObjectType.QuestionMark: { expositionSimTime += 10000; dataStartCntr++; } break;       // 150000 Default interpretation: next sentence
                case PatternObjectType.ExclamationMark: { expositionSimTime += 10000; dataStartCntr++; } break;    // 150000 Default interpretation: next sentence
                case PatternObjectType.NextRow: { expositionSimTime += 100000; dataStartCntr++; } break;            // 200000  it cuts off the context
                case PatternObjectType.Parallel: IdentifyAndHandleParallelObjects(introducedPattern, ref expositionSimTime, ref dataStartCntr, ref objectAttribute); break;  /*() inside other () can only/optionally group objects of the same Attribute*/
                default: { /*Any object separator.*/ dataStartCntr++; } break;
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void IdentifyAndHandleParallelObjects(String introducedPattern, ref UInt64 expositionSimTime, ref int dataStartCntr, ref String objectAttribute)
        {
            if (introducedPattern[dataStartCntr] == '(')
            {
                dataStartCntr++;
                while ((introducedPattern[dataStartCntr] != ')') && (introducedPattern[dataStartCntr] != '\n'))
                {
                    IdentifyAndHandleNextObject(introducedPattern, ref expositionSimTime, ref dataStartCntr, ref objectAttribute);  //+ () inside () is not implemented!
                    //dataStartCntr++;
                }
                dataStartCntr++;
                if (GetPatternObjectType(introducedPattern[dataStartCntr]) == PatternObjectType.Duration)
                {
                    // Update all objects with startTime == expositionSimTime that were included in brackets of parallel objects
                    foreach (SensInput sensInput in sensInputs.Values)
                    {
                        sensInput.AddDuration(ExtractStimulationDuration(introducedPattern, ref dataStartCntr), expositionSimTime);
                    }
                }
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected int ParseIntroducedPattern(String introducedPattern)
        {
            // This method is responsible for splitting introduced pattern into subpatterns for each sensory input and send it them for further processing from their points of view
            // A<time msec> OR (A B C)<time msec> - each training object can be exposed for a given duration (of time). If this duration is not given AAS stimulates the neuron representing this objects until it will fire/be activated and can be represented by sensors with permeability equal the threshold value of the connected neuron
            // (A B C) - parallel exposition of objects, inside this kind of brackets [time intervals] are not allowed and if occur they are ignored, if , or ; occur they are treated as separators of objects without time interval of their exposition. Objects in brackets have to be always send to different sensors, however input field can be sometimes the same
            // (A B C) or {P1}(A B C) - if no attributes are defined inside brackets or only a single one before the opening bracket it means that all these objects should affect the same sensory input but different sensors in it (Sensory Input Fields can have a structure like a retina)
            // ({P1}A {P2}B {P3}C) - if attributes are defined inside brackets it means that these objects should affect different sensory inputs as defined
            // ({P1}(A B C) {P2}(D E F)) - parallel objects for various attributes can be grouped using brackets as shown
            // (A B C | D E F | G H I) - there can be used a row separator | for representing matrices of elements (e.g. images), which elements are always exposed to the system at the same moment. If there is a correlated sequence of images it has to be expresses by the sequence of such matrices
            // {P1:N} OR {P1:S} OR {P1:B} - definition of Sensory Input Field that this object stimulates/influences, type of the input attribute has not to be defined if all objects represent a single attribute, where after colon is defined a type of attribute values: N - numerical, S - symbolic, B - boolean
            // [time msec] - time interval between exposition/presentation/introduction of the following objects, time interval is computed from the starting moment of exposition of an object, i.e. not from the stopping moment defined by <time msec>
            // .?!,; - natural separators automatically converted to time intervals if there is a space after them
            // 1.2 1,2 - if there is a number immediately after . or , it is interpreted as decimal separator in real numbers
            // 'A B C' or "A B C" - apostrophes or quotation marks are used to designate a sequence of objects that create an ensemble, block or entirety
            // tab or space - natural separator of objects in a sequence of table of objects
            // new line / Enter - separates independently presented patterns of whatever type with exception to matrix samples that finish each row with | except the last one
            // Correct sample: {P1}A<1.2> [0.5] ({P2}B<1.0> {P3}C<1.0> [2.0] {P1}D<2.0>.
            // This is a kind of parser and interpreter that has to split the sequence without processing it
            // Each pattern should start with identification of an attribute of the first object {P1}A or their group {P2}(A B C). If not it means that all objects define the same attribute or attributes are not explicitly given, e.g. for classic parralel objects in classification or regression tasks
            // During this process sensory inputs have to be created, so we have to identify all attributes
            // space is treated as a default separator in sequence of objects, so if the delay not defined space is converted to a predefined delay = 5 msec
            // semicolon (coma) is treated as a default separator in a set of parallel objects, so if not defined they are treated as parallel
            // If no attributes defined, all objects are treated as being the values of the same attribute with exception of objects separated by comas and semicolons, which are treated as values of separate attributes defined by columns
            UInt64 expositionSimTime = Events.SimTime;
            int lengthPattern = introducedPattern.Length;
            //anakgMainWindow.SensInput.Text = "";
            effOutput.Erase();
            int cntrObjects = 0;
            int cntr = 0;
            cntrObjects = 0;    // Must be inside the first loop
            String objectAttribute = "Undefined";
            while (cntr < lengthPattern)
            {
                IdentifyAndHandleNextObject(introducedPattern, ref expositionSimTime, ref cntr, ref objectAttribute);
                //-cntr++; IT IS MADE INSIDE THE ABOVE METHOD
                cntrObjects++;
            }
            return cntrObjects;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        //public bool LearnPattern(String sequencialPattern, Int32 mode = 0, UInt32 repetitions = 1) // mode = 0 means classic learning (1. phase) that makes a network plastic, mode = 1 means tune by threshold changes
        //{
        //    if (sequencialPattern.Length > 2)
        //    {

        //        //Logger.LogLine(String.Format("************************ NEXT SEQUENCE ************************"));
        //        //Logger.LogLine(String.Format("TRAIN SEQUENCE: {0}", sequencialPattern));

        //        // Start measuring learning time:
        //        DateTime beginSequenceLearningTime = DateTime.Now;
        //        Vertex.Phase = mode;

        //        // Change the behaviour of ANAKG to learning mode:
        //        plasticity = true;
        //        //if (mode >= 1)
        //        //{
        //        //    //Vertex.ModePlasticity = Vertex.PlasticityMode.tune;  // tune enables the changes of threshold and sensitivy of neurons leading to diversity and specialization of constructed networks
        //        //    anakgMainWindow.Phase.Content = "Tune " + tunePhaseCntr;
        //        //    //- Moved:...ShowThresholds();   //! To nie może być tutaj, bo musi przejść po wszystkich neuronach!
        //        //}
        //        //else
        //        //{
        //        //    //Vertex.ModePlasticity = Vertex.PlasticityMode.create;        // This is an initial and obligatory 1st learning and plasticity phase that constructs the structure of the newtork
        //        //    anakgMainWindow.Phase.Content = "Create " + createPhaseCntr;
        //        //    //- Moved:...ShowActivationNos();   //! To nie może być tutaj, bo musi przejść po wszystkich neuronach!
        //        //}

        //        int noSequenceObjects = 0;
        //        int maxTuningCycles = 9; // It should be equal the number or words in the sequence minus one. // noSequenceObjects;
        //        do
        //        {
        //            noIncorrectSeqActivations = 0;
        //            // Split pattern into sensory input channels and create lists of objects for each sensory input
        //            noSequenceObjects = ParseIntroducedPattern(sequencialPattern, repetitions); //! The number is computed incorrectly - 12 for 5 objects?! Why?

        //            // Change these lists of objects to events that could be parallel, sequencial or both
        //            foreach (SensInput sensInput in sensInputs.Values)
        //            {
        //                sensInput.AddEventsForObjects();
        //            }
        //            if (animate)
        //            {
        //                anakgMainWindow.SensInput.Text = "";
        //                // Clean EffOutput
        //                effOutput.Erase();  // jedno z tych tutaj niepotrzebne: tu i niżej
        //            }
        //            // Start Simulation for this sequence of words added to EventList
        //            events.StartSimulation();
        //            // Decrease the counter of the tuning cycles that can be proceeded for this sequence
        //            maxTuningCycles--;
        //            //Logger.LogLine(String.Format("noIncorrectSeqActivations: {0}", noIncorrectSeqActivations));
        //        } while ((noIncorrectSeqActivations > 0) && (maxTuningCycles > 0) && (mode >= 1));  // Repeat the tuning for the given sequence until overstimulation cases happen but not longer than the number of the objects in the sequence because in this case the solution does not exist
        //        noLearnedObjects += noSequenceObjects;
        //        noLearnedSequences++;

        //        if (animate)
        //        {
        //            view.NormalizeViewBorders();
        //            if (mode == 0)
        //            {
        //                // Automatically change size of elements if they cannot fit the view:
        //                anakgMainWindow.RecomputeElementViewSize();
        //                view.BalanceGraph();
        //                //BalanceGraph();
        //            }
        //        }

        //        // Stop measuring learning time:
        //        DateTime endSequenceLearningTime = DateTime.Now;
        //        ticksLearningTime += (long)(endSequenceLearningTime.Ticks - beginSequenceLearningTime.Ticks);
        //        elapsedSequenceLearningTime = new TimeSpan(ticksLearningTime);

        //        // Gather and view statistics: No of Neurons, No of Synapses, No of Threshold Changes, No of Weights Changes, Time from start, SimTime, Words trained
        //        if (animate) view.ShowAdaptationStatistics();
        //        //SaveAdaptationStatistics();

        //        // Update simulation time adding long enough interval in order not to associate the previous sequence with the last one - all neurons should have time to return back to their resting states
        //        //Events.AddSimulatioTime((UInt32)(delayFollowingSequence * 1000)); Specific delay is added during sequence parsing accordingly to the sign that ends up the pattern

        //        // Clean SensInput and EffOutput
        //        foreach (SensInput sensInput in sensInputs.Values)
        //        {
        //            sensInput.EraseInputData();
        //        }
        //        if (animate) anakgMainWindow.SensInput.Text = "";
        //        effOutput.Erase();  // jedno z tych tutaj niepotrzebne: tu i wyżej

        //        // Successful
        //        return true;
        //    }
        //    else return false;
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        public bool LearnPattern(String sequencialPattern) // mode = 0 means classic learning (1. phase) that makes a network plastic, mode = 1 means tune by threshold changes
        {
            if (sequencialPattern.Length > 2)
            {

                //Logger.LogLine(String.Format("************************ NEXT SEQUENCE ************************"));
                //Logger.LogLine(String.Format("TRAIN SEQUENCE: {0}", sequencialPattern));

                // Start measuring learning time:
                DateTime beginSequenceLearningTime = DateTime.Now;
                //Vertex.Phase = mode;    // Determinates which creation (0) or tuning (1 - AvoidUndesiredActivations, 2 - AvoidTooEarlyActivations, 3 or more - TuneConflicts) is processed

                // Change the behaviour of ANAKG to learning mode:
                plasticity = true;
                int noSequenceObjects = 0;
                int maxTuningCyclesPerSequence = 20; // It should be equal the number or words in the sequence minus one. // noSequenceObjects;
                do
                {
                    Neuron.NullNoUndesiredActivations();
                    Neuron.NullNoIncompleteContextActivations();
                    //noIncorrectSeqActivations = 0;
                    // Split pattern into sensory input channels and create lists of objects for each sensory input
                    noSequenceObjects = ParseIntroducedPattern(sequencialPattern); //! The number is computed incorrectly - 12 for 5 objects?! Why?

                    // Change these lists of objects to events that could be parallel, sequencial or both
                    foreach (SensInput sensInput in sensInputs.Values)
                    {
                        sensInput.AddEventsForObjects();
                    }
                   
                    // Start Simulation for this sequence of words added to EventList
                    events.StartSimulation();
                    // Decrease the counter of the tuning cycles that can be proceeded for this sequence
                    maxTuningCyclesPerSequence--;
                    //Logger.LogLine(String.Format("noIncorrectSeqActivations: {0}", noIncorrectSeqActivations));
                } while (((Neuron.NoUndesiredActivations > 0) || (Neuron.NoIncompleteContextActivations > 0)) && (maxTuningCyclesPerSequence > 0) && (Vertex.IsTuning));  // Repeat the tuning for the given sequence until overstimulation cases happen but not longer than the number of the objects in the sequence because in this case the solution does not exist
                //} while ((noIncorrectSeqActivations > 0) && (maxTuningCycles > 0) && (mode >= 1)) ;  // Repeat the tuning for the given sequence until overstimulation cases happen but not longer than the number of the objects in the sequence because in this case the solution does not exist
                noLearnedObjects += noSequenceObjects;
                noLearnedSequences++;

             

                // Stop measuring learning time:
                DateTime endSequenceLearningTime = DateTime.Now;
                ticksLearningTime += (long)(endSequenceLearningTime.Ticks - beginSequenceLearningTime.Ticks);
                elapsedSequenceLearningTime = new TimeSpan(ticksLearningTime);

                // Gather and view statistics: No of Neurons, No of Synapses, No of Threshold Changes, No of Weights Changes, Time from start, SimTime, Words trained
                
                //SaveAdaptationStatistics();

                // Update simulation time adding long enough interval in order not to associate the previous sequence with the last one - all neurons should have time to return back to their resting states
                //Events.AddSimulatioTime((UInt32)(delayFollowingSequence * 1000)); Specific delay is added during sequence parsing accordingly to the sign that ends up the pattern

                // Clean SensInput and EffOutput
                foreach (SensInput sensInput in sensInputs.Values)
                {
                    sensInput.EraseInputData();
                }
               
                effOutput.Erase();  // jedno z tych tutaj niepotrzebne: tu i wyżej

                // Successful
                return true;
            }
            else return false;
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        protected void SaveAdaptationStatistics()
        {
            //Logger.LogLine(String.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}", noLearnedSequences, noLearnedObjects, Neuron.Counter, Synapse.Counter, Neuron.NoCycleThresholdChanges, Synapse.NoCycleWeightChanges, events.SimTime, elapsedSequenceLearningTime.TotalSeconds));  // DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        public void AskPattern(String sequencialPattern)
        {
            if (sequencialPattern.Length > 0)
            {
                // LOGGER OUTPUT:
                // Logger.LogLine(String.Format("********************************** NEXT RECALLING STIMULATION **********************************"));
                // Logger.LogLine(String.Format("BRING ASSOCIATED MEMORIES BACK FOR: {0}, repeated {1} times.", sequencialPattern, repetitions));

                // Change the behaviour of ANAKG to asking mode that does not change the structure and parameters of the ANAKG
                plasticity = false;
                Vertex.Phase = AdaptationPhase.AskNetwork;
                //anakgMainWindow.Phase.Content = "Asking ";
                Synapse.NullCycleWeightChanges();
                //Neuron.NullCycleThresholdChanges();

                // Split pattern into sensory input channels and create lists of objects for each sensory input
                ParseIntroducedPattern(sequencialPattern);

                // Change these lists of objects to events that could be parallel, sequencial or both
                foreach (SensInput sensInput in sensInputs.Values)
                {
                    sensInput.AddEventsForObjects();
                }

                // Clean EffOutput
                
                // Start Simulation for this sequence of words added to EventList
                events.StartSimulation();
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------
        //public bool LearnSequence(String sequence, byte mode = 0, byte repetitions = 1) // mode = 0 means classic learning (1. phase) that makes a network plastic, mode = 1 means tune by threshold changes
        //{
        //    if (sequence.Length > 0)
        //    {
        //        delayFollowingObject = delayFollowingObjectLearn;
        //        //+ Rebuild in order to enable all kinds of sequence patterns and MASONN patterns in vector or matrix mode (if coma in (A B, C D) brackets means next line):
        //        //+ <A B C (D E) F[2] G[1] H[3] I J>  [exact time before presentation of the next object], if not define - standard time, if in () in the same moment.
        //        //+ Objects can be separated by space, coma, colon, semicolon. Sentences end after dot, exclamation mark, asking mark, >
        //        //+ CONTINUE...

        //        // This method represents the connection between input console (keyboard, file etc.) and sensInput field
        //        String[] words = UpperSplitSequence(ref sequence);

        //        // LOGGER OUTPUT:
        //        // Logger.LogLine(String.Format("********************************** NEXT LEARNING SEQUENCE **********************************"));
        //        // Logger.LogLine(String.Format("LEARN SEQUENCE: {0}", sequence));

        //        // Change the behaviour of ANAKG to learning mode:
        //        plasticity = true;
        //        if (mode == 1) Vertex.ModePlasticity = Vertex.PlasticityMode.tune;  // tune enables the changes of threshold and sensitivy of neurons leading to diversity and specialization of constructed networks
        //        else Vertex.ModePlasticity = Vertex.PlasticityMode.create;        // This is an initial and obligatory 1st learning and plasticity phase that constructs the structure of the newtork

        //        // Send this sequence of words into Sensory Input to learn that changes the structure and parameters of the ANAKG
        //        sensInput.IntroduceSequence(words, plasticity, repetitions);
        //        //foreach (SensInput sensInput in sensInputs.Values)
        //        //{
        //        //    sensInput.XXX();
        //        //}

        //        // Rebalance Graph after addition of ne elements
        //        // BalanceGraph(); only neurons have been added, so we cannot balance graph now. We have to wait for adding synapses and doing this balance during simulation on-line!
        //        // Even neurons have not to be added to the view before their simulation time will not go and stimulate them for the first time!

        //        // Clean EffOutput
        //        effOutput.Erase();

        //        // Start Simulation for this sequence of words added to EventList
        //        events.StartSimulation();

        //        // Automatically change size of elements if they cannot fit the view:
        //        anakgMainWindow.RecomputeElementViewSize();
        //        BalanceGraph();

        //        // Update simulation time adding long enough interval in order not to associate the previous sequence with the last one - all neurons should have time to return back to their resting states
        //        Events.AddSimulatioTime((UInt32)(delayFollowingSequence * 1000));

        //        // Clean SensInput and EffOutput
        //        foreach (SensInput sensInput in sensInputs.Values)
        //        {
        //            sensInput.Erase();
        //        }
        //        effOutput.Erase();

        //        // Successful
        //        return true;
        //    }
        //    else return false;
        //}
        //public void AskSequence(String sequence, byte repetitions = 1)
        //{
        //    delayFollowingObject = delayFollowingObjectAsk;
        //    //+ Rebuild in order to enable all kinds of sequence patterns and MASONN patterns in vector or matrix mode (if coma in (A B, C D) brackets means next line):
        //    //+ <A B C (D E) F[2] G[1] H[3] I J>  [exact time before presentation of the next object], if not define - standard time, if in () in the same moment.
        //    //+ Objects can be separated by space, coma, colon, semicolon. Sentences end after dot, exclamation mark, asking mark, >
        //    //+ CONTINUE...

        //    // This method represents the connection between input console (keyboard, file etc.) and sensInput field
        //    String[] words = UpperSplitSequence(ref sequence);
        //    // LOGGER OUTPUT:
        //    // Logger.LogLine(String.Format("********************************** NEXT RECALLING STIMULATION **********************************"));
        //    // Logger.LogLine(String.Format("BRING ASSOCIATED MEMORIES BACK FOR: {0}, repeated {1} times.", sequence, repetitions));

        //    // Change the behaviour of ANAKG to asking mode that does not change the structure and parameters of the ANAKG
        //    plasticity = false;
        //    Vertex.ModePlasticity = Vertex.PlasticityMode.off;  //ask?

        //    // Clean EffOutput
        //    effOutput.Erase();

        //    // Send this sequence of words into Sensory Input to learn
        //    sensInput.IntroduceSequence(words, plasticity, repetitions);
        //    //foreach (SensInput sensInput in sensInputs.Values)
        //    //{
        //    //    sensInput.XXX();
        //    //}

        //    // Start Simulation for this sequence of words added to EventList
        //    events.StartSimulation();
        //}
        //-----------------------------------------------------------------------------------------------------------------------------
        public void StartNeuralPlasticityWith(Neuron activatedNeuron)
        {
            for (Int32 neuronNo = 0; neuronNo < Neuron.Counter; neuronNo++)
            {
                Neuron sourceNeuron = neurons.ElementAt(neuronNo).Value;
                if (sourceNeuron != activatedNeuron)
                    // Nascent, Activated in the same time and Resting neurons are not connected, only Refracting, Charging, Relaxing/Recovering if its last activity were recent enough
                    if (/*(sourceNeuron.State != Neuron.InternalState.Resting) && */(sourceNeuron.State != Neuron.InternalState.Activation) && (sourceNeuron.State != Neuron.InternalState.AbsRefraction) && (sourceNeuron.State != Neuron.InternalState.Nascent))
                    {
                        // The graphNeuron can charge and relax alternately but its last activation could be far away. Such neurons are not intended to connect
                        //if (Math.Abs((double)activatedNeuron.TimeActivation - sourceNeuron.TimeActivation) < sourceNeuron.PeriodPlasticityMax)   // Until neuron do not return to its resting state it can start its plasticity: graphNeuron.PeriodRelaxation
                        if (activatedNeuron.TimeActivation < sourceNeuron.TimeActivation + sourceNeuron.PeriodPlasticityMax)   // Until neuron do not return to its resting state it can start its plasticity: graphNeuron.PeriodRelaxation
                        {
                            if (activatedNeuron.TimeActivation > sourceNeuron.TimeActivation + sourceNeuron.PeriodPlasticityMin)   // At least PeriodPlasticityMin must elapse between activities of neurons to treat them as successive in any sequence.
                            {
                                if (sourceNeuron.TimeActivation > 0)
                                {
                                    if (sourceNeuron.TimeActivation > activatedNeuron.TimePreviousActivation)   // To avoid using the sourceNeuron more than once to create context connections when the activatedNeuron is more than one activated (the sequence element is repeated)
                                    {
                                        // START PLASTICITY WITH RECENTLY ACTIVATED NEURONS:
                                        // Check timeActivation of all neurons and
                                        // if connected: change permeability
                                        // if not connected: create connection and compute permeability
                                        //isNewVertex = 
                                        sourceNeuron.SynapsePlasticity(activatedNeuron, events.SimTime);     // Update Synaptic Permeability and if necessary create connection
                                    }
                                }
                            }
                        }
                    }
            }
        }
        //-----------------------------------------------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------------------------------------------

        //-----------------------------------------------------------------------------------------------------------------------------
        
        #endregion METHODS
    }
    //***********************************************************************************************************************************************
}
