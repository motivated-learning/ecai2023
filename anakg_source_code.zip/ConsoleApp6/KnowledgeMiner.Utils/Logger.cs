﻿#define LOGGING_ENABLED

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace KnowledgeMiner.Utils
{
    public enum LoggerVerbosityLevel
    {
        Zero,
        One,
        Two
    }

    public class Logger
    {
        private static bool logConsole;

        public static bool LogConsole
        {
            get { return Logger.logConsole; }
            set { Logger.logConsole = value; }
        }
        
        private static bool logBuilder;

        public static bool LogBuilder
        {
            get { return Logger.logBuilder; }
            set { Logger.logBuilder = value; }
        }
        private StringBuilder sb;
        private LoggerVerbosityLevel verbosityLevel = LoggerVerbosityLevel.Zero;

        private static Logger instance;

        private Logger()
        {
            this.sb = new StringBuilder();
        }

        static Logger()
        {
            instance = new Logger();
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void LogLine(string message, LoggerVerbosityLevel level)
        {
            if(logBuilder)
                if (level >= Logger.instance.verbosityLevel)
                    Logger.instance.sb.AppendLine(message);

            if(logConsole)
                Console.WriteLine(message);
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void LogLine(string message)
        {
            LogLine(message, LoggerVerbosityLevel.One);
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void Log(string message, LoggerVerbosityLevel level)
        {
            if(logBuilder)
                if (level >= Logger.instance.verbosityLevel)
                    Logger.instance.sb.Append(String.Format("{0}",message));
            
            if(logConsole)
                Console.Write(String.Format("{0}\t",message));
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void Log(string message)
        {
            Log(message, LoggerVerbosityLevel.One);
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void LogLineTimes(string p)
        {
            for (int i = 0; i < 50; i++)
                Log(p);

            LogLine("");
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void Reset()
        {
            instance.sb = new StringBuilder();
        }

        public static string GetLoggedText()
        {
            if (logBuilder == true)
            {
                return instance.sb.ToString();
            }
            throw new ApplicationException("Cannot get logged text if LogBuilder is false");
        }

        /*[Conditional("LOGGING_ENABLED")] */
        public static void Save(string filePath)
        {
            using (StreamWriter outfile = new StreamWriter(filePath))
            {
                outfile.Write(GetLoggedText());
            }

        }
    }
}
