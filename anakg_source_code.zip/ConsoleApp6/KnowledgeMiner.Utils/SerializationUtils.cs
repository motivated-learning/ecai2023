﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace KnowledgeMiner.Utils
{
    class SerializationUtils
    {
        public static T Deserialize<T>(Stream stream)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            T deserializedObject = (T)serializer.Deserialize(stream);
            stream.Close();

            return deserializedObject;
        }

        public static Stream Serialize<T>(T serializableObject)
        {
            Stream stream = new MemoryStream();
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            serializer.Serialize(stream, serializableObject);
            stream.Close();

            return stream;
        }
    }
}
