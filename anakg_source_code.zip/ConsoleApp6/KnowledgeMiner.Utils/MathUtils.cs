﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MathNet.Numerics.LinearAlgebra;
using System.Globalization;

namespace KnowledgeMiner.Utils
{
    public static class MathUtils
    {
        public static double CalculateDistancePow2(double[] v1, double[] v2)
        {
            if (v1.Length != v2.Length)
                throw new ArgumentException("Vectors have to be the same size.");

            double distance = 0.0;
            for (int i = 0; i < v1.Length; i++)
                distance += v1[i] * v1[i] - 2 * v1[i] * v2[i] + v2[i] * v2[i];

            return distance;
        }

        public static double CalculateDistance(double[] v1, double[] v2)
        {
            return Math.Sqrt(MathUtils.CalculateDistancePow2(v1, v2));
        }

        public static string ToShortDouble(double value)
        {
            return string.Format("{0:0.####}", value);
        }

        public static double[][] InvertMatrix(double[][] matrix)
        {
            return new Matrix(matrix).Inverse().CopyToJaggedArray();
        }

        public static double[] SolveMatrix(double[][] A, double[] b)
        {
            Matrix m = new Matrix(A);
            
            Matrix x = m.Solve(new Vector(b).ToColumnMatrix());
            x.Transpose();
            double[][] retX = x.CopyToJaggedArray();

            return retX[0];
        }

        /// <summary>
        /// Claculates cov matrix.
        /// Given matrix has tu be mean adjusted.
        /// </summary>
        /// <param name="matrix"></param>
        /// <returns></returns>
        public static double[][] CovarianceMatrix(double[][] matrix)
        {

            double[][] covMatrix = new double[matrix[0].Length][];
            for (int i = 0; i < matrix[0].Length; i++)
                covMatrix[i] = new double[matrix[0].Length];

            for (int i = 0; i < matrix[0].Length; i++)
            {
                for (int j = 0; j < matrix[0].Length; j++)
                {
                    for (int k = 0; k < matrix.Length; k++)
                        covMatrix[i][j] += matrix[k][i] * matrix[k][j];

                    covMatrix[i][j] /= (matrix.Length-1);
                }
            }


            return covMatrix;
        }

        public static double[] EigenValues(double[][] matrix)
        {
            ComplexVector cv = new Matrix(matrix).EigenValues;
            double[] eigenValues = new double[cv.Length];

            for (int i = 0; i < cv.Length; i++)
                eigenValues[i] = cv[i].Real;

            return eigenValues;
        }

        public static double[][] EigenVectors(double[][] matrix)
        {
            return new Matrix(matrix).EigenVectors.CopyToJaggedArray();
        }

        public static double[][] MatrixMultiply(double[][] m1, double[][] m2)
        {
            Matrix matrix1 = new Matrix(m1);
            Matrix matrix2 = new Matrix(m2);

            matrix2.Transpose();

            Matrix matrixMultiplied = matrix1.Multiply(matrix2);

            return matrixMultiplied.CopyToJaggedArray();
        }

        //public static double[][] MatrixMultiplyWithTranspose(double[][] m1, double[][] m2)
        //{
        //    Matrix matrix1 = new Matrix(m1);
        //    matrix1.Transpose();

        //    Matrix matrixMultiplied = matrix1.Multiply(new Matrix(m2));

        //    return matrixMultiplied.CopyToJaggedArray();
        //}

        public static double[][] DeepCloneArray(double[][] array)
        {
            double[][] clone = new double[array.Length][];
            for (int i = 0; i < array.Length; i++)
                clone[i] = new double[array[0].Length];

            for (int i = 0; i < array.Length; i++)
                for (int j = 0; j < array[0].Length; j++)
                    clone[i][j] = array[i][j];

            return clone;
        }

        public static double[][] MarixTranspose(double[][] matrix)
        {
            Matrix m = new Matrix(matrix);
            m.Transpose();
            return m.CopyToJaggedArray();
        }

        public static double[] ConvertToDoubleArray(object[] testData)  // Ta metoda jest zastępowana przez automatyczną inteligentną konwersję różnych typów ConvertOriginalDataToRealData & FinalizeConversion w TrainingData
        {
            List<double> list = new List<double>();
            foreach (object o in testData)
            {
                //if ((string)o != "")
                if (Convert.ToString(o) != "")
                {
                    //string oStr = ((string)(o)).Replace(',', '.');
                    string oStr = (Convert.ToString(o)).Replace(',', '.');
                    //                list.Add(Convert.ToDouble(oStr));
                    list.Add(Double.Parse(oStr, CultureInfo.InvariantCulture.NumberFormat));
                }
                else list.Add(Double.NaN);  // Jeśli nie podano wejścia, koduje to jako brak danej
            }
            return list.ToArray();
        }

        public static object[] ConvertToObjectArray(double[] testData)
        {
            List<object> list = new List<object>();
            foreach (double d in testData)
            {
                list.Add((object)d);
            }

            return list.ToArray();
        }
    }
}
