﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KnowledgeMiner.Utils
{
    public class CollectionUtils
    {
        public static KeyValuePair<List<double[]>, List<string> > MixTrainingLists(List<double[]> inputList, List<string> inputClasses)
        {
             List<double[]> randomDoubleList = new List<double[]>();
             List<string> randomStringList = new List<string>();
             KeyValuePair<List<double[]>, List<string> > lists = new KeyValuePair<List<double[]>,List<string>>(randomDoubleList, randomStringList);
             if (inputList.Count == 0)
                 return lists;

             Random r = new Random();
             int randomIndex = 0;
             while (inputList.Count > 0)
             {
                  randomIndex = r.Next(0, inputList.Count); //Choose a random object in the list
                  randomDoubleList.Add(inputList[randomIndex]); //add it to the new, random list<
                  randomStringList.Add(inputClasses[randomIndex]);
                  inputList.RemoveAt(randomIndex); //remove to avoid duplicates
                  inputClasses.RemoveAt(randomIndex);
             }

             return lists; //return the new random list
        }
    }
}
