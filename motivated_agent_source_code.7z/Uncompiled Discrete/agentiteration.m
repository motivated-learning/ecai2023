function [net,dtatrkret,dtatrk,hist,prims,paintrig,pauset]=agentiteration(net,params,const,hist,i,dtatrk,prims,paintrig, pauset,KnownProb)

net.pain(const.primpos)=prims(1:length(const.primpos))/const.tc2;

%        -------Estimate the internal probability----------

if KnownProb==1
    net.intprobest=dtatrk.currentprob;
else
    a=size(net.intprobtrack,2);
    if a>=params.lim(dtatrk.sennum)
        net.intprobtrack(:,1:a-1)=net.intprobtrack(:,2:a);
        net.intprobtrack(:,a)=net.sensor;
    else
        net.intprobtrack(:,a+1)=net.sensor;
    end
    net.intprobest=sum(net.intprobtrack,2)/size(net.intprobtrack,2);
    net.intprobest=0.02.*(net.intprobest==0)+net.intprobest; %Ensures there are no zeros in internal prob
end

if i~=1
    %-----------Evaluate net.pain--------
    %Learn depending on change in prob/net.pain from prev cycle (winning net.pain reduced)

    net.bias=-log2(net.intprobest);

    net.pain(1:params.ns)=(net.bias.*net.wbp)';     %+painval*wpp+;
    net.pain(const.cur)=const.paintp;               %Set play net.pain exactly to threshold to allow play to occur

    grter=false(params.trg,1);

    for k=(params.histsize-(min(params.histsize+1,i)-2)):params.histsize
        if hist.paintrig(k)==const.cur              %deal with curiosity - look at overall probability

            net.painred=-1*ones(1,params.trg);
            grter(1:params.ns)=(net.intprobest)>hist.probdata(:,k);     %dtatrk.prevprob;
            grter((params.ns+1):(params.trg))=net.pain((params.ns+1):(params.trg))'<hist.paindata((params.ns+1):(params.trg),k);
            net.painred(grter)=1;

            %   check if the dominant pain was reduced
        elseif net.pain(hist.paintrig(k))<hist.paindata(paintrig,k);%dtatrk.prevpaindata(paintrig);
            net.painred(hist.paintrig(k))=1;
        else net.painred(hist.paintrig(k))=0;
        end
        %         if hist.wingoals==8 && hist.paintrig==1 && net.painred(hist.paintrig)~=1
        %             pause(0.0001);
        %         end
        %------------___________---------Adjust Weights-----------____________________
        if pauset==0
            if hist.paintrig(k)~=const.cur %no point is adjusting net.wbp for play net.pain
                for j=1:params.ns   %adjust all sensory inputs
                    deltab=params.hadj(k)*const.deltabp*(const.alphab-net.wbp(j));
                    if hist.sennum(k)==j    %if sensory input j was used
                        if net.painred(hist.paintrig(k))    %if net.pain reduced by action taken
                            net.wbp(j)=net.wbp(j)+deltab;
                        else
                            %net.wbp(j)=net.wbp(j)*(1-params.hadj(k)*const.deltabp);
                            net.wbp(j)=net.wbp(j)*(1-params.hadj(k)*const.deltabn);
                        end
                    else    %If net.sensor was not associated
                        net.wbp(j)=net.wbp(j)*(1-params.hadj(k)*const.deltabn);
                    end
                end
            end

            if hist.paintrig(k)~=const.cur
                net.mug=params.hadj(k)*const.mugconst*((1-net.intprobest(hist.sennum(k)))+0.1*net.intprobest(hist.sennum(k)));
                net.nonwin=ones(size(dtatrk.goalval)); net.nonwin(hist.wingoals(k))=0;
                net.nonwin=find(net.nonwin==1);
                if net.painred(hist.paintrig(k))
                    sign=1;
                    %   increase weight wpg for the reduced dominating pain
                    %   in response to a selected action
                    net.deltaa=net.mug*min(abs(const.alphag-net.wpg(hist.paintrig(k),hist.wingoals(k))),...
                        net.wpg(hist.paintrig(k),hist.wingoals(k)));
                    net.wpg(hist.paintrig(k),hist.wingoals(k))=net.wpg(hist.paintrig(k),hist.wingoals(k))+net.deltaa;
                    deltaii=net.mug*net.wpg(hist.paintrig(k),net.nonwin);
                else
                    net.deltaa=net.mug*min(abs(const.alphag-net.wpg(hist.paintrig(k),hist.wingoals(k))),net.wpg(hist.paintrig(k),hist.wingoals(k)));
                    net.wpg(hist.paintrig(k),hist.wingoals(k))=net.wpg(hist.paintrig(k),hist.wingoals(k))-net.deltaa;
                    deltaii=net.mug*(const.alphag-net.wpg(hist.paintrig(k),net.nonwin));
                    sign=-1;
                end

                net.deltai=deltaii.*net.wpg(hist.paintrig(k),net.nonwin)./sum(net.wpg(hist.paintrig(k),net.nonwin));
                %net.deltai=net.deltaa.*net.wpg(hist.paintrig(k),net.nonwin)./sum(net.wpg(hist.paintrig(k),net.nonwin));
                net.wpg(hist.paintrig(k),net.nonwin)=net.wpg(hist.paintrig(k),net.nonwin)-sign*net.deltai;
            else
                %handle Curiosity  separatly
                %####Adjust weights for non-hist.paintrig(k) net.wpg links
                net.mug=params.hadj(k)*const.muqconst*((1-net.intprobest(hist.sennum(k)))+0.1*net.intprobest(hist.sennum(k)));
                %net.mug=1.00*((1-net.intprobest(hist.sennum(k)))+0.1*net.intprobest(hist.sennum(k)));
                net.deltaa=net.mug*min(abs(const.alphag-net.wpg(:,hist.wingoals(k))),net.wpg(:,hist.wingoals(k)));
                net.nonwin=ones(size(dtatrk.goalval)); net.nonwin(hist.wingoals(k))=0;
                net.nonwin=find(net.nonwin==1);
                net.deltaii=net.mug*(const.alphag-net.wpg(1:params.trg-1,net.nonwin));
                for l=1:params.trg-1
                    net.deltai(l,:)=net.deltaii(l,:).*net.wpg(l,net.nonwin)./sum(net.wpg(l,net.nonwin));
                end
                if hist.paintrig(k)==const.cur
                    net.wpg(1:params.trg-1,hist.wingoals(k))=net.wpg(1:params.trg-1,hist.wingoals(k))+net.painred(1:params.trg-1)'.*net.deltaa(1:params.trg-1);
                    %affect all other wpg goal for nonwin situation
                    %net.wpg(1:params.trg-1,net.nonwin)=net.wpg(1:params.trg-1,net.nonwin)-diag(net.painred(1:params.trg-1))*net.deltai(1:params.trg-1,:);
                    %########Disable change to curiosity weights################
                    net.wpg(hist.paintrig(k),hist.wingoals(k))=net.wpg(hist.paintrig(k),hist.wingoals(k))-net.deltaa(hist.paintrig(k));
                    %Change nonwinning with increase
                    %                         net.wpg(hist.paintrig(k),net.nonwin)=net.wpg(hist.paintrig(k),net.nonwin)+net.deltai;
                end
            end



        end
    end
end
%############--------Determine Current Goal & Motor/net.sensor%pair------------
%Determine the net.pain node that triggered the goal
%painval=(net.pain>=const.tp);
net.pain(1:params.ns)=(net.painnull.*net.bias.*net.wbp)';   %+painval*wpp+;
net.pain(const.cur)=const.paintp;       %Set play net.pain exactly to threshold to allow play to occur
paintrig=find(net.pain==max(net.pain));
paintrig=paintrig(length(paintrig));     %handles rare situations where the max pains are identical
painval=zeros(1,params.trg);
painval(paintrig)=net.pain(paintrig);
painval=(painval>=const.tp);
dtatrkret.paindata=[net.pain(1:params.ns) net.pain(params.ns+1:params.trg)];

net.UA=~net.sensor;
for j=1:params.nm-1, net.UA=[net.UA;~net.sensor]; end
%net.cert(const.cur,:)=min(min(net.wpg(1:params.trg-1,:),1-net.wpg(1:params.trg-1,:)));
for m=1:params.ng
    [Y I]=sort(net.wpg(1:params.trg-1,m),'descend');
    net.cert(const.cur,m)=min(1-net.wpg(I(1),m),1-net.wpg(I(2),m));
end
dtatrkret.certtrack=1-net.cert(const.cur,:);
dtatrk.goalval=(painval*(net.wpg.*net.cert))'+net.UA.*net.wuag;
dtatrk.winninggoal=min(find(dtatrk.goalval==max(dtatrk.goalval)));

%Take action & Perform environmental updates based on goal
%Implement dtatrk.motnum 6 - play that doesn't consume resources?
% if paintrig<7 %paintrig==4 || paintrig==5
%     pause(0.0001);
% end
dtatrk.motnum=floor((dtatrk.winninggoal-1)/params.ns)+1; %Determine associated sensory input
dtatrk.sennum=mod(dtatrk.winninggoal,params.ns);    %Determine associated motor output

if dtatrk.sennum==0, dtatrk.sennum=params.ns; end
if length(dtatrk.winninggoal)==1 && dtatrk.goalval(dtatrk.winninggoal)>=const.goalthresh %Proceed if winner-take-all functions correctly
    pauset=0;
    dtatrk.goalcount(paintrig,dtatrk.winninggoal)=dtatrk.goalcount(paintrig,dtatrk.winninggoal)+1;
    %dtatrkret.goalcount=[paintrig,1];
else
    %dtatrkret.goalcount=[paintrig,0];
    dtatrk.winninggoal=dtatrk.winninggoal(1);
    dtatrkret.goaltrack=[params.ng+1;0;1];
    pauset=1;
    %   increase primitive pain levels by 1
    prims=prims+1;
    dtatrk.actioncount(10)=dtatrk.actioncount(10)+1;
end

%Update hist array
if params.histsize>1
    hist.wingoals(1:params.histsize-1)=hist.wingoals(2:params.histsize);
    hist.paintrig(1:params.histsize-1)=hist.paintrig(2:params.histsize);
    hist.paindata(:,1:params.histsize-1)=hist.paindata(:,2:params.histsize);
    hist.probdata(:,1:params.histsize-1)=hist.probdata(:,2:params.histsize);
    hist.sennum(1:params.histsize-1)=hist.sennum(2:params.histsize);
    hist.motnum(1:params.histsize-1)=hist.motnum(2:params.histsize);
end
try
    hist.wingoals(params.histsize)=dtatrk.winninggoal;
    hist.paintrig(params.histsize)=paintrig;
    hist.paindata(:,params.histsize)=net.pain;
    hist.probdata(:,params.histsize)=net.intprobest;
    hist.sennum(params.histsize)=dtatrk.sennum;
    hist.motnum(params.histsize)=dtatrk.motnum;
catch
    disp('error');
    pause(0.1);
end