function [sensor prob]=environcheck(ns,rate,uses)
% cgeck the environment
prob=1./(1+(uses./rate));
sensor=rand(ns,1)<=prob;