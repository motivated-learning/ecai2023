s={'Lack of Food' ;'Empty Gorcery' ;'Lack of Money' ;'Lack of JobOpportunitites' ;'Learning Opportunities';'Lack of Toys';'Prim Hunger';'Curiousity'};
s2={'Food' ;'Gorcery' ;'Money' ;'JobOpportunitites' ;'Learning Opportunities';'Toys'};

count=0;
Curlearn=0; %To Enable or disable curiosity turning off/on the curiousity pain
KnownProb=1;

%Parameters
%   ns is the number of sensory inputs
%   nm is the number of motor outputs
%   nprim is the number of primitive pain signals (including curiosity)
params=struct('nbatch',1,'niter', 10000,'ns', 6,'nm', 6, 'ng', 0,'nprim', 2);
params.ng=params.ns*params.nm;
params.trg=params.ns+params.nprim;
params.histsize=1;
params.hadj=flipdim(1:-(1/params.histsize):(1/params.histsize),2);
params.batchwinave=1;
prims=zeros(1,params.nprim);

%Constants
const=struct('e',10^-9, 'deltabn', 0.0001, 'deltabp',0.02*4, ...
    'mugconst', 0.3, 'alphag', 1, 'alphap', 0.7, 'alphab', 0.5, 'tp', ...
    0.4, 'paintp', 0, 'tc', 10, 'rate', 0, 'goalthresh', 0.00051);
const.primpos=[7];      %is is an idex for the primiytive pain position?
const.tc2=const.tc*1;
const.cur=8;            %index for curiosity position?
%?threshold for pain
const.tp=0.2;
const.muqconst=0.2;
const.paintp=(const.tp+0.001)*Curlearn;
%const.rate=[const.tc const.tc/2 const.tc/5 const.tc/10 10000 100000]';
const.rate=[const.tc const.tc/2 const.tc/3 const.tc/4 10000 100000]';
%const.rate=[const.tc const.tc const.tc const.tc 10000 100000]';
const.evpainhandle=cell(1,params.ns+params.nprim-1);  %Create cell array specifying sensor-motor combinations that satify the pains
const.evpainhandle{1}=[2,2];
const.evpainhandle{2}=[3,3];
const.evpainhandle{3}=[4,4];
const.evpainhandle{4}=[5,5];
const.evpainhandle{5}=[];
const.evpainhandle{6}=[];
const.evpainhandle{7}=[1,1];
const.evpainhandle{8}=[];
const.set1=zeros(length(const.evpainhandle),1);
for i=1:length(const.evpainhandle)
    if ~isempty(const.evpainhandle{i})
        const.set1(i)=1;
    end
end
const.set2=num2cell(find(const.set1==0))';
const.set1=num2cell(find(const.set1==1))';

batchpain=zeros(params.niter,params.trg);
batchcumpain=batchpain;
batchbias=zeros(params.niter,params.ns);
batchprob=zeros(params.ns,params.niter);
batchgoal=zeros(params.trg,params.ng);
batchaction=zeros(1,10);
batchgoaltrack=[];
batchpainredtrack=zeros(params.niter,params.trg);
batchcerttrack=zeros(params.niter,params.ng);
batchwbptrack=zeros(params.niter,params.ns);

net=struct('wuag', -10*ones(params.ng,1));