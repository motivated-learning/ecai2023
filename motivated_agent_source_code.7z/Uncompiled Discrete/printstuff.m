% set the plot options
if printtype==1
    % figure(1);
    % %   title('Average net.pain levels')
    % for j=1:params.ns-1
    %     subplot(params.ns-1,1,j);
    %     plot(dtatrk.paindata(:,j));
    %     title(s{j});
    %     ylabel('net.pain');
    %   axis([0 i 0 max([0.1 max(dtatrk.paindata(:,j))])]);
    % end
    % xlabel('Discrete time');

    % figure(2);
    % %   title('Average Depletion of Resources')
    % for j=1:params.ns-2
    %     subplot(params.ns-2,1,j);
    %     plot(dtatrk.biasdata(:,j));
    %     title(s{j+1});
    %     ylabel('net.bias');
    %     axis([0 i 0 max([0.1 max(dtatrk.biasdata(:,j))])]);s
    % end
    % xlabel('Discrete time');

    figure(3);
%     for k=1:params.ns
%         probtrack(k,:)=smooth(probtrack(k,:),params.batchwinave);
%     end
    plot(probtrack(1:params.ns,1:i)');
    legend(s2,'Location','SouthEast')
    title('Averaged Probabilty data');
    ylabel('Probability');
    xlabel('Discrete time');
    legend(s2{1:params.ns},'Location', 'SouthEast')

        figure(4);
    title('Pain data');
%     for k=1:size(paindata,2)
%         paindata(:,k)=smooth(paindata(:,k),params.batchwinave);
%     end
    plot(paindata(1:i,:));
    ylabel('net.pain level');
    xlabel('Discrete time');
    legend(s,'Location', 'NorthEast')

    figure(5);
    %title('Frequency of net.pain Related actions')
    for j=1:params.trg
        subplot(params.trg,1,j);
        if j==1
            pt=params.ns+1;
        elseif j==const.cur
            pt=const.cur;
        else
            pt=j-1;
        end
        bar(1:params.ng,100*dtatrk.goalcount(pt,:)/sum(sum(dtatrk.goalcount)));
        title(s{j});
        %axis([0 i 0 max([0.1 max(biasdata(:,j))])]);
    end
    xlabel('Goal number');


    figure(6); bar(dtatrk.actioncount);
    title('Action Chart');
    ylabel('ACtion Count');
    xlabel('Action ID');

    figure(7); plot((goaltrack(1:i,1).*goaltrack(1:i,2)),'.g');
    hold on; plot((goaltrack(1:i,1).*~goaltrack(1:i,2)),'.r');
    plot((goaltrack(1:i,1).*goaltrack(1:i,3)),'.b'); hold off;
    title('Goal Scatter Plot');
    ylabel('Goal ID');
    xlabel('Discrete time');
    
    for k=1:size(certtrack,2)
        %certtrack(:,k)=smooth(certtrack(:,k),params.batchwinave);
        certtrack(:,k)=wiener2(certtrack(:,k),[1 params.batchwinave]);
    end
    figure(8);plot(certtrack(1:i,:));

    count=count+1;
    dtatrk.wbpstore(count,:)=net.wbp;
    %   axis([0 i 0 max(max(dtatrk.paindata(j,:)))]);
else
    batchcumpain=batchcumpain/params.nbatch;
    batchpain=batchpain/params.nbatch;
    batchbias=batchbias/params.nbatch;
    batchprob=batchprob/params.nbatch;
    batchgoal=batchgoal/params.nbatch;
    batchaction=batchaction/params.nbatch;
    batchpainredtrack=batchpainredtrack/params.nbatch;
    batchcerttrack=batchcerttrack/params.nbatch;
    batchwbptrack=batchwbptrack/params.nbatch;

    % figure(8);
    % %   title('Average net.pain levels')
    % for j=1:params.ns-1
    %     subplot(params.ns-1,1,j);
    %     plot(batchpain(:,j));
    %     title(s{j});
    %     ylabel('net.pain');
    % end
    % xlabel('Discrete time');

    % figure(9);
    % %   title('Average Depletion of Resources')
    % for j=1:params.ns-2
    %     subplot(params.ns-2,1,j);
    %     plot(batchbias(:,j));
    %     title(s{j+1});
    %     ylabel('net.bias');
    % end
    % xlabel('Discrete time');

    figure(10);
    for k=1:params.ns
        batchprob(k,:)=smooth(batchprob(k,:),params.batchwinave);
    end
    plot(batchprob(1:params.ns,:)');
    legend(s2,'Location','SouthEast')
    title('Averaged Probabilty data');
    ylabel('Probability');
    xlabel('Discrete time');
    legend(s2{1:params.ns},'Location', 'SouthEast')
    saveas(figure(10),'aveprob','jpg')

    figure(11);clf;
    title('Batchpain data');
    for k=1:size(batchpain,2)
        batchpain(:,k)=smooth(batchpain(:,k),params.batchwinave);
    end
    plot(batchpain);
    ylabel('net.pain level');
    xlabel('Discrete time');
    legend(s,'Location', 'NorthEast')
    saveas(figure(11),'batchpain','jpg')

    figure(12);
    %title('Average Frequency of net.pain Related actions')
    for j=1:params.trg
        subplot(params.trg,1,j);
        if j==1
            pt=params.ns+1;
        elseif j==const.cur
            pt=const.cur;
        else
            pt=j-1;
        end
        bar(1:params.ng,100*batchgoal(pt,:)/sum(sum(batchgoal)));
        title(s{pt});
        %axis([0 i 0 max([0.1 max(biasdata(:,j))])]);
    end
    xlabel('Goal number');
    saveas(figure(12),'goalbarchart','jpg')

    figure(13); bar(batchaction);
    %legend('Eat','GetFood','GetMoney','GetJob','Study','UselessPlay','OtherPlay','OutofSync','MiscAction');
    title('Average Action Chart');
    ylabel('ACtion Count');
    xlabel('Action ID');
    saveas(figure(13),'barchart','jpg')

    figure(14);plot((batchgoaltrack(:,1).*batchgoaltrack(:,2)),'.g');
    hold on; plot((batchgoaltrack(:,1).*~batchgoaltrack(:,2)),'.r');
    plot((batchgoaltrack(:,1).*batchgoaltrack(:,3)),'.b'); hold off;
    saveas(figure(14),'goalscatterplot','jpg')
    
    title('Goal Scatter Plot');
    ylabel('Goal ID');
    xlabel('Discrete time');

    figure(15);
    for k=1:size(batchcerttrack,2)
        batchcerttrack(:,k)=smooth(batchcerttrack(:,k),params.batchwinave);
        %batchcerttrack(:,k)=wiener2(batchcerttrack(:,k),[1 params.batchwinave]);
    end
    plot(batchcerttrack);
    title('Certainty tracking');
    saveas(figure(15),'certtrack','jpg')

    % figure(16);
    % plot((batchpain(:,[const.hunger 1:4])>=const.tp).*(batchpain(:,[const.hunger 1:4])-const.tp));
    % ylabel('net.pain level');
    % xlabel('Discrete time');
    % legend('Hunger','No Food','Empty Grocery','No Money','No Job','Location', 'NorthEast')


    %   title('Average net.pain levels')
    rangej=find(batchcumpain(params.niter,:)~=0);%[1:params.ns-2 params.trg-1];
    count=0;
    for j=rangej
        count=count+1;
        %     figure(17);
        %     subplot(size(rangej,2),1,count);
        %
        %     plot(a);
        %     title(s{j});
        %     ylabel('Pain');
        figure(18)

        c(:,j)=batchcumpain(:,j)./(1:size(batchcumpain(:,j),1))';
        subplot(size(rangej,2),1,count);
        %plot(batchcumpain(:,j))
        plot(c(:,j));
        title(s{j});
        ylabel('Average Pain');
    end
    xlabel('Discrete time');
    saveas(figure(18),'avepain','jpg')
    
    figure(20);
%     for k=1:size(batchwbptrack,2)
%         batchwbptrack(:,k)=smooth(batchwbptrack(:,k),params.batchwinave);
%     end
    plot(batchwbptrack);
    title('Wbp tracking');
    saveas(figure(20),'wbptrack','jpg')

    batchcumpain(params.niter,:)
    c(params.niter,:)
end