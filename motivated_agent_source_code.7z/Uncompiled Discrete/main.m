warning off all;
clc; clear all; close all;
tic
%hist=1;
%walleeparams;
origparams;
%farm1;

for brun=1:params.nbatch
    brun
    initialize;   
    
    %Get initial Sensor Data
    [net.sensor dtatrk.currentprob]=environcheck(params.ns,const.rate,dtatrk.uses);

    %#############Main ExecutionBlock############------------------------------
    for i=1:params.niter
        %Update Network
        
        
        [net,dtatrkret,dtatrk,hist,prims,paintrig, pauset]=agentiteration(net,params,const,hist,i,dtatrk,prims,paintrig, pauset,KnownProb);
        dtatrk.prevprob=net.intprobest;
        
        %Probe Environment
        [dtatrk.uses,prims,dtatrk.currentprob, net.sensor, dtatrk.actioncount,dtatrkret.goaltrack]=enviroupdate(const,...
            dtatrk.winninggoal,dtatrk.sennum, dtatrk.motnum, dtatrk.uses, paintrig,prims,...
            dtatrk.actioncount,params,params.trg,pauset);

        %Update Tracking Arrays
        if i~=1
            painredtrack(i,:)=painredtrack(i-1,:)+net.painred;
            biasdata(i,:)=net.bias;
        else
            painredtrack(i,:)=zeros(1,params.trg);
            biasdata(i,:)=zeros(1,params.ns);
        end
        probtrack(:,i)=net.intprobest;        
        paindata(i,:)=dtatrkret.paindata;
        dtatrk.prevpaindata=dtatrkret.paindata;
        goaltrack(i,:)=dtatrkret.goaltrack;
        wpgtrack(i,:,:)=net.wpg;
        certtrack(i,:)=dtatrkret.certtrack;
        wbptrack(i,:)=net.wbp;




        %############Plot algorithm results#############
        if mod(i,100000)==0 && params.nbatch==1
            printtype=1;
            printstuff;
        end
    end
    %#############################################

    a=(paindata>=const.tp).*(paindata-const.tp);
    b=cumsum(a);
    batchcumpain=batchcumpain+b;
    batchpain=batchpain+paindata;
    batchbias=batchbias+biasdata;
    batchprob=batchprob+probtrack;
    batchgoal=batchgoal+dtatrk.goalcount;
    batchaction=batchaction+dtatrk.actioncount;
    batchgoaltrack=[batchgoaltrack;goaltrack];
    batchpainredtrack=batchpainredtrack+painredtrack;
    batchcerttrack=batchcerttrack+certtrack;
    batchwbptrack=batchwbptrack+wbptrack;
end

printtype=2;
printstuff;
toc