%Initialize parameters for goal creation
net.wbp=zeros(params.ns,1);
net.wpg=0.02*rand(params.trg,params.ng)+0.49;

dtatrk.uses=zeros(params.ns,1);
probtrack=zeros(params.ns,params.niter);
intprobesttrack=zeros(params.ns,params.niter);

net.intprobtrack=[];
net.intprobest=ones(params.ns,1);
cysincerefresh=zeros(params.ns);
params.lim=ones(params.ns,1)*10;

%Initialize counters and other state variables
net.bias=zeros(params.ns,1);
net.painnull=ones(params.ns,1);
for j=1:params.ns
    if isempty(const.evpainhandle{j}), net.painnull(j)=0; end
end
net.pain=zeros(1,params.trg); %net.pain params.trg is primitive net.pain
net.cert=ones(params.trg,params.ng);
net.UA=[];
prevpaintrig=const.cur; dtatrk.sennum=1; pauset=1;

%Initial data tracking arrays
paindata=zeros(params.niter,params.trg);
prevpaindata=zeros(1,params.trg);
biasdata=zeros(params.niter,params.ns);
dtatrk.goalcount=zeros(params.trg,params.ng);
dtatrk.actioncount=zeros(1,10);
goaltrack=zeros(params.niter,3);
wpgtrack=zeros(params.niter,params.trg,params.ng);
certtrack=zeros(params.niter,params.ng);
painredtrack=zeros(params.niter,params.trg);
wbptrack=zeros(params.niter,params.ns);
paintrig=0;

%Create History array
hist.wingoals=zeros(1,params.histsize);
hist.paintrig=zeros(1,params.histsize);
hist.paindata=zeros(params.trg,params.histsize);
hist.probdata=zeros(params.ns,params.histsize);
hist.sennum=zeros(1,params.histsize);
hist.motnum=zeros(1,params.histsize);