% specify parameters for Wallee
%   describe sensory and pain inputs
s={'Lack of Sunlight' ;'Lack of Batteries' ;'Lack of Watering Can Water';'Lack of Faucet Water';'Lack of Barrel Water';'Lack of Pond Water';'Lack of Power' ;'Lack of Watered Plants' ;'Curiousity'};
%   describe sensory inputs
s2={'Sunlight' ;'Batteries' ;'Watering Can' ;'Water from Faucet' ;'Water from Barrel';'Water from Pond'};
%   describe motor outputs
m2={'water';'use';'bring'};

%   set numer of pains
np=size(s,1);
%   set the number of all sensory inputs 
ns=size(s2,1);
%   set the number of primitive pains (+1 for curiosity)
nprim=size(s,1)-ns;
%   set the number of motor outputs
nm=size(m2,1);

count=0;
Curlearn=1; %To Enable or disable curiosity be turning off/on the curiousity pain
KnownProb=1;

%Parameters
params=struct('nbatch',1,'niter', 20000,'ns', ns,'nm', nm);
params.ng=params.ns*params.nm;
params.nprim=nprim;
params.trg=params.ns+params.nprim;
%   this parameter sets the size of historical observation - recommended
%   value of params.histsize=2
params.histsize=1;
params.hadj=flipdim(1:-(1/params.histsize):(1/params.histsize),2);
params.batchwinave=10;
prims=zeros(1,params.nprim);

%Constants
const=struct('e',10^-9, 'deltabn', 0.0001, 'deltabp',0.04, ...
    'mugconst', 0.3, 'alphag', 1, 'alphap', 0.7, 'alphab', 0.5, 'tp', ...
    0.4, 'paintp', 0, 'tc', 20, 'rate', 0, 'goalthresh', 0.0001);
%   number of primitive pains
const.primpos=(ns+1):(np-1);
const.tc2=20;
const.cur=np;
const.tp=0.2;
const.muqconst=0.2;
const.paintp=(const.tp+0.001)*Curlearn;
const.rate=[1000000 const.tc*30 const.tc const.tc*2 const.tc*3 1000000]';
%const.rate=[const.tc const.tc const.tc const.tc 10000 100000 const.tc]';
%   const.evpainhandle show what sensory-motor actions can reduce the
%   corresponding pain - if no pair is shown there is no pain involved
%   this constant describes the environment response to agent's actions
const.evpainhandle{1}=[];           %Lack of Sunlight
const.evpainhandle{2}=[];           %Lack of Batteries
const.evpainhandle{3}=[4,3;5,3];    %Lack of Watering Can Water
const.evpainhandle{4}=[5,3];        %Lack of Faucet Water
const.evpainhandle{5}=[6,3];        %Lack of Barrel Water
const.evpainhandle{6}=[];           %Lack of Pond Water
const.evpainhandle{7}=[1,2;2,2];    %Lack of Power
const.evpainhandle{8}=[3,1];        %Lack of Watered Plants
const.evpainhandle{9}=[];           %Curiosity
const.set1=zeros(length(const.evpainhandle),1);
for i=1:length(const.evpainhandle)
    if ~isempty(const.evpainhandle{i})
        const.set1(i)=1;
    end
end
%const.set3=num2cell((params.ns+1):(const.cur-1));
const.set2=num2cell(find(const.set1==0))';
const.set1=num2cell(find(const.set1==1))';


batchpain=zeros(params.niter,params.trg);
batchcumpain=batchpain;
batchbias=zeros(params.niter,params.ns);
batchprob=zeros(params.ns,params.niter);
batchgoal=zeros(params.trg,params.ng);
batchaction=zeros(1,10);
batchgoaltrack=[];
batchpainredtrack=zeros(params.niter,params.trg);
batchcerttrack=zeros(params.niter,params.ng);
batchwbptrack=zeros(params.niter,params.ns);

net=struct('wuag', -10*ones(params.ng,1));
