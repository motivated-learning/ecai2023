% describe sensory inputs and motor action
s = {'No Food';'Lack of Farmland';'Lack of Employees';'Lack of Machinery';...
    'Dry Reservoir';'No Seeds';'No Money';'Curiousity'};
s2 = {'Grow Food';'Buy Farmland';'Hire Employees';'Buy Machinery';'Irrigate Reservoir';...
    'Buy Seeds'};
m2={'Grow';'Buy';'Hire';'Irigate'};

%   set the number of all sensory inputs 
ns=size(s2,1);
%   set the number of primitive pains (+1 for curiosity)
nprim=size(s,1)-ns;
%   set the number of motor outputs
nm=size(m2,1);

count=0;
Curlearn=1; %Curiosity Enabled
KnownProb=0; % Machine estimates its parameters

%Parameters
params=struct('nbatch',1,'niter', 15000,'ns', ns,'nm', nm);
params.ng=params.ns*params.nm;
params.nprim=nprim;
params.trg=params.ns+params.nprim;
params.histsize=2;
params.hadj=flipdim(1:-(1/params.histsize):(1/params.histsize),2);
params.batchwinave=1;
prims=zeros(1,params.nprim);

%Constants
const=struct('e',10^-9, 'deltabn', 0.0001, 'deltabp',0.02*4, ...
    'mugconst', 0.3, 'alphag', 1, 'alphap', 0.7, 'alphab', 0.5, 'tp', ...
    0.35, 'paintp', 0, 'tc', 10, 'rate', 0, 'goalthresh', 0.00051);
const.primpos=[7];
const.tc2=const.tc*1;
const.cur=8;
const.tp=0.35;
const.muqconst=0.2;
const.paintp=(const.tp+0.001)*Curlearn;
const.rate=[const.tc const.tc/2 const.tc/3 const.tc/4 10000 100000]';
const.evpainhandle=cell(1,params.ns+params.nprim-1);  %Create cell array specifying sensor-motor combinations that satify the pains
const.evpainhandle{1}=[2,2];
const.evpainhandle{2}=[3,3];
const.evpainhandle{3}=[4,2];
const.evpainhandle{4}=[5,4];
const.evpainhandle{5}=[6,2];
const.evpainhandle{6}=[];
const.evpainhandle{7}=[1,1];
const.evpainhandle{8}=[];
const.set1=zeros(length(const.evpainhandle),1);
for i=1:length(const.evpainhandle)
    if ~isempty(const.evpainhandle{i})
        const.set1(i)=1;
    end
end
const.set2=num2cell(find(const.set1==0))';
const.set1=num2cell(find(const.set1==1))';

batchpain=zeros(params.niter,params.trg);
batchcumpain=batchpain;
batchbias=zeros(params.niter,params.ns);
batchprob=zeros(params.ns,params.niter);
batchgoal=zeros(params.trg,params.ng);
batchaction=zeros(1,10);
batchgoaltrack=[];
batchpainredtrack=zeros(params.niter,params.trg);
batchcerttrack=zeros(params.niter,params.ng);
batchwbptrack=zeros(params.niter,params.ns);

net=struct('wuag', -10*ones(params.ng,1));