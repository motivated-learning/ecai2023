function [uses,prims,currentprob, sensor, actioncount,goaltrack]=enviroupdate2(const,goalnum,sennum, motnum, uses, paintrig,prims,actioncount,params,trg,pauset)

%Note that most of the parameters passed to and from this function are for indexing purposes or are simple passed for the purposes of "remembering"

if pauset==0
    validpairs=const.evpainhandle{paintrig};
    valid=0;

    if paintrig==const.cur
        for j=1:const.cur %checks for valid curiosity based combinations
            validpairs=const.evpainhandle{j};
            for i=1:size(const.evpainhandle{j},1)
                if ~isempty(validpairs) && validpairs(i,1)==sennum && validpairs(i,2)==motnum
                    valid=j; break;
                end
            end
        end
    else
        for i=1:size(validpairs,1)  %checks for valid pain based combinations
            if validpairs(i,1)==sennum && validpairs(i,2)==motnum
                valid=1; break;
            end
        end
    end

    if valid>0
        switch paintrig
            case const.cur
                goaltrack=[goalnum;0;1];
                %if sennum<5
                uses(sennum)=uses(sennum)+1;
                if valid>params.ns
                    b=find(paintrig~=(params.ns+1):(const.cur-1));
                    prims=prims+1;
                    prims(paintrig==(params.ns+1):(const.cur-1))=0;
                    if ~isempty(b)
                        prims(b)=prims(b)+1;
                    end
                else           %restore resource
                    prims=prims+1;
                    uses(valid)=0;
                end
                actioncount(params.ns+1)=actioncount(params.ns+1)+1;
            case const.set1%{1,2,3,4}
                uses(sennum)=uses(sennum)+1;    %Deplete resource
                if paintrig>params.ns && paintrig<const.cur
                    b=find(paintrig~=(params.ns+1):(const.cur-1));
                    prims(paintrig==(params.ns+1):(const.cur-1))=0;
                    if ~isempty(b)
                        prims(b)=prims(b)+1;
                    end
                else
                    uses(paintrig)=0;           %restore resource
                    prims=prims+1;
                end

                actioncount(sennum)=actioncount(sennum)+1;
                goaltrack=[goalnum;1;0];
            otherwise
                    uses(sennum)=uses(sennum)+1;
                    prims(paintrig-params.ns)=0;
                    actioncount(sennum)=actioncount(sennum)+1;
                    goaltrack=[goalnum;1;0];
        end
    else
        %   increase all primitive pain levels by 1
        prims=prims+1;
        switch paintrig
            case const.cur
                goaltrack=[goalnum;0;1];
                actioncount(params.ns+2)=actioncount(params.ns+2)+1; %motnum 6 action when mot~=sen
                uses(sennum)=uses(sennum)+1;
            otherwise
                uses(sennum)=uses(sennum)+1;
                goaltrack=[goalnum;0;0];
                actioncount(params.ns+3)=actioncount(params.ns+3)+1;
        end
    end
else
    goaltrack=[0;0;0];
end

[sensora currentprob]=environcheck(params.ns,const.rate,uses);
[sensor currentprob]=environcheck(params.ns,const.rate,uses);